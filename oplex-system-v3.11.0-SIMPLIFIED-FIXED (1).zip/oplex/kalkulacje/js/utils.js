/* ==========================================
   KALKULACJE - UTILS
   Funkcje pomocnicze
   Version: 1.0.0
   ========================================== */

/**
 * Formatuje kwotę do PLN
 * @param {number} amount
 * @returns {string}
 */
function formatCurrency(amount) {
  return new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: 'PLN',
    minimumFractionDigits: 2
  }).format(amount);
}

/**
 * Formatuje procent
 * @param {number} value
 * @param {number} decimals
 * @returns {string}
 */
function formatPercent(value, decimals = 2) {
  return value.toFixed(decimals) + '%';
}

/**
 * Formatuje dużą liczbę (z separatorami tysięcy)
 * @param {number} value
 * @returns {string}
 */
function formatNumber(value) {
  return new Intl.NumberFormat('pl-PL').format(value);
}

/**
 * Oblicza zmianę procentową
 * @param {number} oldValue
 * @param {number} newValue
 * @returns {number}
 */
function calculatePercentChange(oldValue, newValue) {
  if (oldValue === 0) return 0;
  return ((newValue - oldValue) / oldValue) * 100;
}

/**
 * Określa trend (up, down, stable)
 * @param {number} change
 * @returns {string}
 */
function getTrend(change) {
  if (change > 5) return 'up';
  if (change < -5) return 'down';
  return 'stable';
}

/**
 * Formatuje datę i czas
 */
function formatDateTime(timestamp) {
  const date = new Date(timestamp);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  
  return `${day}.${month}.${year} ${hours}:${minutes}`;
}
