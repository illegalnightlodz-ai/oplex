/* ==========================================
   KALKULACJE - STORAGE
   Oplex Management System
   Version: 1.0.0
   ========================================== */

const CALCULATIONS_KEY = "oplex:kalkulacje:data";
const INDICATORS_KEY = "oplex:kalkulacje:indicators";

/* ===================== HELPERS ===================== */

function loadJSON(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function saveJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ===================== CALCULATIONS ===================== */

/**
 * Pobiera dane obrotowe z modułu Obrót
 * @param {string} period - "week" | "month" | "year"
 * @returns {object}
 */
function getRevenueData(period = 'month') {
  // Integracja z System Obrót
  // Placeholder - do implementacji z rzeczywistymi danymi
  return {
    revenue: 0,
    costs: 0,
    profit: 0
  };
}

/**
 * Oblicza rentowność
 * @param {number} revenue
 * @param {number} costs
 * @returns {number} procent
 */
function calculateProfitability(revenue, costs) {
  if (revenue === 0) return 0;
  return ((revenue - costs) / revenue) * 100;
}

/**
 * Oblicza marżę
 * @param {number} revenue
 * @param {number} costs
 * @returns {number} procent
 */
function calculateMargin(revenue, costs) {
  if (revenue === 0) return 0;
  return ((revenue - costs) / costs) * 100;
}

/**
 * Oblicza średni obrót dzienny
 * @param {number} totalRevenue
 * @param {number} days
 * @returns {number}
 */
function calculateAverageDailyRevenue(totalRevenue, days) {
  if (days === 0) return 0;
  return totalRevenue / days;
}

/* ===================== INDICATORS ===================== */

/**
 * Zapisuje wskaźniki
 */
function saveIndicators(data) {
  saveJSON(INDICATORS_KEY, {
    ...data,
    updatedAt: new Date().toISOString()
  });
}

/**
 * Pobiera wskaźniki
 */
function getIndicators() {
  return loadJSON(INDICATORS_KEY, {});
}

/* ===================== FORECASTS ===================== */

/**
 * Prognozuje obrót na podstawie historii
 * @param {array} history - tablica obrotów z przeszłości
 * @param {number} periods - ile okresów do przodu
 * @returns {array}
 */
function forecastRevenue(history, periods = 3) {
  if (history.length < 2) return [];
  
  // Prosta średnia krocząca
  const sum = history.reduce((a, b) => a + b, 0);
  const avg = sum / history.length;
  
  const forecast = [];
  for (let i = 0; i < periods; i++) {
    forecast.push(Math.round(avg));
  }
  
  return forecast;
}
