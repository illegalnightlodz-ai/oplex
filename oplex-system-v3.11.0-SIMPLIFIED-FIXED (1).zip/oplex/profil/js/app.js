/* ==========================================
   OPLEX - PROFIL PRACOWNIKA
   ========================================== */

/**
 * Ładuje profil pracownika
 */
function loadProfile() {
  const username = getUser();
  const employee = getEmployeeByUsername(username);
  
  const container = document.getElementById('profileCard');
  
  if (!employee) {
    container.innerHTML = `
      <div class="info-box">
        <p>❌ Nie znaleziono profilu pracownika</p>
      </div>
    `;
    return;
  }
  
  container.innerHTML = `
    <div class="profile-header">
      <div class="profile-avatar">${employee.fullName.split(' ').map(n => n[0]).join('')}</div>
      <div class="profile-info">
        <h2>${employee.fullName}</h2>
        <p>${employee.position || 'Pracownik'}</p>
        <p style="color: var(--text-secondary); font-size: 0.9rem;">@${employee.username}</p>
      </div>
    </div>
    
    <div class="profile-details">
      <div class="detail-row">
        <span>📊 Udział w obrocie:</span>
        <strong>${(employee.percentage * 100).toFixed(1)}%</strong>
      </div>
      <div class="detail-row">
        <span>👥 Rola:</span>
        <strong>${getRoleName(employee.role)}</strong>
      </div>
      <div class="detail-row">
        <span>📅 Data zatrudnienia:</span>
        <strong>${formatDatePL(employee.hiredDate)}</strong>
      </div>
      <div class="detail-row">
        <span>✅ Status:</span>
        <strong style="color: var(--success);">${employee.active ? 'Aktywny' : 'Nieaktywny'}</strong>
      </div>
    </div>
  `;
}

/**
 * Ładuje historię wypłat pracownika
 */
function loadPayrollHistory() {
  const username = getUser();
  const container = document.getElementById('payrollHistory');
  
  // Pobierz wszystkie rozliczenia
  const payrolls = getPayrolls();
  
  // Filtruj tylko zamknięte rozliczenia
  const closedPayrolls = payrolls.filter(p => p.status === 'CLOSED');
  
  if (closedPayrolls.length === 0) {
    container.innerHTML = `
      <div class="info-box">
        <p>ℹ️ Brak zamkniętych rozliczeń</p>
      </div>
    `;
    return;
  }
  
  // Znajdź wypłaty dla tego pracownika
  const myPayrolls = closedPayrolls.map(payroll => {
    const myResult = payroll.results.find(r => r.employee.username === username);
    if (!myResult) return null;
    
    return {
      ...payroll,
      myResult
    };
  }).filter(Boolean);
  
  if (myPayrolls.length === 0) {
    container.innerHTML = `
      <div class="info-box">
        <p>ℹ️ Brak wypłat w historii</p>
      </div>
    `;
    return;
  }
  
  // Sortuj od najnowszych
  myPayrolls.sort((a, b) => new Date(b.closedAt) - new Date(a.closedAt));
  
  container.innerHTML = myPayrolls.map(p => `
    <div class="payroll-history-card">
      <div class="payroll-history-header">
        <div>
          <h3>${p.period}</h3>
          <p style="color: var(--text-secondary); font-size: 0.9rem;">
            Okres: ${p.dateRange.start} - ${p.dateRange.end}<br>
            Tygodnie: ${p.weeks.join(' + ')}<br>
            Zamknięto: ${new Date(p.closedAt).toLocaleString('pl-PL')}
          </p>
        </div>
        <div class="payroll-history-amount">
          ${p.myResult.finalTotal.toLocaleString('pl-PL')} zł
        </div>
      </div>
      
      <div class="payroll-history-details">
        <div class="detail-row">
          <span>💰 Obrót obsłużony:</span>
          <strong>${p.myResult.totalRevenue.toLocaleString('pl-PL')} zł</strong>
        </div>
        <div class="detail-row">
          <span>📊 Wypłata ${(p.myResult.employee.percentage * 100).toFixed(1)}%:</span>
          <strong>${p.myResult.percentageAmount.toLocaleString('pl-PL')} zł</strong>
        </div>
        ${p.myResult.saturdays && p.myResult.saturdays.length > 0 ? `
          <div class="detail-row">
            <span>🗓️ Soboty (${p.myResult.saturdays.length}x × ${p.saturdayRate} zł):</span>
            <strong>${p.myResult.saturdayBonus.toLocaleString('pl-PL')} zł</strong>
          </div>
          <div class="saturday-list">
            ${p.myResult.saturdays.map(s => `
              <div class="saturday-item ${s.auto ? 'auto' : 'manual'}">
                <span>${s.date}</span>
                <span>${s.station}</span>
                <span class="badge">${s.auto ? 'Auto' : 'Ręczne'}</span>
              </div>
            `).join('')}
          </div>
        ` : ''}
        ${p.myResult.adjustment && p.myResult.adjustment !== 0 ? `
          <div class="detail-row adjustment">
            <span>⚖️ Korekta:</span>
            <strong style="color: ${p.myResult.adjustment > 0 ? 'var(--success)' : 'var(--danger)'}">
              ${p.myResult.adjustment > 0 ? '+' : ''}${p.myResult.adjustment.toLocaleString('pl-PL')} zł
            </strong>
          </div>
        ` : ''}
      </div>
    </div>
  `).join('');
}

/**
 * Pobiera wszystkie rozliczenia
 */
function getPayrolls() {
  const key = 'oplex:admin:payrolls';
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch (e) {
    return [];
  }
}

/**
 * Formatuje nazwę roli
 */
function getRoleName(role) {
  const roles = {
    'employee': '👤 Pracownik',
    'manager': '🔑 Zarządca',
    'super-admin': '👑 Super-Admin'
  };
  return roles[role] || role;
}

/**
 * Formatuje datę na polski format
 */
function formatDatePL(dateStr) {
  if (!dateStr) return '-';
  const date = new Date(dateStr);
  return date.toLocaleDateString('pl-PL');
}
