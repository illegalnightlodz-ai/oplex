/* ==========================================
   OPLEX MANAGEMENT SYSTEM - AUTH
   Version: 3.0.0
   ========================================== */

function getUser() {
  return localStorage.getItem("oplex_user");
}

function setUser(name) {
  localStorage.setItem("oplex_user", name);
}

function logout() {
  if (confirm("Czy na pewno chcesz się wylogować?")) {
    localStorage.removeItem("oplex_user");
    window.location.reload();
  }
}

function requireAuth() {
  if (!getUser()) {
    document.getElementById("loginOverlay").style.display = "flex";
  } else {
    const username = getUser();
    let displayName = username;
    
    // Sprawdź czy użytkownik ma profil - wyświetl pełne imię
    if (typeof getEmployeeByUsername === 'function') {
      const employee = getEmployeeByUsername(username);
      if (employee && employee.fullName) {
        displayName = employee.fullName;
      }
    }
    
    // Update username in topbar
    const userNameTop = document.getElementById("userName");
    if (userNameTop) userNameTop.innerText = displayName;
    
    // Update username in footer
    const userNameFooter = document.getElementById("userNameFooter");
    if (userNameFooter) userNameFooter.innerText = displayName;
  }
}

function login() {
  const input = document.getElementById("loginName");
  const name = input.value.trim();
  
  if (!name) {
    alert("❌ Podaj login!");
    return;
  }

  // Sprawdź czy użytkownik istnieje w systemie pracowników
  if (typeof getEmployeeByUsername !== 'function') {
    alert("❌ System pracowników niedostępny!\n\nSkontaktuj się z administratorem.");
    return;
  }
  
  const employee = getEmployeeByUsername(name);
  
  if (!employee) {
    alert("❌ Nieprawidłowy login!\n\nUżytkownik nie istnieje w systemie.\n\nSkontaktuj się z administratorem aby utworzyć profil.");
    input.value = "";
    input.focus();
    return;
  }
  
  // Użytkownik istnieje - sprawdź czy ma hasło
  if (employee.password) {
    const password = prompt(`🔐 Witaj ${employee.fullName}!\n\nWprowadź hasło:`);
    
    if (!password) {
      return; // Anulowano
    }
    
    // Weryfikuj hasło
    if (typeof verifyEmployeePassword === 'function') {
      if (!verifyEmployeePassword(name, password)) {
        alert("❌ Nieprawidłowe hasło!");
        input.value = "";
        input.focus();
        return;
      }
    }
  }
  
  // Zaloguj użytkownika
  setUser(name);
  document.getElementById("loginOverlay").style.display = "none";
  
  // Jeśli to super-admin (konto "admin") - od razu daj token
  if (employee.role === "super-admin" && typeof loginAsAdmin === 'function') {
    const adminPassword = atob(employee.password);
    loginAsAdmin(adminPassword);
    console.log("✅ Auto-login super-admin");
  }
  
  // Update username w UI
  const userNameTop = document.getElementById("userName");
  if (userNameTop) userNameTop.innerText = employee.fullName || name;
  
  const userNameFooter = document.getElementById("userNameFooter");
  if (userNameFooter) userNameFooter.innerText = employee.fullName || name;
  
  // Odśwież stronę aby zaktualizować UI
  window.location.reload();
}

// Handle Enter key in login input
document.addEventListener("DOMContentLoaded", function() {
  const loginInput = document.getElementById("loginName");
  if (loginInput) {
    loginInput.addEventListener("keypress", function(event) {
      if (event.key === "Enter") {
        login();
      }
    });
  }
});
