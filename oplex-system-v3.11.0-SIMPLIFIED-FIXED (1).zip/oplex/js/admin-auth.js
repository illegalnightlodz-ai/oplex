/* ==========================================
   OPLEX MANAGEMENT SYSTEM - ADMIN AUTH
   Centralny system autoryzacji Super-Admin
   Version: 1.0.0
   ========================================== */

const ADMIN_SESSION_KEY = "oplex_admin_session";
const ADMIN_PASSWORD_KEY = "oplex_admin_password";
const SESSION_DURATION = 60 * 60 * 1000; // 60 minut w ms

/**
 * Inicjalizacja - ustaw domyślne hasło jeśli nie istnieje
 */
function initAdminAuth() {
  if (!localStorage.getItem(ADMIN_PASSWORD_KEY)) {
    // Domyślne hasło: sierra10 (base64)
    localStorage.setItem(ADMIN_PASSWORD_KEY, btoa("sierra10"));
  }
}

/**
 * Sprawdza czy sesja admin jest aktywna
 * @returns {boolean}
 */
function checkAdminSession() {
  try {
    const session = JSON.parse(localStorage.getItem(ADMIN_SESSION_KEY));
    
    if (!session || !session.active) {
      return false;
    }
    
    const now = Date.now();
    
    // Sprawdź czy sesja nie wygasła
    if (now > session.expiresAt) {
      logoutAdmin(true); // Auto-logout
      return false;
    }
    
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Logowanie jako admin
 * @param {string} password - Hasło super-admin
 * @returns {boolean} - Sukces logowania
 */
function loginAsAdmin(password) {
  try {
    const storedPassword = atob(localStorage.getItem(ADMIN_PASSWORD_KEY) || "");
    
    if (password !== storedPassword) {
      return false;
    }
    
    // Utwórz sesję
    const now = Date.now();
    const session = {
      active: true,
      user: getUser() || "admin",
      createdAt: now,
      expiresAt: now + SESSION_DURATION
    };
    
    localStorage.setItem(ADMIN_SESSION_KEY, JSON.stringify(session));
    
    // Log
    if (typeof addLog === 'function') {
      addLog("ADMIN_LOGIN", { user: session.user });
    }
    
    return true;
  } catch (e) {
    console.error("Błąd logowania admin:", e);
    return false;
  }
}

/**
 * Przedłuż sesję admin o kolejne 60 minut
 * @returns {boolean} - Sukces przedłużenia
 */
function extendAdminSession() {
  try {
    const session = JSON.parse(localStorage.getItem(ADMIN_SESSION_KEY));
    
    if (!session || !session.active) {
      return false;
    }
    
    // Przedłuż o 60 minut
    session.expiresAt = Date.now() + SESSION_DURATION;
    localStorage.setItem(ADMIN_SESSION_KEY, JSON.stringify(session));
    
    // Log
    if (typeof addLog === 'function') {
      addLog("ADMIN_SESSION_EXTENDED", { user: session.user });
    }
    
    return true;
  } catch (e) {
    console.error("Błąd przedłużenia sesji:", e);
    return false;
  }
}

/**
 * Wylogowanie z trybu admin
 * @param {boolean} autoLogout - Czy to auto-logout z powodu wygaśnięcia?
 */
function logoutAdmin(autoLogout = false) {
  try {
    const session = JSON.parse(localStorage.getItem(ADMIN_SESSION_KEY));
    const user = session ? session.user : "unknown";
    
    // Usuń sesję
    localStorage.removeItem(ADMIN_SESSION_KEY);
    
    // Log
    if (typeof addLog === 'function') {
      addLog(autoLogout ? "ADMIN_AUTO_LOGOUT" : "ADMIN_LOGOUT", { user });
    }
    
    // Przekieruj do dashboard z komunikatem
    if (autoLogout) {
      alert("⏱️ Sesja administratora wygasła. Zostałeś wylogowany z trybu admin.");
      window.location.href = "/oplex/index.html";
    } else {
      // Odśwież stronę aby zaktualizować UI
      window.location.reload();
    }
  } catch (e) {
    console.error("Błąd wylogowania admin:", e);
  }
}

/**
 * Pobiera pozostały czas sesji
 * @returns {number} - Pozostały czas w sekundach (0 jeśli brak sesji)
 */
function getRemainingTime() {
  try {
    const session = JSON.parse(localStorage.getItem(ADMIN_SESSION_KEY));
    
    if (!session || !session.active) {
      return 0;
    }
    
    const remaining = session.expiresAt - Date.now();
    return Math.max(0, Math.floor(remaining / 1000)); // Sekundy
  } catch (e) {
    return 0;
  }
}

/**
 * Formatuje czas do wyświetlenia (MM:SS)
 * @param {number} seconds - Czas w sekundach
 * @returns {string} - Sformatowany czas
 */
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

/**
 * Zmiana hasła super-admin
 * @param {string} oldPassword - Stare hasło
 * @param {string} newPassword - Nowe hasło
 * @returns {boolean} - Sukces zmiany
 */
function changeAdminPassword(oldPassword, newPassword) {
  try {
    const storedPassword = atob(localStorage.getItem(ADMIN_PASSWORD_KEY) || "");
    
    // Weryfikacja starego hasła
    if (oldPassword !== storedPassword) {
      return false;
    }
    
    // Walidacja nowego hasła
    if (!newPassword || newPassword.length < 6) {
      alert("❌ Nowe hasło musi mieć minimum 6 znaków!");
      return false;
    }
    
    // Zapisz nowe hasło (base64)
    localStorage.setItem(ADMIN_PASSWORD_KEY, btoa(newPassword));
    
    // Log
    if (typeof addLog === 'function') {
      addLog("ADMIN_PASSWORD_CHANGED", { 
        user: getUser(),
        timestamp: new Date().toISOString()
      });
    }
    
    return true;
  } catch (e) {
    console.error("Błąd zmiany hasła:", e);
    return false;
  }
}

/**
 * Timer - sprawdza sesję co 10 sekund
 */
let adminTimerInterval = null;

function startAdminTimer() {
  if (adminTimerInterval) {
    clearInterval(adminTimerInterval);
  }
  
  adminTimerInterval = setInterval(() => {
    if (!checkAdminSession()) {
      // Sesja wygasła - zatrzymaj timer
      stopAdminTimer();
    } else {
      // Zaktualizuj UI timera (jeśli istnieje)
      updateAdminTimerUI();
    }
  }, 10000); // Co 10 sekund
}

function stopAdminTimer() {
  if (adminTimerInterval) {
    clearInterval(adminTimerInterval);
    adminTimerInterval = null;
  }
}

/**
 * Aktualizacja UI timera (wywołana z zewnątrz lub przez timer)
 */
function updateAdminTimerUI() {
  const timerElement = document.getElementById('adminTimer');
  if (timerElement) {
    const remaining = getRemainingTime();
    timerElement.textContent = formatTime(remaining);
    
    // Zmień kolor jeśli zostało mniej niż 5 minut
    if (remaining < 300) {
      timerElement.style.color = "#dc2626";
      timerElement.style.fontWeight = "bold";
    } else {
      timerElement.style.color = "";
      timerElement.style.fontWeight = "";
    }
  }
  
  // Badge w topbar
  const badgeElement = document.getElementById('adminBadge');
  if (badgeElement) {
    const remaining = getRemainingTime();
    badgeElement.textContent = `🔐 Admin • ${formatTime(remaining)}`;
  }
}

/**
 * Inicjalizacja przy załadowaniu strony
 */
document.addEventListener('DOMContentLoaded', function() {
  initAdminAuth();
  
  // Jeśli sesja aktywna, uruchom timer
  if (checkAdminSession()) {
    startAdminTimer();
    updateAdminTimerUI();
  }
});

/**
 * Prompt logowania admin (wywołany z dashboard - przycisk w topbar)
 */
function promptAdminLogin() {
  const password = prompt("🔐 Wprowadź hasło Super-Admin:");
  
  if (!password) {
    return false;
  }
  
  if (loginAsAdmin(password)) {
    alert("✅ Zalogowano jako administrator!\n\nSesja będzie aktywna przez 60 minut.");
    startAdminTimer();
    window.location.reload(); // Odśwież stronę
    return true;
  } else {
    alert("❌ Nieprawidłowe hasło!");
    return false;
  }
}

/**
 * Prompt logowania przez kafelek Super-Admin (dla zarządców)
 * Wymaga: użytkownik zalogowany + ranga manager
 */
function promptManagerLogin() {
  const username = getUser();
  
  if (!username) {
    alert("❌ Musisz się najpierw zalogować!");
    return false;
  }
  
  // Sprawdź czy użytkownik ma profil
  if (typeof getEmployeeByUsername !== 'function') {
    alert("❌ System pracowników niedostępny!");
    return false;
  }
  
  const employee = getEmployeeByUsername(username);
  
  if (!employee) {
    alert("❌ Nie masz profilu pracownika!\n\nDostęp do Super-Admin wymaga profilu z rangą Zarządca.");
    return false;
  }
  
  // Sprawdź rangę
  if (employee.role !== 'manager' && employee.role !== 'super-admin') {
    alert("❌ Brak uprawnień!\n\nDostęp do Super-Admin wymaga rangi Zarządca.");
    return false;
  }
  
  // Dla super-admin sprawdź czy już ma token
  if (employee.role === 'super-admin' && checkAdminSession()) {
    // Już zalogowany - przekieruj do panelu
    window.location.href = '/oplex/admin/index.html';
    return true;
  }
  
  // Prompt hasła pracownika
  if (employee.password) {
    const password = prompt(`🔐 Witaj ${employee.fullName}!\n\nWprowadź swoje hasło aby uzyskać dostęp admin:`);
    
    if (!password) {
      return false;
    }
    
    // Weryfikuj hasło
    if (typeof verifyEmployeePassword === 'function') {
      if (!verifyEmployeePassword(username, password)) {
        alert("❌ Nieprawidłowe hasło!");
        return false;
      }
    }
  }
  
  // Zaloguj jako admin
  // Dla zarządcy - użyj hasła super-admin
  const adminPassword = prompt("🔑 Wprowadź hasło Super-Admin:");
  
  if (!adminPassword) {
    return false;
  }
  
  if (loginAsAdmin(adminPassword)) {
    alert(`✅ Witaj ${employee.fullName}!\n\nOtrzymałeś dostęp administratora na 60 minut.`);
    startAdminTimer();
    window.location.href = '/oplex/admin/index.html';
    return true;
  } else {
    alert("❌ Nieprawidłowe hasło Super-Admin!");
    return false;
  }
}

/**
 * Prompt zmiany hasła
 */
function promptChangePassword() {
  if (!checkAdminSession()) {
    alert("❌ Brak uprawnień! Zaloguj się jako administrator.");
    return false;
  }
  
  const oldPassword = prompt("🔐 Aktualne hasło:");
  if (!oldPassword) return false;
  
  const newPassword = prompt("🔑 Nowe hasło (min. 6 znaków):");
  if (!newPassword) return false;
  
  const confirmPassword = prompt("🔑 Powtórz nowe hasło:");
  if (!confirmPassword) return false;
  
  if (newPassword !== confirmPassword) {
    alert("❌ Hasła nie są identyczne!");
    return false;
  }
  
  if (changeAdminPassword(oldPassword, newPassword)) {
    alert("✅ Hasło zostało zmienione!");
    return true;
  } else {
    alert("❌ Nieprawidłowe aktualne hasło!");
    return false;
  }
}

/**
 * UI: Przycisk przedłużenia sesji
 */
function handleExtendSession() {
  if (extendAdminSession()) {
    alert("✅ Sesja przedłużona o 60 minut!");
    updateAdminTimerUI();
  } else {
    alert("❌ Błąd przedłużenia sesji!");
  }
}

/**
 * UI: Przycisk wylogowania admin
 */
function handleLogoutAdmin() {
  if (confirm("Czy na pewno chcesz wylogować się z trybu administratora?")) {
    logoutAdmin(false);
  }
}

/**
 * Pobiera pozostały czas sesji admin w sekundach
 * @returns {number} - Pozostały czas w sekundach
 */
function getAdminTimeRemaining() {
  try {
    const session = JSON.parse(localStorage.getItem(ADMIN_SESSION_KEY));
    
    if (!session || !session.active) {
      return 0;
    }
    
    const now = Date.now();
    const remaining = Math.max(0, Math.floor((session.expiresAt - now) / 1000));
    
    return remaining;
  } catch (e) {
    return 0;
  }
}
