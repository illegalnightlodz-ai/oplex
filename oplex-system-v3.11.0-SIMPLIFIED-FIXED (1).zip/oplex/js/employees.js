/* ==========================================
   OPLEX MANAGEMENT SYSTEM - EMPLOYEES
   System zarządzania profilami pracowników
   Version: 1.0.0
   ========================================== */

const EMPLOYEES_KEY = "oplex_employees";

/**
 * Inicjalizacja - utwórz konto super-admin jeśli nie istnieje
 */
function initEmployees() {
  const employees = getEmployees();
  
  // Sprawdź czy istnieje konto "admin"
  const adminExists = employees.some(e => e.username === "admin");
  
  if (!adminExists) {
    // Utwórz ukryte konto awaryjne super-admin
    const superAdmin = {
      id: "admin_" + Date.now(),
      username: "admin",
      fullName: "Super Administrator",
      password: btoa("sierra10"), // Zaszyfrowane base64
      role: "super-admin",
      position: "Administrator Systemu",
      active: true,
      hidden: true, // Ukryte w liście pracowników
      percentage: 0, // Nie uczestniczy w wypłatach
      hiredDate: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString()
    };
    
    employees.push(superAdmin);
    saveEmployees(employees);
    
    console.log("✅ Utworzono konto awaryjne super-admin (admin / sierra10)");
  }
}

/**
 * Pobiera wszystkich pracowników
 * @returns {Array}
 */
function getEmployees() {
  try {
    return JSON.parse(localStorage.getItem(EMPLOYEES_KEY)) || [];
  } catch (e) {
    console.error("Błąd odczytu pracowników:", e);
    return [];
  }
}

/**
 * Zapisuje pracowników
 * @param {Array} employees
 */
function saveEmployees(employees) {
  try {
    localStorage.setItem(EMPLOYEES_KEY, JSON.stringify(employees));
  } catch (e) {
    console.error("Błąd zapisu pracowników:", e);
  }
}

/**
 * Pobiera pracownika po username
 * @param {string} username
 * @returns {object|null}
 */
function getEmployeeByUsername(username) {
  const employees = getEmployees();
  return employees.find(e => e.username === username) || null;
}

/**
 * Pobiera pracownika po ID
 * @param {string} id
 * @returns {object|null}
 */
function getEmployeeById(id) {
  const employees = getEmployees();
  return employees.find(e => e.id === id) || null;
}

/**
 * Dodaje nowego pracownika
 * @param {object} employeeData
 * @returns {boolean}
 */
function addEmployee(employeeData) {
  try {
    const employees = getEmployees();
    
    // Sprawdź czy username już istnieje
    if (employees.some(e => e.username === employeeData.username)) {
      alert("❌ Użytkownik o tym loginie już istnieje!");
      return false;
    }
    
    const newEmployee = {
      id: "emp_" + Date.now(),
      username: employeeData.username,
      fullName: employeeData.fullName,
      password: employeeData.password ? btoa(employeeData.password) : null,
      role: employeeData.role || "employee", // "employee" | "manager" | "super-admin"
      position: employeeData.position || "",
      percentage: parseFloat(employeeData.percentage) || 1,
      active: employeeData.active !== false,
      hidden: false,
      hiredDate: employeeData.hiredDate || new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString()
    };
    
    employees.push(newEmployee);
    saveEmployees(employees);
    
    // Log
    if (typeof addLog === 'function') {
      addLog("EMPLOYEE_ADDED", {
        employeeId: newEmployee.id,
        username: newEmployee.username,
        role: newEmployee.role
      });
    }
    
    return true;
  } catch (e) {
    console.error("Błąd dodawania pracownika:", e);
    return false;
  }
}

/**
 * Aktualizuje pracownika
 * @param {string} id
 * @param {object} updates
 * @returns {boolean}
 */
function updateEmployee(id, updates) {
  try {
    const employees = getEmployees();
    const index = employees.findIndex(e => e.id === id);
    
    if (index === -1) {
      alert("❌ Pracownik nie istnieje!");
      return false;
    }
    
    // Sprawdź czy zmiana username nie koliduje z innym pracownikiem
    if (updates.username && updates.username !== employees[index].username) {
      if (employees.some(e => e.username === updates.username && e.id !== id)) {
        alert("❌ Login już zajęty przez innego pracownika!");
        return false;
      }
    }
    
    // Aktualizuj dane
    employees[index] = {
      ...employees[index],
      ...updates,
      password: updates.password ? btoa(updates.password) : employees[index].password,
      updatedAt: new Date().toISOString()
    };
    
    saveEmployees(employees);
    
    // Log
    if (typeof addLog === 'function') {
      addLog("EMPLOYEE_UPDATED", {
        employeeId: id,
        username: employees[index].username,
        changes: Object.keys(updates)
      });
    }
    
    return true;
  } catch (e) {
    console.error("Błąd aktualizacji pracownika:", e);
    return false;
  }
}

/**
 * Usuwa pracownika (soft delete - oznacza jako nieaktywny)
 * @param {string} id
 * @returns {boolean}
 */
function deleteEmployee(id) {
  try {
    const employee = getEmployeeById(id);
    
    if (!employee) {
      alert("❌ Pracownik nie istnieje!");
      return false;
    }
    
    // Nie można usunąć konta super-admin
    if (employee.role === "super-admin") {
      alert("❌ Nie można usunąć konta super-admin!");
      return false;
    }
    
    // Soft delete - ustaw jako nieaktywny
    return updateEmployee(id, { active: false });
  } catch (e) {
    console.error("Błąd usuwania pracownika:", e);
    return false;
  }
}

/**
 * Weryfikuje hasło pracownika
 * @param {string} username
 * @param {string} password
 * @returns {boolean}
 */
function verifyEmployeePassword(username, password) {
  try {
    const employee = getEmployeeByUsername(username);
    
    if (!employee) {
      return false;
    }
    
    // Jeśli pracownik nie ma hasła, zwróć false
    if (!employee.password) {
      return false;
    }
    
    // Sprawdź hasło
    const storedPassword = atob(employee.password);
    return password === storedPassword;
  } catch (e) {
    console.error("Błąd weryfikacji hasła:", e);
    return false;
  }
}

/**
 * Sprawdza czy pracownik ma uprawnienia zarządcy lub super-admin
 * @param {string} username
 * @returns {boolean}
 */
function isManager(username) {
  const employee = getEmployeeByUsername(username);
  return employee && (employee.role === "manager" || employee.role === "super-admin");
}

/**
 * Sprawdza czy użytkownik to super-admin
 * @param {string} username
 * @returns {boolean}
 */
function isSuperAdmin(username) {
  const employee = getEmployeeByUsername(username);
  return employee && employee.role === "super-admin";
}

/**
 * Pobiera widocznych pracowników (bez ukrytych)
 * @returns {Array}
 */
function getVisibleEmployees() {
  return getEmployees().filter(e => !e.hidden);
}

/**
 * Pobiera aktywnych pracowników do wypłat
 * @returns {Array}
 */
function getActiveEmployees() {
  return getEmployees().filter(e => e.active && !e.hidden && e.percentage > 0);
}

/**
 * Eksport pracowników (bez haseł)
 * @returns {Array}
 */
function exportEmployees() {
  const employees = getEmployees();
  return employees.map(e => ({
    ...e,
    password: e.password ? "***" : null // Ukryj hasła
  }));
}

/**
 * Import pracowników
 * @param {Array} data
 * @returns {boolean}
 */
function importEmployees(data) {
  try {
    if (!Array.isArray(data)) {
      alert("❌ Nieprawidłowy format danych!");
      return false;
    }
    
    // Zachowaj istniejące hasła
    const existing = getEmployees();
    const merged = data.map(emp => {
      const old = existing.find(e => e.username === emp.username);
      return {
        ...emp,
        password: old ? old.password : emp.password
      };
    });
    
    saveEmployees(merged);
    
    // Log
    if (typeof addLog === 'function') {
      addLog("EMPLOYEES_IMPORTED", { count: merged.length });
    }
    
    return true;
  } catch (e) {
    console.error("Błąd importu pracowników:", e);
    return false;
  }
}

// Inicjalizacja przy załadowaniu
if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', function() {
    initEmployees();
  });
}

/**
 * Sprawdza czy użytkownik ma dostęp do trybu Admin
 * @param {string} username
 * @returns {boolean}
 */
function canAccessAdminMode(username) {
  const employee = getEmployeeByUsername(username);
  if (!employee) return false;
  
  // Tylko super-admin i manager mogą logować się jako admin
  return employee.role === 'super-admin' || employee.role === 'manager';
}
