/* ==========================================
   URLOPY - UTILS
   Funkcje pomocnicze
   Version: 1.0.0
   ========================================== */

/**
 * Oblicza liczbę dni roboczych między datami (bez sobót i niedziel)
 */
function calculateWorkDays(startDate, endDate) {
  const start = new Date(startDate);
  const end = new Date(endDate);
  let count = 0;
  
  const current = new Date(start);
  while (current <= end) {
    const dayOfWeek = current.getDay();
    // Pomiń soboty (6) i niedziele (0)
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  
  return count;
}

/**
 * Formatuje datę do YYYY-MM-DD
 */
function formatDate(date) {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Formatuje datę do polskiego formatu DD.MM.YYYY
 */
function formatDatePL(dateStr) {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  return `${day}.${month}.${year}`;
}

/**
 * Pobiera pierwszy i ostatni dzień miesiąca
 */
function getMonthRange(year, month) {
  const firstDay = new Date(year, month - 1, 1);
  const lastDay = new Date(year, month, 0);
  
  return {
    start: formatDate(firstDay),
    end: formatDate(lastDay)
  };
}

/**
 * Pobiera nazwę miesiąca
 */
function getMonthName(month) {
  const months = [
    'Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec',
    'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'
  ];
  return months[month - 1] || '';
}

/**
 * Sprawdza czy data jest weekendem
 */
function isWeekend(dateStr) {
  const date = new Date(dateStr);
  const day = date.getDay();
  return day === 0 || day === 6;
}

/**
 * Dzisiejsza data
 */
function today() {
  return formatDate(new Date());
}
