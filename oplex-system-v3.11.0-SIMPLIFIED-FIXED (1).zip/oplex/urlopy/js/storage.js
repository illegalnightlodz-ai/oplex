/* ==========================================
   URLOPY - STORAGE
   Oplex Management System
   Version: 1.0.0
   ========================================== */

const VACATION_LIMITS_KEY = "oplex:urlopy:limits";
const VACATION_REQUESTS_KEY = "oplex:urlopy:requests";
const VACATION_CALENDAR_KEY = "oplex:urlopy:calendar";

/* ===================== HELPERS ===================== */

function loadJSON(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function saveJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ===================== LIMITS ===================== */

/**
 * Pobiera limity urlopowe dla pracownika
 * @param {string} username
 * @returns {object|null}
 */
function getVacationLimit(username) {
  const limits = loadJSON(VACATION_LIMITS_KEY, {});
  return limits[username] || null;
}

/**
 * Ustawia limit urlopowy dla pracownika
 * @param {string} username
 * @param {number} days
 */
function setVacationLimit(username, days) {
  const limits = loadJSON(VACATION_LIMITS_KEY, {});
  limits[username] = {
    total: days,
    used: limits[username]?.used || 0,
    remaining: days - (limits[username]?.used || 0),
    updatedAt: new Date().toISOString()
  };
  saveJSON(VACATION_LIMITS_KEY, limits);
}

/**
 * Pobiera wszystkie limity
 */
function getAllVacationLimits() {
  return loadJSON(VACATION_LIMITS_KEY, {});
}

/* ===================== REQUESTS ===================== */

/**
 * Dodaje wniosek urlopowy
 */
function addVacationRequest(data) {
  const requests = loadJSON(VACATION_REQUESTS_KEY, []);
  const request = {
    id: "vac_" + Date.now(),
    username: data.username,
    startDate: data.startDate,
    endDate: data.endDate,
    days: data.days,
    type: data.type || "urlop", // "urlop" | "zwolnienie" | "okazjonalny"
    status: "pending", // "pending" | "approved" | "rejected"
    requestedAt: new Date().toISOString(),
    requestedBy: data.requestedBy || getUser()
  };
  
  requests.push(request);
  saveJSON(VACATION_REQUESTS_KEY, requests);
  
  return request;
}

/**
 * Pobiera wnioski urlopowe
 */
function getVacationRequests(username = null) {
  const requests = loadJSON(VACATION_REQUESTS_KEY, []);
  if (username) {
    return requests.filter(r => r.username === username);
  }
  return requests;
}

/**
 * Aktualizuje status wniosku
 */
function updateVacationRequest(id, status) {
  const requests = loadJSON(VACATION_REQUESTS_KEY, []);
  const index = requests.findIndex(r => r.id === id);
  
  if (index >= 0) {
    requests[index].status = status;
    requests[index].processedAt = new Date().toISOString();
    requests[index].processedBy = getUser();
    saveJSON(VACATION_REQUESTS_KEY, requests);
    
    // Jeśli zatwierdzono - dodaj do kalendarza
    if (status === "approved") {
      addToCalendar(requests[index]);
    }
  }
}

/* ===================== CALENDAR ===================== */

/**
 * Dodaje urlop do kalendarza
 */
function addToCalendar(vacationData) {
  const calendar = loadJSON(VACATION_CALENDAR_KEY, []);
  
  calendar.push({
    id: vacationData.id,
    username: vacationData.username,
    startDate: vacationData.startDate,
    endDate: vacationData.endDate,
    days: vacationData.days,
    type: vacationData.type
  });
  
  saveJSON(VACATION_CALENDAR_KEY, calendar);
  
  // Zaktualizuj wykorzystane dni
  updateUsedDays(vacationData.username, vacationData.days);
}

/**
 * Pobiera kalendarz urlopów
 */
function getVacationCalendar(startDate = null, endDate = null) {
  const calendar = loadJSON(VACATION_CALENDAR_KEY, []);
  
  if (startDate && endDate) {
    return calendar.filter(v => {
      return v.startDate <= endDate && v.endDate >= startDate;
    });
  }
  
  return calendar;
}

/**
 * Aktualizuje wykorzystane dni
 */
function updateUsedDays(username, days) {
  const limits = loadJSON(VACATION_LIMITS_KEY, {});
  
  if (limits[username]) {
    limits[username].used += days;
    limits[username].remaining = limits[username].total - limits[username].used;
    saveJSON(VACATION_LIMITS_KEY, limits);
  }
}
