/* ==========================================
   OPLEX SUPER-ADMIN - APP
   Version: 1.0.0
   ========================================== */

// Current view
let currentTab = 'employees';

/**
 * Przełączanie zakładek
 */
function switchTab(tabName) {
  // Ukryj wszystkie
  document.querySelectorAll('.tab-content').forEach(el => {
    el.style.display = 'none';
  });
  
  // Pokaż wybraną
  const view = document.getElementById(tabName + 'View');
  if (view) {
    view.style.display = 'block';
  }
  
  // Zaktualizuj przyciski
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  event.target.classList.add('active');
  
  currentTab = tabName;
  
  // Załaduj dane dla danej zakładki
  if (tabName === 'employees') {
    renderEmployeesList();
  } else if (tabName === 'payroll') {
    renderPayroll();
  } else if (tabName === 'costs') {
    // Placeholder - do implementacji
  } else if (tabName === 'audit') {
    refreshAdminLogs();
  } else if (tabName === 'settings') {
    calculateStorageUsage();
  }
}

/* ==========================================
   TAB: EMPLOYEES
   ========================================== */

/**
 * Renderuje listę pracowników
 */
function renderEmployeesList() {
  const container = document.getElementById('employeesList');
  const employees = getVisibleEmployees();
  
  if (employees.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>👥 Brak pracowników w systemie</p>
        <p style="font-size: 14px; color: #6b7280;">Kliknij "Dodaj Pracownika" aby utworzyć pierwszy profil.</p>
      </div>
    `;
    return;
  }
  
  container.innerHTML = employees.map(emp => `
    <div class="employee-card ${!emp.active ? 'inactive' : ''}">
      <div class="employee-header">
        <div class="employee-avatar">${emp.fullName.charAt(0)}</div>
        <div class="employee-info">
          <h4>${emp.fullName}</h4>
          <p class="employee-username">@${emp.username}</p>
        </div>
        <div class="employee-role-badge ${emp.role}">
          ${emp.role === 'super-admin' ? '👑 Super-Admin' : 
            emp.role === 'manager' ? '🔑 Zarządca' : '👤 Pracownik'}
        </div>
      </div>
      
      <div class="employee-details">
        <div class="detail-row">
          <span class="label">Stanowisko:</span>
          <span class="value">${emp.position || '---'}</span>
        </div>
        <div class="detail-row">
          <span class="label">Procent z obrotu:</span>
          <span class="value">${emp.percentage}%</span>
        </div>
        <div class="detail-row">
          <span class="label">Data zatrudnienia:</span>
          <span class="value">${formatDatePL(emp.hiredDate)}</span>
        </div>
        <div class="detail-row">
          <span class="label">Hasło:</span>
          <span class="value">${emp.password ? '🔒 Ustawione' : '⚠️ Brak'}</span>
        </div>
        <div class="detail-row">
          <span class="label">Status:</span>
          <span class="value ${emp.active ? 'status-active' : 'status-inactive'}">
            ${emp.active ? '✅ Aktywny' : '❌ Nieaktywny'}
          </span>
        </div>
      </div>
      
      <div class="employee-actions">
        <button class="btn-edit" onclick="editEmployee('${emp.id}')">
          ✏️ Edytuj
        </button>
        ${emp.role !== 'super-admin' ? `
          <button class="btn-delete" onclick="confirmDeleteEmployee('${emp.id}')">
            🗑️ Usuń
          </button>
        ` : ''}
      </div>
    </div>
  `).join('');
}

/**
 * Otwiera modal dodawania pracownika
 */
function openAddEmployeeModal() {
  document.getElementById('modalTitle').textContent = '➕ Dodaj Pracownika';
  document.getElementById('employeeId').value = '';
  document.getElementById('employeeName').value = '';
  document.getElementById('employeeUsername').value = '';
  document.getElementById('employeePassword').value = '';
  document.getElementById('employeePosition').value = '';
  document.getElementById('employeePercentage').value = '1';
  document.getElementById('employeeRole').value = 'employee';
  document.getElementById('employeeHiredDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('employeeActive').checked = true;
  
  document.getElementById('employeeModal').style.display = 'flex';
}

/**
 * Edycja pracownika
 */
function editEmployee(id) {
  const employee = getEmployeeById(id);
  
  if (!employee) {
    alert('❌ Pracownik nie istnieje!');
    return;
  }
  
  document.getElementById('modalTitle').textContent = '✏️ Edytuj Pracownika';
  document.getElementById('employeeId').value = employee.id;
  document.getElementById('employeeName').value = employee.fullName;
  document.getElementById('employeeUsername').value = employee.username;
  document.getElementById('employeePassword').value = ''; // Nie pokazuj hasła
  document.getElementById('employeePosition').value = employee.position || '';
  document.getElementById('employeePercentage').value = employee.percentage;
  document.getElementById('employeeRole').value = employee.role;
  document.getElementById('employeeHiredDate').value = employee.hiredDate;
  document.getElementById('employeeActive').checked = employee.active;
  
  document.getElementById('employeeModal').style.display = 'flex';
}

/**
 * Zapisuje pracownika
 */
function saveEmployee() {
  const id = document.getElementById('employeeId').value;
  const fullName = document.getElementById('employeeName').value.trim();
  const username = document.getElementById('employeeUsername').value.trim();
  const password = document.getElementById('employeePassword').value.trim();
  const position = document.getElementById('employeePosition').value.trim();
  const percentage = parseFloat(document.getElementById('employeePercentage').value);
  const role = document.getElementById('employeeRole').value;
  const hiredDate = document.getElementById('employeeHiredDate').value;
  const active = document.getElementById('employeeActive').checked;
  
  // Walidacja
  if (!fullName) {
    alert('❌ Podaj imię i nazwisko!');
    return;
  }
  
  if (!username) {
    alert('❌ Podaj login!');
    return;
  }
  
  const employeeData = {
    fullName,
    username,
    password: password || null,
    position,
    percentage,
    role,
    hiredDate,
    active
  };
  
  let success = false;
  
  if (id) {
    // Edycja
    success = updateEmployee(id, employeeData);
  } else {
    // Dodawanie
    success = addEmployee(employeeData);
  }
  
  if (success) {
    alert(`✅ Pracownik został ${id ? 'zaktualizowany' : 'dodany'}!`);
    closeEmployeeModal();
    renderEmployeesList();
  }
}

/**
 * Potwierdź usunięcie pracownika
 */
function confirmDeleteEmployee(id) {
  const employee = getEmployeeById(id);
  
  if (!employee) {
    alert('❌ Pracownik nie istnieje!');
    return;
  }
  
  if (!confirm(`Czy na pewno chcesz usunąć pracownika:\n\n${employee.fullName} (@${employee.username})?\n\nPracownik zostanie oznaczony jako nieaktywny.`)) {
    return;
  }
  
  if (deleteEmployee(id)) {
    alert('✅ Pracownik został usunięty!');
    renderEmployeesList();
  }
}

/**
 * Zamyka modal pracownika
 */
function closeEmployeeModal() {
  document.getElementById('employeeModal').style.display = 'none';
}


/* ==========================================
   TAB: PAYROLL - UPROSZCZONE
   ========================================== */

const SATURDAY_RATE = 200;

/**
 * Inicjalizuje zakładkę wypłat
 */
function renderPayroll() {
  renderPayrollStartConfig();
  renderCurrentPayrollPeriod();
}

/**
 * Renderuje konfigurację poniedziałku startowego
 */
function renderPayrollStartConfig() {
  const container = document.getElementById('payrollStartConfig');
  const config = getPayrollConfig();
  
  if (config && config.locked) {
    // ZABLOKOWANE
    const canUnlock = typeof checkAdminSession === 'function' && checkAdminSession();
    
    container.className = 'config-card locked';
    container.innerHTML = `
      <h3>✅ Poniedziałek startowy skonfigurowany</h3>
      <div class="config-locked-info">
        <div class="info">
          Rozliczenia rozpoczynają się od: <strong>${formatDatePL(config.startMonday)}</strong> (poniedziałek)<br>
          <span style="font-size: 0.85rem; color: var(--text-muted);">
            Ustawiono: ${new Date(config.setAt).toLocaleString('pl-PL')} przez ${config.setBy}
          </span>
        </div>
        ${canUnlock ? `
          <button class="btn-secondary" onclick="unlockPayrollConfig()">
            🔓 Odblokuj
          </button>
        ` : ''}
      </div>
    `;
  } else {
    // NIEZABLOKOWANE - pokaż formularz
    container.className = 'config-card';
    container.innerHTML = `
      <h3>🔧 Konfiguracja poniedziałku startowego</h3>
      <p style="color: var(--text-secondary); margin-bottom: 16px;">
        Wybierz poniedziałek od którego rozpocząć dwu-tygodniowe okresy rozliczeniowe.
        Po zapisie nie będzie można zmienić bez odblokowania.
      </p>
      <div class="config-form">
        <label>Poniedziałek startowy:</label>
        <input type="date" id="startMondayInput" style="padding: 10px 14px; border-radius: 8px; border: 1px solid rgba(59, 130, 246, 0.3); background: var(--dark-card); color: var(--text-primary); font-size: 1rem;">
        <button class="btn-primary" onclick="savePayrollConfig()">
          ✅ Zapisz i zablokuj
        </button>
      </div>
    `;
  }
}

/**
 * Pobiera konfigurację
 */
function getPayrollConfig() {
  const key = 'oplex:admin:payroll-config';
  try {
    return JSON.parse(localStorage.getItem(key));
  } catch (e) {
    return null;
  }
}

/**
 * Zapisuje konfigurację
 */
function savePayrollConfig() {
  const input = document.getElementById('startMondayInput');
  const date = input.value;
  
  if (!date) {
    alert('❌ Wybierz datę!');
    return;
  }
  
  // Sprawdź czy to poniedziałek
  const d = new Date(date + 'T00:00:00');
  if (d.getDay() !== 1) {
    alert('❌ Wybrana data nie jest poniedziałkiem!\n\nWybierz poniedziałek.');
    return;
  }
  
  const confirmed = confirm(
    `🔒 ZABLOKUJ PONIEDZIAŁEK STARTOWY\n\n` +
    `Data: ${formatDatePL(date)} (poniedziałek)\n\n` +
    `Po zapisie nie będzie można zmienić bez odblokowania przez admina.\n\n` +
    `Czy kontynuować?`
  );
  
  if (!confirmed) return;
  
  const config = {
    startMonday: date,
    currentPeriodStart: date,
    setAt: new Date().toISOString(),
    setBy: getUser(),
    locked: true
  };
  
  const key = 'oplex:admin:payroll-config';
  localStorage.setItem(key, JSON.stringify(config));
  
  alert('✅ Poniedziałek startowy zapisany!');
  renderPayroll();
}

/**
 * Odblokowuje konfigurację (tylko admin)
 */
function unlockPayrollConfig() {
  if (typeof checkAdminSession !== 'function' || !checkAdminSession()) {
    alert('❌ Wymagane uprawnienia administratora!');
    return;
  }
  
  const confirmed = confirm(
    `🔓 ODBLOKUJ KONFIGURACJĘ\n\n` +
    `Czy na pewno chcesz odblokować?\n\n` +
    `To pozwoli zmienić poniedziałek startowy.`
  );
  
  if (!confirmed) return;
  
  const key = 'oplex:admin:payroll-config';
  localStorage.removeItem(key);
  
  alert('✅ Konfiguracja odblokowana!');
  renderPayroll();
}

/**
 * Renderuje bieżący okres (2 tygodnie)
 */
function renderCurrentPayrollPeriod() {
  const config = getPayrollConfig();
  
  if (!config || !config.locked) {
    document.getElementById('payrollPeriodInfo').innerHTML = `
      <p style="color: var(--text-secondary);">Najpierw skonfiguruj poniedziałek startowy powyżej</p>
    `;
    document.getElementById('week1Card').innerHTML = '';
    document.getElementById('week2Card').innerHTML = '';
    document.getElementById('generatePayrollBtn').disabled = true;
    return;
  }
  
  // Oblicz bieżący okres (2 tygodnie)
  const periodStart = config.currentPeriodStart;
  const week1Start = periodStart;
  const week1End = addDays(week1Start, 6);
  const week2Start = addDays(week1Start, 7);
  const week2End = addDays(week1Start, 13);
  
  // Info o okresie
  document.getElementById('payrollPeriodInfo').innerHTML = `
    <h3 style="margin: 0 0 8px 0; color: var(--text-primary);">Bieżący okres rozliczeniowy</h3>
    <p style="margin: 0; color: var(--text-secondary);">
      ${formatDatePL(week1Start)} - ${formatDatePL(week2End)} (2 tygodnie)
    </p>
  `;
  
  // Oblicz dane dla każdego tygodnia
  const week1Data = calculateWeekDataByDates(week1Start, week1End);
  const week2Data = calculateWeekDataByDates(week2Start, week2End);
  
  // Renderuj kafelki
  document.getElementById('week1Card').innerHTML = renderWeekCardHTML('Tydzień 1', week1Start, week1End, week1Data);
  document.getElementById('week2Card').innerHTML = renderWeekCardHTML('Tydzień 2', week2Start, week2End, week2Data);
  
  // Dodaj klasy CSS
  const week1Card = document.getElementById('week1Card');
  const week2Card = document.getElementById('week2Card');
  
  week1Card.className = `week-card-payroll ${week1Data.isClosed ? 'week-closed' : 'week-open'}`;
  week2Card.className = `week-card-payroll ${week2Data.isClosed ? 'week-closed' : 'week-open'}`;
  
  // Włącz przycisk tylko jeśli oba tygodnie zamknięte
  const bothClosed = week1Data.isClosed && week2Data.isClosed;
  document.getElementById('generatePayrollBtn').disabled = !bothClosed;
  
  // Wyczyść wyniki
  document.getElementById('payrollResults').innerHTML = '';
}

/**
 * Renderuje HTML kafelka tygodnia
 */
function renderWeekCardHTML(title, startDate, endDate, data) {
  return `
    <div class="week-card-header">
      <h4>${title}</h4>
      <span class="week-status">
        ${data.isClosed ? '✅ Zamknięty' : '⚠️ Niezamknięty'}
      </span>
    </div>
    <div class="week-card-body">
      <div style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 12px;">
        ${formatDatePL(startDate)} - ${formatDatePL(endDate)}
      </div>
      <div class="week-card-row">
        <span>Łączny obrót:</span>
        <strong>${data.totalRevenue.toLocaleString('pl-PL')} zł</strong>
      </div>
      <div class="week-card-row">
        <span>Zwroty:</span>
        <strong style="color: var(--danger);">-${data.totalReturns.toLocaleString('pl-PL')} zł</strong>
      </div>
      <div class="week-card-total">
        <span>Netto:</span>
        <span>${data.netRevenue.toLocaleString('pl-PL')} zł</span>
      </div>
    </div>
  `;
}

/**
 * Oblicza dane tygodnia na podstawie zakresu dat
 */
function calculateWeekDataByDates(startDate, endDate) {
  const days = getLogsFromModule('oplex:obrot:days') || [];
  const weeks = getLogsFromModule('oplex:obrot:weeks') || [];
  const returns = getLogsFromModule('oplex:zwroty:data') || [];
  
  // Filtruj dni z tego zakresu
  const weekDays = days.filter(d => d.date >= startDate && d.date <= endDate);
  
  let totalRevenue = 0;
  weekDays.forEach(day => {
    totalRevenue += (day.shop1 || 0) + (day.shop2 || 0);
  });
  
  // Oblicz zwroty dla tego zakresu
  const weekReturns = returns.filter(r => r.date >= startDate && r.date <= endDate);
  const totalReturns = weekReturns.reduce((sum, r) => sum + (r.amount || 0), 0);
  
  // POPRAWNA LOGIKA: Sprawdź czy TYGODNIE są zamknięte
  let isClosed = false;
  
  if (weekDays.length > 0) {
    // Zbierz unikalne ISO week keys z dni
    const uniqueWeekKeys = [...new Set(weekDays.map(d => d.week))].filter(Boolean);
    
    if (uniqueWeekKeys.length > 0) {
      // Sprawdź czy WSZYSTKIE te tygodnie są zamknięte w module Obrót
      isClosed = uniqueWeekKeys.every(weekKey => {
        const week = weeks.find(w => w.weekKey === weekKey);
        return week && week.status === 'CLOSED';
      });
    }
  }
  // Jeśli brak dni (weekDays.length === 0) → isClosed = false
  
  return {
    totalRevenue,
    totalReturns,
    netRevenue: totalRevenue - totalReturns,
    isClosed: isClosed,
    daysCount: weekDays.length
  };
}

/**
 * Dodaje dni do daty
 */
function addDays(dateStr, days) {
  const d = new Date(dateStr + 'T00:00:00');
  d.setDate(d.getDate() + days);
  return formatDate(d);
}

/**
 * Format daty YYYY-MM-DD
 */
function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Przełącza zakładki Rozliczenie/Historia
 */
function showPayrollTab(tab) {
  if (tab === 'current') {
    document.getElementById('payrollCurrentView').style.display = 'block';
    document.getElementById('payrollHistoryView').style.display = 'none';
    document.getElementById('payrollCurrentTab').classList.add('active');
    document.getElementById('payrollHistoryTab').classList.remove('active');
  } else {
    document.getElementById('payrollCurrentView').style.display = 'none';
    document.getElementById('payrollHistoryView').style.display = 'block';
    document.getElementById('payrollCurrentTab').classList.remove('active');
    document.getElementById('payrollHistoryTab').classList.add('active');
    renderPayrollHistory();
  }
}

/**
 * Renderuje historię rozliczeń
 */
function renderPayrollHistory() {
  const container = document.getElementById('payrollHistoryList');
  const payrolls = getPayrolls().filter(p => p.status === 'CLOSED');
  
  if (payrolls.length === 0) {
    container.innerHTML = `
      <div class="info-box">
        <p>ℹ️ Brak zamkniętych rozliczeń</p>
      </div>
    `;
    return;
  }
  
  payrolls.sort((a, b) => new Date(b.closedAt) - new Date(a.closedAt));
  
  container.innerHTML = payrolls.map(p => {
    const totalPayroll = p.results.reduce((sum, r) => sum + r.finalTotal, 0);
    
    return `
      <div class="payroll-history-item" onclick="viewPayrollDetails('${p.id}')">
        <div class="history-header">
          <div>
            <h4>${formatDatePL(p.periodStart)} - ${formatDatePL(p.periodEnd)}</h4>
            <p>2 tygodnie</p>
          </div>
          <div class="history-amount">${totalPayroll.toLocaleString('pl-PL')} zł</div>
        </div>
        <div class="history-meta">
          Zamknięto: ${new Date(p.closedAt).toLocaleString('pl-PL')} przez ${p.closedBy}
        </div>
      </div>
    `;
  }).join('');
}

/**
 * Pobiera wszystkie rozliczenia
 */
function getPayrolls() {
  const key = 'oplex:admin:payrolls';
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch (e) {
    return [];
  }
}

/**
 * Generuje wypłaty dla bieżącego okresu
 */
function generatePayrollForPeriod() {
  const config = getPayrollConfig();
  
  if (!config || !config.locked) {
    alert('❌ Brak konfiguracji!');
    return;
  }
  
  const periodStart = config.currentPeriodStart;
  const week1Start = periodStart;
  const week1End = addDays(week1Start, 6);
  const week2Start = addDays(week1Start, 7);
  const week2End = addDays(week1Start, 13);
  
  // Sprawdź czy oba tygodnie zamknięte
  const week1Data = calculateWeekDataByDates(week1Start, week1End);
  const week2Data = calculateWeekDataByDates(week2Start, week2End);
  
  if (!week1Data.isClosed || !week2Data.isClosed) {
    alert(
      `❌ TYGODNIE NIEZAMKNIĘTE!\n\n` +
      `Aby wygenerować wypłaty, oba tygodnie muszą być zamknięte.\n\n` +
      `Tydzień 1: ${week1Data.isClosed ? '✅' : '⚠️ Niezamknięty'}\n` +
      `Tydzień 2: ${week2Data.isClosed ? '✅' : '⚠️ Niezamknięty'}\n\n` +
      `Zamknij tygodnie w module Obrót.`
    );
    return;
  }
  
  // Sprawdź czy już istnieje rozliczenie dla tego okresu
  const existingPayroll = getPayrolls().find(p => p.periodStart === periodStart && p.status !== 'CLOSED');
  
  if (existingPayroll) {
    // DRAFT - kontynuuj edycję
    renderPayrollResultsForPeriod(existingPayroll);
    return;
  }
  
  // Pobierz wszystkie dni z okresu
  const allDays = getLogsFromModule('oplex:obrot:days') || [];
  const periodDays = allDays.filter(d => d.date >= week1Start && d.date <= week2End);
  
  // Pobierz aktywnych pracowników
  const employees = getActiveEmployees();
  
  // Oblicz dla każdego pracownika
  const results = employees.map(emp => {
    let totalRevenue = 0;
    let saturdays = [];
    
    periodDays.forEach(day => {
      // Stanowisko 1
      if (day.s1User === emp.username) {
        totalRevenue += (day.shop1 || 0);
        
        if (day.s1Saturday) {
          saturdays.push({
            date: day.date,
            station: 'Stanowisko 1',
            auto: true
          });
        }
      }
      
      // Stanowisko 2
      if (day.s2User === emp.username) {
        totalRevenue += (day.shop2 || 0);
        
        if (day.s2Saturday) {
          saturdays.push({
            date: day.date,
            station: 'Stanowisko 2',
            auto: true
          });
        }
      }
    });
    
    const percentageAmount = Math.round(totalRevenue * (emp.percentage || 0));
    const saturdayBonus = saturdays.length * SATURDAY_RATE;
    const total = percentageAmount + saturdayBonus;
    
    return {
      employee: emp,
      totalRevenue,
      percentageAmount,
      saturdays,
      saturdayBonus,
      total,
      adjustment: 0,
      finalTotal: total
    };
  }).filter(r => r.total > 0);
  
  // Sortuj malejąco
  results.sort((a, b) => b.finalTotal - a.finalTotal);
  
  // Stwórz rozliczenie
  const payrollData = {
    id: Date.now(),
    periodStart: periodStart,
    periodEnd: week2End,
    week1: { start: week1Start, end: week1End, data: week1Data },
    week2: { start: week2Start, end: week2End, data: week2Data },
    saturdayRate: SATURDAY_RATE,
    results: results,
    status: 'DRAFT',
    createdAt: new Date().toISOString(),
    createdBy: getUser()
  };
  
  // Renderuj wyniki
  renderPayrollResultsForPeriod(payrollData);
}

/**
 * Renderuje wyniki wypłat
 */
function renderPayrollResultsForPeriod(payrollData) {
  const container = document.getElementById('payrollResults');
  
  const totalPayroll = payrollData.results.reduce((sum, r) => sum + r.finalTotal, 0);
  
  container.innerHTML = `
    <div style="margin-top: 32px; padding-top: 24px; border-top: 2px solid rgba(59, 130, 246, 0.2);">
      <div class="section-header">
        <h3>👥 Wypłaty pracowników</h3>
        <div style="text-align: right;">
          <div style="font-size: 1.4rem; font-weight: 700; color: var(--success);">
            ${totalPayroll.toLocaleString('pl-PL')} zł
          </div>
          <div style="font-size: 0.9rem; color: var(--text-secondary);">
            Łączna suma
          </div>
        </div>
      </div>
      
      <div class="payroll-grid">
        ${payrollData.results.map((r, idx) => `
          <div class="payroll-card ${r.adjustment !== 0 ? 'has-adjustment' : ''}">
            <div class="payroll-header">
              <div>
                <h4>${r.employee.fullName}</h4>
                <p style="color: var(--text-secondary); font-size: 0.9rem;">
                  ${r.employee.position || 'Pracownik'} • ${(r.employee.percentage * 100).toFixed(1)}% z obrotu
                </p>
              </div>
              <div class="payroll-total">${r.finalTotal.toLocaleString('pl-PL')} zł</div>
            </div>
            
            <div class="payroll-details">
              <div class="payroll-row">
                <span>💰 Obrót obsłużony:</span>
                <strong>${r.totalRevenue.toLocaleString('pl-PL')} zł</strong>
              </div>
              <div class="payroll-row">
                <span>📊 Wypłata ${(r.employee.percentage * 100).toFixed(1)}%:</span>
                <strong>${r.percentageAmount.toLocaleString('pl-PL')} zł</strong>
              </div>
              ${r.saturdays.length > 0 ? `
                <div class="payroll-row saturdays">
                  <span>🗓️ Soboty (${r.saturdays.length}x × ${SATURDAY_RATE} zł):</span>
                  <strong>${r.saturdayBonus.toLocaleString('pl-PL')} zł</strong>
                </div>
                <div class="saturday-list">
                  ${r.saturdays.map(s => `
                    <div class="saturday-item ${s.auto ? 'auto' : 'manual'}">
                      <span>${formatDatePL(s.date)}</span>
                      <span>${s.station}</span>
                      <span class="badge">${s.auto ? 'Auto' : 'Ręczne'}</span>
                    </div>
                  `).join('')}
                </div>
              ` : ''}
              
              <div class="payroll-row adjustment-row">
                <span>⚖️ Korekta (potrącenie/bonus):</span>
                <div style="display: flex; gap: 8px; align-items: center;">
                  <input 
                    type="number" 
                    id="adjustment_${idx}" 
                    value="${r.adjustment || 0}" 
                    style="width: 120px; padding: 6px; background: var(--dark-card); border: 1px solid rgba(59, 130, 246, 0.3); color: var(--text-primary); border-radius: 6px;"
                    onchange="updatePayrollAdjustment(${idx}, ${payrollData.id})"
                  >
                  <span style="color: var(--text-secondary);">zł</span>
                </div>
              </div>
              
              ${r.adjustment !== 0 ? `
                <div class="payroll-row">
                  <span><strong>Końcowa kwota:</strong></span>
                  <strong style="color: var(--success); font-size: 1.1rem;">
                    ${r.finalTotal.toLocaleString('pl-PL')} zł
                  </strong>
                </div>
              ` : ''}
            </div>
          </div>
        `).join('')}
      </div>
      
      <div style="margin-top: 32px; display: flex; gap: 16px; justify-content: flex-end;">
        <button class="btn-secondary" onclick="savePayrollDraft(${payrollData.id})">
          💾 Zapisz roboczą
        </button>
        <button class="btn-primary" onclick="closePayrollPeriod(${payrollData.id})">
          🔒 Zamknij rozliczenie
        </button>
      </div>
    </div>
  `;
}

/**
 * Aktualizuje korektę wypłaty
 */
function updatePayrollAdjustment(resultIndex, payrollId) {
  const payrolls = getPayrolls();
  const payroll = payrolls.find(p => p.id === payrollId);
  
  if (!payroll) return;
  
  const inputValue = Number(document.getElementById(`adjustment_${resultIndex}`).value) || 0;
  
  payroll.results[resultIndex].adjustment = inputValue;
  payroll.results[resultIndex].finalTotal = payroll.results[resultIndex].total + inputValue;
  
  savePayrollToDraft(payroll);
  renderPayrollResultsForPeriod(payroll);
}

/**
 * Zapisuje rozliczenie jako draft
 */
function savePayrollDraft(payrollId) {
  const payrolls = getPayrolls();
  const payroll = payrolls.find(p => p.id === payrollId);
  
  if (!payroll) {
    alert('❌ Nie znaleziono rozliczenia!');
    return;
  }
  
  savePayrollToDraft(payroll);
  alert('✅ Rozliczenie zapisane!');
}

/**
 * Zapisuje rozliczenie do localStorage
 */
function savePayrollToDraft(payrollData) {
  const key = 'oplex:admin:payrolls';
  const payrolls = getPayrolls();
  
  const index = payrolls.findIndex(p => p.id === payrollData.id);
  
  if (index >= 0) {
    payrolls[index] = payrollData;
  } else {
    payrolls.push(payrollData);
  }
  
  localStorage.setItem(key, JSON.stringify(payrolls));
}

/**
 * Zamyka rozliczenie i przechodzi do następnego okresu
 */
function closePayrollPeriod(payrollId) {
  const payrolls = getPayrolls();
  const payroll = payrolls.find(p => p.id === payrollId);
  
  if (!payroll) {
    alert('❌ Nie znaleziono rozliczenia!');
    return;
  }
  
  const totalSum = payroll.results.reduce((s, r) => s + r.finalTotal, 0);
  
  const confirmed = confirm(
    `🔒 ZAMKNIJ ROZLICZENIE\n\n` +
    `Okres: ${formatDatePL(payroll.periodStart)} - ${formatDatePL(payroll.periodEnd)}\n\n` +
    `Suma wypłat: ${totalSum.toLocaleString('pl-PL')} zł\n\n` +
    `Po zamknięciu:\n` +
    `- Rozliczenie przeniesione do historii\n` +
    `- Dodane do kosztów\n` +
    `- Pokazane następne 2 tygodnie\n\n` +
    `Czy zamknąć?`
  );
  
  if (!confirmed) return;
  
  payroll.status = 'CLOSED';
  payroll.closedAt = new Date().toISOString();
  payroll.closedBy = getUser();
  
  savePayrollToDraft(payroll);
  addPayrollToCosts(payroll);
  
  // PRZEJDŹ DO NASTĘPNEGO OKRESU (+14 dni)
  const config = getPayrollConfig();
  const nextPeriodStart = addDays(config.currentPeriodStart, 14);
  
  config.currentPeriodStart = nextPeriodStart;
  localStorage.setItem('oplex:admin:payroll-config', JSON.stringify(config));
  
  alert('✅ Rozliczenie zamknięte!\n\nPrzechodzimy do następnego okresu.');
  
  // Odśwież widok
  renderPayroll();
  
  // Przełącz na historię aby pokazać zamknięte
  setTimeout(() => {
    showPayrollTab('history');
  }, 500);
}

/**
 * Dodaje rozliczenie do kosztów
 */
function addPayrollToCosts(payrollData) {
  const costs = getLogsFromModule('oplex:admin:costs') || [];
  const totalPayroll = payrollData.results.reduce((s, r) => s + r.finalTotal, 0);
  
  costs.push({
    id: Date.now(),
    date: payrollData.closedAt.split('T')[0],
    type: 'PAYROLL',
    category: 'Wynagrodzenia',
    amount: totalPayroll,
    description: `Wypłaty ${formatDatePL(payrollData.periodStart)} - ${formatDatePL(payrollData.periodEnd)}`,
    payrollId: payrollData.id,
    createdAt: payrollData.closedAt,
    createdBy: payrollData.closedBy
  });
  
  localStorage.setItem('oplex:admin:costs', JSON.stringify(costs));
}
function calculateStorageUsage() {
  let total = 0;
  
  for (let key in localStorage) {
    if (localStorage.hasOwnProperty(key)) {
      total += localStorage[key].length + key.length;
    }
  }
  
  const kb = (total / 1024).toFixed(2);
  document.getElementById('storageUsage').textContent = kb + ' KB';
}

/**
 * Eksportuje wszystkie dane systemu
 */
function exportAllData() {
  try {
    const data = {
      version: '3.0.0',
      exportDate: new Date().toISOString(),
      employees: exportEmployees(),
      localStorage: {}
    };
    
    // Eksportuj wszystkie klucze localStorage
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        try {
          data.localStorage[key] = JSON.parse(localStorage[key]);
        } catch (e) {
          data.localStorage[key] = localStorage[key];
        }
      }
    }
    
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `oplex-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    
    alert('✅ Backup został pobrany!');
  } catch (e) {
    console.error('Błąd exportu:', e);
    alert('❌ Błąd podczas exportu danych!');
  }
}

/**
 * Importuje dane systemu
 */
function importAllData() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  
  input.onchange = function(e) {
    const file = e.target.files[0];
    
    if (!file) return;
    
    const reader = new FileReader();
    
    reader.onload = function(event) {
      try {
        const data = JSON.parse(event.target.result);
        
        if (!confirm('⚠️ UWAGA!\n\nImport nadpisze wszystkie obecne dane!\n\nCzy na pewno kontynuować?')) {
          return;
        }
        
        // Import employees
        if (data.employees) {
          importEmployees(data.employees);
        }
        
        // Import localStorage
        if (data.localStorage) {
          for (let key in data.localStorage) {
            localStorage.setItem(key, JSON.stringify(data.localStorage[key]));
          }
        }
        
        alert('✅ Import zakończony!\n\nStrona zostanie odświeżona.');
        window.location.reload();
      } catch (e) {
        console.error('Błąd importu:', e);
        alert('❌ Błąd podczas importu danych!\n\nSprawdź czy plik jest prawidłowy.');
      }
    };
    
    reader.readAsText(file);
  };
  
  input.click();
}

/**
 * Resetuje cały system
 */
function resetSystem() {
  if (!confirm('⚠️ UWAGA! OPERACJA NIEODWRACALNA!\n\nCzy na pewno chcesz zresetować cały system?\n\nWszystkie dane zostaną usunięte!')) {
    return;
  }
  
  const secondConfirm = prompt('Wpisz "RESET" aby potwierdzić:');
  
  if (secondConfirm !== 'RESET') {
    alert('❌ Anulowano reset.');
    return;
  }
  
  localStorage.clear();
  alert('✅ System został zresetowany!\n\nStrona zostanie odświeżona.');
  window.location.reload();
}

/**
 * Renderuje zakładkę kosztów
 */
function renderCosts() {
  // Placeholder - moduł do rozbudowy w przyszłości
  console.log('Moduł Koszty - w przygotowaniu');
}

/* ==========================================
   TAB: AUDIT (LOGS)
   ========================================== */

/**
 * Odświeża logi audytowe - agreguje logi z wszystkich modułów
 */
function refreshAdminLogs() {
  const container = document.getElementById('adminLogsContainer');
  
  if (!container) return;
  
  // Pobierz logi z wszystkich modułów
  const obrotLogs = getLogsFromModule('oplex:obrot:logs') || [];
  const zwrotyLogs = getLogsFromModule('oplex:zwroty:logs') || [];
  
  // Połącz i posortuj po timestamp
  const allLogs = [...obrotLogs, ...zwrotyLogs]
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 100); // Ostatnie 100 logów
  
  if (allLogs.length === 0) {
    container.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 40px;">Brak logów w systemie</p>';
    return;
  }
  
  container.innerHTML = allLogs.map(log => `
    <div class="log-entry">
      <div class="log-header">
        <span class="log-time">${formatDateTime(log.timestamp)}</span>
        <span class="log-module log-module-${(log.module || 'SYSTEM').toLowerCase()}">${log.module || 'SYSTEM'}</span>
        <span class="log-action">${formatLogAction(log.action)}</span>
      </div>
      <div class="log-details">
        <span class="log-user">👤 ${log.user}</span>
        ${log.data ? `<span class="log-data">${formatLogData(log.data)}</span>` : ''}
      </div>
    </div>
  `).join('');
}

/**
 * Pobiera logi z modułu
 */
function getLogsFromModule(key) {
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch (e) {
    return [];
  }
}

/**
 * Formatuje akcję loga
 */
function formatLogAction(action) {
  const actions = {
    // Admin
    'ADMIN_LOGIN': '🔓 Logowanie admin',
    'ADMIN_LOGOUT': '🔒 Wylogowanie admin',
    'ADMIN_AUTO_LOGOUT': '⏱️ Auto-wylogowanie',
    'ADMIN_SESSION_EXTENDED': '⏱️ Przedłużenie sesji',
    'ADMIN_PASSWORD_CHANGED': '🔑 Zmiana hasła',
    'EMPLOYEE_ADDED': '➕ Dodano pracownika',
    'EMPLOYEE_UPDATED': '✏️ Aktualizacja pracownika',
    // Obrót
    'CLOSE_WEEK': '📊 Zamknięto tydzień',
    'CLOSE_STATION': '✅ Zamknięto stanowisko',
    // Zwroty
    'RETURN_ADDED': '📦 Dodano zwrot',
    'RETURN_EDITED': '✏️ Edytowano zwrot',
    'RETURN_DELETED': '🗑️ Usunięto zwrot'
  };
  
  return actions[action] || action;
}

/**
 * Formatuje dane loga
 */
function formatLogData(data) {
  if (typeof data === 'string') return data;
  
  const parts = [];
  
  // Admin / Pracownicy
  if (data.username) parts.push(`Login: ${data.username}`);
  if (data.role) parts.push(`Rola: ${data.role}`);
  
  // Obrót
  if (data.weekKey) parts.push(`Tydzień: ${data.weekKey}`);
  if (data.total) parts.push(`Kwota: ${data.total} zł`);
  
  // Zwroty
  if (data.customer) parts.push(`Klient: ${data.customer}`);
  if (data.amount) parts.push(`Kwota: ${data.amount} zł`);
  if (data.type) parts.push(`Typ: ${data.type}`);
  if (data.returnId) parts.push(`ID: #${String(data.returnId).slice(-6)}`);
  
  return parts.join(' • ');
}

/* ==========================================
   UTILITY
   ========================================== */

/**
 * Formatuje datę (DD.MM.YYYY)
 */
function formatDatePL(dateStr) {
  if (!dateStr) return '---';
  
  const [year, month, day] = dateStr.split('-');
  return `${day}.${month}.${year}`;
}

/**
 * Formatuje datę i czas
 */
function formatDateTime(timestamp) {
  const date = new Date(timestamp);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  
  return `${day}.${month}.${year} ${hours}:${minutes}`;
}

/* ==========================================
   INIT
   ========================================== */

/**
 * Aktualizuje timer admina w topbarze
 */
function updateAdminTimerUI() {
  const timerElement = document.getElementById('adminTimer');
  const userNameElement = document.getElementById('userName');
  
  if (!timerElement) return;
  
  // Sprawdź czy jest aktywna sesja admin
  if (typeof checkAdminSession === 'function') {
    const isAdmin = checkAdminSession();
    
    if (isAdmin && typeof getAdminTimeRemaining === 'function') {
      const remaining = getAdminTimeRemaining();
      
      if (remaining > 0) {
        const minutes = Math.floor(remaining / 60);
        const seconds = remaining % 60;
        timerElement.textContent = `${minutes}:${String(seconds).padStart(2, '0')}`;
      } else {
        timerElement.textContent = 'Wygasła';
      }
    } else {
      timerElement.textContent = '--:--';
    }
  }
  
  // Aktualizuj nazwę użytkownika
  if (userNameElement && typeof getEmployeeByUsername === 'function' && typeof getUser === 'function') {
    const employee = getEmployeeByUsername(getUser());
    if (employee) {
      userNameElement.textContent = employee.fullName;
    } else {
      userNameElement.textContent = getUser();
    }
  }
}

/**
 * Inicjalizacja UI
 */
function initAdminUI() {
  // Update session info
  const sessionUser = document.getElementById('sessionUser');
  if (sessionUser) {
    const employee = getEmployeeByUsername(getUser());
    sessionUser.textContent = employee ? employee.fullName : getUser();
  }
  
  // Update timer
  updateAdminTimerUI();
  setInterval(updateAdminTimerUI, 1000); // Co sekundę
  
  // Render initial view
  renderEmployeesList();
  calculateStorageUsage();
}

/**
 * Generuje wypłaty dla bieżącego okresu
 */
function generatePayrollForPeriod() {
  if (payrollPeriods.length === 0) {
    alert('❌ Brak okresów do rozliczenia!');
    return;
  }
  
  const period = payrollPeriods[currentPayrollPeriodIndex];
  
  // Sprawdź czy oba tygodnie są zamknięte
  const week1Closed = period.week1.status === 'CLOSED';
  const week2Closed = period.week2.status === 'CLOSED';
  
  if (!week1Closed || !week2Closed) {
    alert(
      `❌ TYGODNIE NIEZAMKNIĘTE!\n\n` +
      `Aby wygenerować wypłaty, oba tygodnie muszą być zamknięte.\n\n` +
      `${period.week1.weekKey}: ${week1Closed ? '✅' : '⚠️ Niezamknięty'}\n` +
      `${period.week2.weekKey}: ${week2Closed ? '✅' : '⚠️ Niezamknięty'}\n\n` +
      `Zamknij tygodnie w module Obrót.`
    );
    return;
  }
  
  // Sprawdź czy już istnieje rozliczenie dla tego okresu
  const existingPayroll = getPayrolls().find(p => p.periodId === period.id);
  
  if (existingPayroll) {
    if (existingPayroll.status === 'CLOSED') {
      alert(`❌ Ten okres został już rozliczony i zamknięty!`);
      showPayrollTab('history');
      return;
    }
    
    // DRAFT - kontynuuj edycję
    renderPayrollResultsForPeriod(existingPayroll);
    return;
  }
  
  // Pobierz dane z obu tygodni
  const week1Data = calculateWeekData(period.week1.weekKey);
  const week2Data = calculateWeekData(period.week2.weekKey);
  
  const week1Range = getWeekDateRangeObj(period.week1.weekKey);
  const week2Range = getWeekDateRangeObj(period.week2.weekKey);
  
  // Pobierz wszystkie dni z obu tygodni
  const allDays = getLogsFromModule('oplex:obrot:days') || [];
  const periodDays = allDays.filter(d => 
    d.week === period.week1.weekKey || d.week === period.week2.weekKey
  );
  
  // Pobierz aktywnych pracowników
  const employees = getActiveEmployees();
  
  // Oblicz dla każdego pracownika
  const results = employees.map(emp => {
    let totalRevenue = 0;
    let saturdays = [];
    
    periodDays.forEach(day => {
      // Stanowisko 1
      if (day.s1User === emp.username) {
        totalRevenue += (day.shop1 || 0);
        
        if (day.s1Saturday) {
          saturdays.push({
            date: day.date,
            station: 'Stanowisko 1',
            auto: true
          });
        }
      }
      
      // Stanowisko 2
      if (day.s2User === emp.username) {
        totalRevenue += (day.shop2 || 0);
        
        if (day.s2Saturday) {
          saturdays.push({
            date: day.date,
            station: 'Stanowisko 2',
            auto: true
          });
        }
      }
    });
    
    // Pobierz ręcznie dodane soboty (sprawdź oba tygodnie)
    const manualSats1 = getManualSaturdays(emp.username, period.week1.weekKey);
    const manualSats2 = getManualSaturdays(emp.username, period.week2.weekKey);
    const allManualSats = [...manualSats1, ...manualSats2];
    
    saturdays = [...saturdays, ...allManualSats.map(s => ({
      date: s.date,
      station: s.note || 'Pomoc',
      auto: false
    }))];
    
    const percentageAmount = Math.round(totalRevenue * (emp.percentage || 0));
    const saturdayBonus = saturdays.length * SATURDAY_RATE;
    const total = percentageAmount + saturdayBonus;
    
    return {
      employee: emp,
      totalRevenue,
      percentageAmount,
      saturdays,
      saturdayBonus,
      total,
      adjustment: 0,
      finalTotal: total
    };
  }).filter(r => r.total > 0);
  
  // Sortuj malejąco
  results.sort((a, b) => b.finalTotal - a.finalTotal);
  
  // Stwórz rozliczenie
  const payrollData = {
    id: Date.now(),
    periodId: period.id,
    week1Key: period.week1.weekKey,
    week2Key: period.week2.weekKey,
    dateRange: {
      start: week1Range.start,
      end: week2Range.end
    },
    week1Data: week1Data,
    week2Data: week2Data,
    saturdayRate: SATURDAY_RATE,
    results: results,
    status: 'DRAFT',
    createdAt: new Date().toISOString(),
    createdBy: getUser()
  };
  
  // Renderuj wyniki
  renderPayrollResultsForPeriod(payrollData);
}

/**
 * Renderuje wyniki wypłat dla okresu
 */
function renderPayrollResultsForPeriod(payrollData) {
  const container = document.getElementById('payrollResults');
  
  const totalPayroll = payrollData.results.reduce((sum, r) => sum + r.finalTotal, 0);
  
  container.innerHTML = `
    <div style="margin-top: 32px; padding-top: 24px; border-top: 2px solid rgba(59, 130, 246, 0.2);">
      <div class="section-header">
        <h3>👥 Wypłaty pracowników</h3>
        <div style="text-align: right;">
          <div style="font-size: 1.4rem; font-weight: 700; color: var(--success);">
            ${totalPayroll.toLocaleString('pl-PL')} zł
          </div>
          <div style="font-size: 0.9rem; color: var(--text-secondary);">
            Łączna suma
          </div>
        </div>
      </div>
      
      <div class="payroll-grid">
        ${payrollData.results.map((r, idx) => `
          <div class="payroll-card ${r.adjustment !== 0 ? 'has-adjustment' : ''}">
            <div class="payroll-header">
              <div>
                <h4>${r.employee.fullName}</h4>
                <p style="color: var(--text-secondary); font-size: 0.9rem;">
                  ${r.employee.position || 'Pracownik'} • ${(r.employee.percentage * 100).toFixed(1)}% z obrotu
                </p>
              </div>
              <div class="payroll-total">${r.finalTotal.toLocaleString('pl-PL')} zł</div>
            </div>
            
            <div class="payroll-details">
              <div class="payroll-row">
                <span>💰 Obrót obsłużony:</span>
                <strong>${r.totalRevenue.toLocaleString('pl-PL')} zł</strong>
              </div>
              <div class="payroll-row">
                <span>📊 Wypłata ${(r.employee.percentage * 100).toFixed(1)}%:</span>
                <strong>${r.percentageAmount.toLocaleString('pl-PL')} zł</strong>
              </div>
              ${r.saturdays.length > 0 ? `
                <div class="payroll-row saturdays">
                  <span>🗓️ Soboty (${r.saturdays.length}x × ${SATURDAY_RATE} zł):</span>
                  <strong>${r.saturdayBonus.toLocaleString('pl-PL')} zł</strong>
                </div>
                <div class="saturday-list">
                  ${r.saturdays.map(s => `
                    <div class="saturday-item ${s.auto ? 'auto' : 'manual'}">
                      <span>${s.date}</span>
                      <span>${s.station}</span>
                      <span class="badge">${s.auto ? 'Auto' : 'Ręczne'}</span>
                    </div>
                  `).join('')}
                </div>
              ` : ''}
              
              <div class="payroll-row adjustment-row">
                <span>⚖️ Korekta (potrącenie/bonus):</span>
                <div style="display: flex; gap: 8px; align-items: center;">
                  <input 
                    type="number" 
                    id="adjustment_${idx}" 
                    value="${r.adjustment || 0}" 
                    style="width: 120px; padding: 6px; background: var(--dark-card); border: 1px solid rgba(59, 130, 246, 0.3); color: var(--text-primary); border-radius: 6px;"
                    onchange="updatePayrollAdjustment(${idx}, ${payrollData.id})"
                  >
                  <span style="color: var(--text-secondary);">zł</span>
                </div>
              </div>
              
              ${r.adjustment !== 0 ? `
                <div class="payroll-row">
                  <span><strong>Końcowa kwota:</strong></span>
                  <strong style="color: var(--success); font-size: 1.1rem;">
                    ${r.finalTotal.toLocaleString('pl-PL')} zł
                  </strong>
                </div>
              ` : ''}
            </div>
          </div>
        `).join('')}
      </div>
      
      <div style="margin-top: 32px; display: flex; gap: 16px; justify-content: flex-end;">
        <button class="btn-secondary" onclick="savePayrollDraft(${payrollData.id})">
          💾 Zapisz roboczą
        </button>
        <button class="btn-primary" onclick="closePayrollPeriod(${payrollData.id})">
          🔒 Zamknij rozliczenie
        </button>
      </div>
    </div>
  `;
}

/**
 * Aktualizuje korektę wypłaty
 */
function updatePayrollAdjustment(resultIndex, payrollId) {
  const payrolls = getPayrolls();
  const payroll = payrolls.find(p => p.id === payrollId);
  
  if (!payroll) return;
  
  const inputValue = Number(document.getElementById(`adjustment_${resultIndex}`).value) || 0;
  
  payroll.results[resultIndex].adjustment = inputValue;
  payroll.results[resultIndex].finalTotal = payroll.results[resultIndex].total + inputValue;
  
  savePayrollToDraft(payroll);
  renderPayrollResultsForPeriod(payroll);
}

/**
 * Zapisuje rozliczenie jako draft
 */
function savePayrollDraft(payrollId) {
  const payrolls = getPayrolls();
  let payroll = payrolls.find(p => p.id === payrollId);
  
  if (!payroll) {
    // Znajdź w bieżącym okresie
    const period = payrollPeriods[currentPayrollPeriodIndex];
    // Tutaj trzeba by odtworzyć payrollData, ale na razie zakładamy że istnieje
    alert('❌ Nie znaleziono rozliczenia!');
    return;
  }
  
  savePayrollToDraft(payroll);
  alert('✅ Rozliczenie zapisane!');
}

/**
 * Zapisuje rozliczenie do localStorage
 */
function savePayrollToDraft(payrollData) {
  const key = 'oplex:admin:payrolls';
  const payrolls = getPayrolls();
  
  const index = payrolls.findIndex(p => p.id === payrollData.id);
  
  if (index >= 0) {
    payrolls[index] = payrollData;
  } else {
    payrolls.push(payrollData);
  }
  
  localStorage.setItem(key, JSON.stringify(payrolls));
}

/**
 * Zamyka rozliczenie okresu
 */
function closePayrollPeriod(payrollId) {
  const payrolls = getPayrolls();
  const payroll = payrolls.find(p => p.id === payrollId);
  
  if (!payroll) {
    alert('❌ Nie znaleziono rozliczenia!');
    return;
  }
  
  const totalSum = payroll.results.reduce((s, r) => s + r.finalTotal, 0);
  
  const confirmed = confirm(
    `🔒 ZAMKNIJ ROZLICZENIE\n\n` +
    `Okres: ${payroll.week1Key} + ${payroll.week2Key}\n` +
    `${payroll.dateRange.start} - ${payroll.dateRange.end}\n\n` +
    `Suma wypłat: ${totalSum.toLocaleString('pl-PL')} zł\n\n` +
    `Po zamknięciu rozliczenie zostanie przeniesione do historii i kosztów.\n\n` +
    `Czy zamknąć?`
  );
  
  if (!confirmed) return;
  
  payroll.status = 'CLOSED';
  payroll.closedAt = new Date().toISOString();
  payroll.closedBy = getUser();
  
  savePayrollToDraft(payroll);
  addPayrollToCosts(payroll);
  
  alert('✅ Rozliczenie zamknięte i dodane do kosztów!');
  
  // Przełącz na historię
  showPayrollTab('history');
  
  // Odśwież okresy
  loadPayrollPeriods();
  renderPayrollPeriod();
}

/**
 * Dodaje rozliczenie do kosztów
 */
function addPayrollToCosts(payrollData) {
  const costs = getLogsFromModule('oplex:admin:costs') || [];
  const totalPayroll = payrollData.results.reduce((s, r) => s + r.finalTotal, 0);
  
  costs.push({
    id: Date.now(),
    date: payrollData.closedAt.split('T')[0],
    type: 'PAYROLL',
    category: 'Wynagrodzenia',
    amount: totalPayroll,
    description: `Wypłaty ${payrollData.week1Key} + ${payrollData.week2Key} (${payrollData.dateRange.start} - ${payrollData.dateRange.end})`,
    payrollId: payrollData.id,
    createdAt: payrollData.closedAt,
    createdBy: payrollData.closedBy
  });
  
  localStorage.setItem('oplex:admin:costs', JSON.stringify(costs));
}

/**
 * Pobierz ręcznie dodane soboty dla tygodnia
 */
function getManualSaturdays(username, weekKey) {
  const key = 'oplex:admin:manual-saturdays';
  const saturdays = JSON.parse(localStorage.getItem(key) || '[]');
  
  const weekRange = getWeekDateRangeObj(weekKey);
  if (!weekRange) return [];
  
  return saturdays.filter(s => 
    s.username === username && 
    s.date >= weekRange.start && 
    s.date <= weekRange.end
  );
}
