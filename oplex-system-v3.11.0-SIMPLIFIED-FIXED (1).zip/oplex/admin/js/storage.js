/* ==========================================
   SUPER-ADMIN - STORAGE
   Oplex Management System
   Version: 1.0.0
   ========================================== */

const PAYROLL_KEY = "oplex:admin:payroll";
const COSTS_KEY = "oplex:admin:costs";

/* ===================== HELPERS ===================== */

function loadJSON(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function saveJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ===================== PAYROLL ===================== */

/**
 * Pobiera historię wypłat
 * @returns {array}
 */
function getPayrollHistory() {
  return loadJSON(PAYROLL_KEY, []);
}

/**
 * Dodaje wypłatę do historii
 * @param {object} payrollData
 */
function addPayroll(payrollData) {
  const history = getPayrollHistory();
  
  const payroll = {
    id: "pay_" + Date.now(),
    period: payrollData.period, // np. "2026-W01-W02"
    employees: payrollData.employees, // [{username, amount, bonuses}]
    totalAmount: payrollData.totalAmount,
    createdAt: new Date().toISOString(),
    createdBy: getUser()
  };
  
  history.push(payroll);
  saveJSON(PAYROLL_KEY, history);
  
  return payroll;
}

/**
 * Pobiera wypłaty dla pracownika
 * @param {string} username
 * @returns {array}
 */
function getEmployeePayrolls(username) {
  const history = getPayrollHistory();
  return history.filter(p => 
    p.employees.some(e => e.username === username)
  );
}

/* ===================== COSTS ===================== */

/**
 * Pobiera koszty
 * @returns {array}
 */
function getCosts() {
  return loadJSON(COSTS_KEY, []);
}

/**
 * Dodaje koszt
 * @param {object} costData
 */
function addCost(costData) {
  const costs = getCosts();
  
  const cost = {
    id: "cost_" + Date.now(),
    category: costData.category, // np. "wynajem", "media", "towar"
    amount: costData.amount,
    description: costData.description,
    date: costData.date,
    createdAt: new Date().toISOString(),
    createdBy: getUser()
  };
  
  costs.push(cost);
  saveJSON(COSTS_KEY, costs);
  
  return cost;
}

/**
 * Pobiera koszty za okres
 * @param {string} startDate
 * @param {string} endDate
 * @returns {array}
 */
function getCostsByPeriod(startDate, endDate) {
  const costs = getCosts();
  return costs.filter(c => 
    c.date >= startDate && c.date <= endDate
  );
}

/**
 * Oblicza sumę kosztów za okres
 * @param {string} startDate
 * @param {string} endDate
 * @returns {number}
 */
function getTotalCosts(startDate, endDate) {
  const costs = getCostsByPeriod(startDate, endDate);
  return costs.reduce((sum, c) => sum + c.amount, 0);
}
