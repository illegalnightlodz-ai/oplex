/* ===============================
   OPLEX – STORAGE (ZWROTY)
   v3.0.1
   =============================== */

const STORAGE_KEY = "oplex:zwroty:data";
const LOGS_KEY = "oplex:zwroty:logs";

/* ===============================
   DANE ZWROTÓW
   =============================== */

function loadData() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch (e) {
    console.error("Błąd odczytu danych zwrotów", e);
    return [];
  }
}

function saveData(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

/* ===============================
   LOGI AUDYTOWE
   =============================== */

function addLog(action, data = {}) {
  try {
    const logs = JSON.parse(localStorage.getItem(LOGS_KEY)) || [];
    
    logs.push({
      id: Date.now(),
      timestamp: new Date().toISOString(),
      user: getCurrentUser() || "SYSTEM",
      action: action,
      data: data,
      module: "ZWROTY"
    });
    
    // Zachowaj maksymalnie 1000 ostatnich logów
    if (logs.length > 1000) {
      logs.splice(0, logs.length - 1000);
    }
    
    localStorage.setItem(LOGS_KEY, JSON.stringify(logs));
  } catch (e) {
    console.error("Błąd zapisu logu:", e);
  }
}

function getLogs(limit = 100) {
  try {
    const logs = JSON.parse(localStorage.getItem(LOGS_KEY)) || [];
    return logs.slice(-limit).reverse();
  } catch (e) {
    console.error("Błąd odczytu logów:", e);
    return [];
  }
}

function getRecentLogs(count = 50) {
  return getLogs(count);
}

/* ===============================
   UŻYTKOWNIK – GLOBALNY
   =============================== */

function getCurrentUser() {
  return localStorage.getItem("oplex_user");
}

/* ===============================
   KOMPATYBILNOŚĆ WSTECZNA
   =============================== */

(function migrateOldData() {
  const oldKey = "zwrotyData";
  const oldData = localStorage.getItem(oldKey);

  if (oldData && !localStorage.getItem(STORAGE_KEY)) {
    console.warn("Migracja danych zwrotów ze starego klucza");
    localStorage.setItem(STORAGE_KEY, oldData);
  }
})();
