function getWeekKey(dateString) {
  const date = new Date(dateString);
  date.setHours(0, 0, 0, 0);

  // ISO week date weeks start on Monday
  // Set to nearest Thursday: current date + 4 - current day number
  // Make Sunday's day number 7
  const dayNr = (date.getDay() + 6) % 7;
  date.setDate(date.getDate() - dayNr + 3);

  // January 4th is always in week 1
  const firstThursday = new Date(date.getFullYear(), 0, 4);

  const diff = date - firstThursday;
  const week = 1 + Math.round(diff / (7 * 24 * 60 * 60 * 1000));

  return `${date.getFullYear()}-W${String(week).padStart(2, "0")}`;
}

function getCurrentWeekKey() {
  return getWeekKey(new Date().toISOString().slice(0, 10));
}

function getMonthKey(date) {
  return date.slice(0, 7);
}

function getWeekDateRange(weekKey) {
  const [year, week] = weekKey.split("-W").map(Number);

  // ISO 8601: tydzień 1 zawiera 4 stycznia
  const jan4 = new Date(year, 0, 4);
  const jan4Day = (jan4.getDay() + 6) % 7;

  // poniedziałek danego tygodnia
  const monday = new Date(jan4);
  monday.setDate(jan4.getDate() - jan4Day + (week - 1) * 7);

  // niedziela
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  const formatLocal = d => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  };

  return `${formatLocal(monday)} – ${formatLocal(sunday)}`;
}