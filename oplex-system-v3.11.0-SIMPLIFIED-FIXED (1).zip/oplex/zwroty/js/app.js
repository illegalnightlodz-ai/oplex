/* ===============================
   OPLEX – ZWROTY
   v3.0.1
   =============================== */

// ================= DATA / STATE =================
let data = loadData();
let statsChart = null;
let currentUser = getCurrentUser();

// ================= UI =================
const userInput = document.getElementById("user");
const amountInput = document.getElementById("amount");
const typeInput = document.getElementById("type");

const weekSelect = document.getElementById("weekSelect");
const monthSelect = document.getElementById("monthSelect");
const yearSelect = document.getElementById("yearSelect");

const weekTable = document.getElementById("weekTable");
const monthTable = document.getElementById("monthTable");
const yearTable = document.getElementById("yearTable");

const weekStats = document.getElementById("weekStats");
const monthStats = document.getElementById("monthStats");
const statsContent = document.getElementById("statsContent");

const weekSearch = document.getElementById("weekSearch");
const monthSearch = document.getElementById("monthSearch");
const yearSearch = document.getElementById("yearSearch");
const yearTableSelect = document.getElementById("yearTableSelect");

// ================= EVENTS =================
document.getElementById("addBtn").onclick = addEntry;
weekSelect.onchange = renderWeek;
monthSelect.onchange = renderMonth;

if (weekSearch) weekSearch.oninput = renderWeek;
if (monthSearch) monthSearch.oninput = renderMonth;
if (yearSearch) yearSearch.oninput = renderYear;
if (yearTableSelect) yearTableSelect.onchange = renderYear;

// ================= ADD =================
function addEntry() {
  if (!currentUser) return alert("Zaloguj się");
  if (!userInput.value || !amountInput.value) return;

  const now = new Date();
  const date = now.toISOString().slice(0, 10);
  const time = now.toTimeString().slice(0, 8); // HH:MM:SS

  const entry = {
    id: Date.now(),
    user: userInput.value,
    addedBy: currentUser,
    date,
    time, // NOWE: godzina dodania
    amount: Number(amountInput.value),
    type: typeInput.value || "-",
    week: getWeekKey(date),
    month: getMonthKey(date)
  };

  data.push(entry);
  saveData(data);
  
  // LOG
  addLog("RETURN_ADDED", {
    returnId: entry.id,
    customer: entry.user,
    amount: entry.amount,
    type: entry.type
  });
  
  clearForm();
  reload();
}

// ================= EDIT / DELETE =================
function editEntry(id) {
  const e = data.find(x => x.id === id);
  if (!e) return;

  const user = prompt("Klient:", e.user);
  const amount = prompt("Kwota:", e.amount);
  const type = prompt("Opis:", e.type);

  if (user && !isNaN(amount)) {
    const oldData = { ...e };
    
    e.user = user;
    e.amount = Number(amount);
    e.type = type || "-";
    e.editedAt = new Date().toISOString();
    e.editedBy = currentUser;
    
    saveData(data);
    
    // LOG
    addLog("RETURN_EDITED", {
      returnId: id,
      customer: e.user,
      amount: e.amount,
      oldAmount: oldData.amount
    });
    
    reload();
  }
}

function deleteEntry(id) {
  if (!confirm("Usunąć wpis?")) return;
  
  const e = data.find(x => x.id === id);
  
  data = data.filter(e => e.id !== id);
  saveData(data);
  
  // LOG
  addLog("RETURN_DELETED", {
    returnId: id,
    customer: e?.user,
    amount: e?.amount
  });
  
  reload();
}

// ================= HELPERS =================
function clearForm() {
  userInput.value = "";
  amountInput.value = "";
  typeInput.value = "";
}

function reload() {
  loadSelectors();
  renderWeek();
  renderMonth();
  renderYear();
  if (document.getElementById("statsView").style.display !== "none") {
    loadYears();
    renderStats();
  }
}

// ================= SELECTORS =================
function loadSelectors() {
  const currentWeek = getCurrentWeekKey();
  let weeks = [...new Set(data.map(d => d.week))];
  if (!weeks.includes(currentWeek)) weeks.push(currentWeek);
  weeks.sort();

  weekSelect.innerHTML = weeks.map(w => `<option>${w}</option>`).join("");
  weekSelect.value = currentWeek;

  let months = [...new Set(data.map(d => d.month))].sort();
  monthSelect.innerHTML = months.map(m => `<option>${m}</option>`).join("");

  let years = [...new Set(data.map(d => d.date.slice(0, 4)))].sort();
  if (yearTableSelect)
    yearTableSelect.innerHTML = years.map(y => `<option>${y}</option>`).join("");
}

// ================= STATS HELPERS =================
function calcStats(rows) {
  const sum = rows.reduce((a, b) => a + b.amount, 0);
  return {
    count: rows.length,
    sum,
    avg: rows.length ? (sum / rows.length).toFixed(2) : 0,
    max: rows.length ? Math.max(...rows.map(r => r.amount)) : 0,
    min: rows.length ? Math.min(...rows.map(r => r.amount)) : 0
  };
}

// ================= WEEK VIEW =================
function renderWeek() {
  const week = weekSelect.value;
  document.getElementById("weekRange").innerText = `(${getWeekDateRange(week)})`;
  const q = weekSearch?.value.toLowerCase() || "";

  const rows = data.filter(d =>
    d.week === week &&
    (d.user + d.type + (d.addedBy || "")).toLowerCase().includes(q)
  );

  weekTable.innerHTML = rows.map(r => `
    <tr>
      <td>${r.user}</td>
      <td>${r.date} ${r.time || ''}</td>
      <td>${r.amount} zł</td>
      <td>${r.type}</td>
      <td>${getDisplayName(r.addedBy) || "-"}</td>
      <td>
        <button onclick="editEntry(${r.id})">✏️</button>
        <button onclick="deleteEntry(${r.id})">🗑️</button>
      </td>
    </tr>
  `).join("");

  const s = calcStats(rows);
  weekStats.innerText = `Zwroty: ${s.count} | Suma: ${s.sum} zł`;
}

// ================= MONTH VIEW =================
function renderMonth() {
  const month = monthSelect.value;
  const q = monthSearch?.value.toLowerCase() || "";

  const rows = data.filter(d =>
    d.month === month &&
    (d.user + d.type + (d.addedBy || "")).toLowerCase().includes(q)
  );

  monthTable.innerHTML = rows.map(r => `
    <tr>
      <td>${r.date} ${r.time || ''}</td>
      <td>${r.user}</td>
      <td>${r.amount} zł</td>
      <td>${r.type}</td>
      <td>${getDisplayName(r.addedBy) || "-"}</td>
      <td>
        <button onclick="editEntry(${r.id})">✏️</button>
        <button onclick="deleteEntry(${r.id})">🗑️</button>
      </td>
    </tr>
  `).join("");

  const s = calcStats(rows);
  monthStats.innerText = `Zwroty: ${s.count} | Suma: ${s.sum} zł`;
}

// ================= YEAR VIEW =================
function renderYear() {
  if (!yearTableSelect) return;
  const year = yearTableSelect.value;
  const q = yearSearch?.value.toLowerCase() || "";

  const rows = data
    .filter(d => d.date.startsWith(year))
    .filter(d => (d.user + d.type + (d.addedBy || "")).toLowerCase().includes(q))
    .sort((a, b) => a.date.localeCompare(b.date));

  yearTable.innerHTML = rows.map(r => `
    <tr>
      <td>${r.date} ${r.time || ''}</td>
      <td>${r.week}</td>
      <td>${r.user}</td>
      <td>${r.amount} zł</td>
      <td>${r.type}</td>
      <td>${getDisplayName(r.addedBy) || "-"}</td>
    </tr>
  `).join("");
}

// ================= STATISTICS =================
function loadYears() {
  const years = [...new Set(data.map(d => d.date.slice(0, 4)))].sort();
  yearSelect.innerHTML = years.map(y => `<option>${y}</option>`).join("");
  yearSelect.onchange = renderStats;
}

function renderStats() {
  const year = yearSelect.value;
  const yearData = data.filter(d => d.date.startsWith(year));
  let html = "", yearSum = 0;

  for (let m = 1; m <= 12; m++) {
    const month = `${year}-${String(m).padStart(2, "0")}`;
    const rows = yearData.filter(d => d.month === month);
    if (!rows.length) continue;

    const weeks = {};
    rows.forEach(d => {
      yearSum += d.amount;
      weeks[d.week] = (weeks[d.week] || 0) + d.amount;
    });

    html += `<h4>${month}</h4><ul>`;
    Object.entries(weeks).forEach(([w, s]) =>
      html += `<li>${w} (${getWeekDateRange(w)}): ${s} zł</li>`
    );
    html += `</ul><hr>`;
  }

  statsContent.innerHTML = html + `<h3>Suma roku: ${yearSum} zł</h3>`;
}

// ================= TABS =================
function showView(view) {
  ["weekView", "monthView", "yearView", "statsView"].forEach(v =>
    document.getElementById(v).style.display = "none"
  );
  document.getElementById(view + "View").style.display = "block";

  if (view === "stats") {
    loadYears();
    renderStats();
  }
}

// ================= HELPER - DISPLAY NAME =================
function getDisplayName(username) {
  if (!username) return "-";
  
  // Sprawdź czy użytkownik ma profil
  if (typeof getEmployeeByUsername === 'function') {
    const employee = getEmployeeByUsername(username);
    if (employee && employee.fullName) {
      return employee.fullName;
    }
  }
  
  return username;
}

// ================= INIT =================
reload();
