/* =========================================
   UTILS – DATY / TYGODNIE (ISO, BEZ BUGÓW)
   Oplex Sklep – Obrót
   ========================================= */

/**
 * Bezpieczne tworzenie daty (lokalna, brak UTC shift)
 */
function makeDate(dateStr) {
  return new Date(dateStr + "T12:00:00");
}

/**
 * Format YYYY-MM-DD (czas lokalny)
 */
function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Dzisiejsza data
 */
function today() {
  return formatDate(new Date());
}

/**
 * Klucz tygodnia ISO: YYYY-Www
 */
function getWeekKey(dateStr) {
  const d = makeDate(dateStr);
  const target = new Date(d);
  target.setDate(target.getDate() + 3 - ((target.getDay() + 6) % 7));
  const year = target.getFullYear();
  const week1 = makeDate(`${year}-01-04`);
  const weekNo =
    1 +
    Math.round(
      ((target - week1) / 86400000 - 3 + ((week1.getDay() + 6) % 7)) / 7
    );
  return `${year}-W${String(weekNo).padStart(2, "0")}`;
}

/**
 * Zakres dat tygodnia ISO (pon–ndz)
 */
function getWeekDateRange(weekKey) {
  const [year, week] = weekKey.split("-W").map(Number);
  const simple = makeDate(`${year}-01-01`);
  simple.setDate(simple.getDate() + (week - 1) * 7);
  const dow = simple.getDay();
  const monday =
    dow <= 4
      ? new Date(simple.setDate(simple.getDate() - simple.getDay() + 1))
      : new Date(simple.setDate(simple.getDate() + 8 - simple.getDay()));
  const start = new Date(monday);
  const end = new Date(monday);
  end.setDate(start.getDate() + 6);
  return `${formatDate(start)} – ${formatDate(end)}`;
}

/**
 * Lista dni tygodnia ISO (pon–sob) - 6 DNI
 */
function getWeekDays(weekKey) {
  const [year, week] = weekKey.split("-W").map(Number);
  const simple = makeDate(`${year}-01-01`);
  simple.setDate(simple.getDate() + (week - 1) * 7);
  const dow = simple.getDay();
  const monday =
    dow <= 4
      ? new Date(simple.setDate(simple.getDate() - simple.getDay() + 1))
      : new Date(simple.setDate(simple.getDate() + 8 - simple.getDay()));
  const days = [];
  const names = ["Pon", "Wt", "Śr", "Czw", "Pt", "Sob", "Nie"]; // 7 DNI
  for (let i = 0; i < 7; i++) { // 0-6 (Pon-Nie)
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const dateStr = formatDate(d);
    const holidayName = isPublicHoliday(dateStr);
    days.push({
      date: dateStr,
      label: names[i],
      isDayOff: i === 6 || holidayName !== null, // Niedziela LUB święto = dzień wolny
      holidayName: holidayName // Nazwa święta (jeśli dotyczy)
    });
  }
  return days;
}

/**
 * Oblicz datę Wielkanocy (algorytm Gaussa)
 */
function calculateEaster(year) {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month - 1, day);
}

/**
 * Pobierz wszystkie święta państwowe w Polsce dla danego roku
 * Zwraca obiekt: { "YYYY-MM-DD": "Nazwa święta" }
 */
function getPolishHolidays(year) {
  const holidays = {};
  
  // Święta stałe
  holidays[`${year}-01-01`] = "Nowy Rok";
  holidays[`${year}-01-06`] = "Święto Trzech Króli";
  holidays[`${year}-05-01`] = "Święto Pracy";
  holidays[`${year}-05-03`] = "Święto Konstytucji 3 Maja";
  holidays[`${year}-08-15`] = "Wniebowzięcie NMP";
  holidays[`${year}-11-01`] = "Wszystkich Świętych";
  holidays[`${year}-11-11`] = "Narodowe Święto Niepodległości";
  holidays[`${year}-12-24`] = "Wigilia";
  holidays[`${year}-12-25`] = "Boże Narodzenie";
  holidays[`${year}-12-26`] = "Drugi dzień Bożego Narodzenia";
  
  // Święta ruchome - Wielkanoc i pochodne
  const easter = calculateEaster(year);
  
  // Wielkanoc (niedziela)
  const easterStr = formatDate(easter);
  holidays[easterStr] = "Wielkanoc";
  
  // Poniedziałek Wielkanocny
  const easterMonday = new Date(easter);
  easterMonday.setDate(easter.getDate() + 1);
  holidays[formatDate(easterMonday)] = "Poniedziałek Wielkanocny";
  
  // Boże Ciało (60 dni po Wielkanocy)
  const corpusChristi = new Date(easter);
  corpusChristi.setDate(easter.getDate() + 60);
  holidays[formatDate(corpusChristi)] = "Boże Ciało";
  
  return holidays;
}

/**
 * Sprawdź czy dany dzień jest świętem państwowym
 * @param {string} dateStr - Data w formacie YYYY-MM-DD
 * @returns {string|null} - Nazwa święta lub null jeśli to nie święto
 */
function isPublicHoliday(dateStr) {
  const year = parseInt(dateStr.split("-")[0]);
  const holidays = getPolishHolidays(year);
  return holidays[dateStr] || null;
}

/**
 * Formatuje klucz tygodnia do wyświetlania
 * @param {string} weekKey - Klucz tygodnia w formacie YYYY-WXX
 * @returns {string} - Sformatowany tydzień np. "2025-TYDZIEŃ-50"
 */
function formatWeekDisplay(weekKey) {
  if (!weekKey) return "";
  
  // "2025-W50" → "2025-TYDZIEŃ-50"
  const parts = weekKey.split("-W");
  if (parts.length !== 2) return weekKey;
  
  const year = parts[0];
  const weekNum = parts[1];
  
  return `${year}-TYDZIEŃ-${weekNum}`;
}
