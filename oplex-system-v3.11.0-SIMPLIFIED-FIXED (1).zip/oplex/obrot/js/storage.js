/* =========================================================
   STORAGE – OBRÓT (ROZSZERZONE STATYSTYKI)
   Oplex Sklep
   ========================================================= */

const DAYS_KEY = "oplex:obrot:days";
const WEEKS_KEY = "oplex:obrot:weeks";
const LOGS_KEY = "oplex:obrot:logs";

/* ===================== HELPERS ===================== */

function loadJSON(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}

function saveJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ===================== LOGS ===================== */

/**
 * Dodaje wpis do logu
 * @param {string} action - typ akcji (np. "CLOSE_STATION", "CLOSE_WEEK")
 * @param {object} data - dodatkowe dane
 */
function addLog(action, data = {}) {
  try {
    const logs = loadLogs();
    const log = {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      user: getUser() || "SYSTEM",
      action: action,
      data: data
    };
    
    logs.push(log);
    saveJSON(LOGS_KEY, logs);
    
    return log;
  } catch (e) {
    console.error("Błąd zapisu logu:", e);
  }
}

/**
 * Pobiera wszystkie logi
 */
function loadLogs() {
  return loadJSON(LOGS_KEY, []);
}

/**
 * Pobiera logi dla konkretnego tygodnia
 * @param {string} weekKey
 */
function getWeekLogs(weekKey) {
  const allLogs = loadLogs();
  return allLogs.filter(log => {
    if (log.data.weekKey === weekKey) return true;
    if (log.data.date) {
      const logWeek = getWeekKey(log.data.date);
      return logWeek === weekKey;
    }
    return false;
  });
}

/**
 * Pobiera ostatnie N logów
 */
function getRecentLogs(count = 50) {
  const logs = loadLogs();
  return logs.slice(-count).reverse();
}

/**
 * Czyści logi starsze niż X dni
 * @param {number} days - ilość dni do zachowania
 */
function cleanOldLogs(days = 90) {
  const logs = loadLogs();
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);
  
  const filtered = logs.filter(log => {
    const logDate = new Date(log.timestamp);
    return logDate >= cutoffDate;
  });
  
  saveJSON(LOGS_KEY, filtered);
  return logs.length - filtered.length; // zwróć ilość usuniętych
}

/**
 * Eksportuje logi do JSON
 */
function exportLogs() {
  return loadLogs();
}

/* ===================== DAYS ===================== */

/**
 * Zwraca wszystkie dni
 */
function loadDays() {
  return loadJSON(DAYS_KEY, []);
}

/**
 * Zapisuje wszystkie dni
 */
function saveDays(days) {
  saveJSON(DAYS_KEY, days);
}

/**
 * Zwraca dzień po dacie YYYY-MM-DD
 */
function loadDay(date) {
  return loadDays().find(d => d.date === date) || null;
}

/**
 * Zapis dnia
 * @param {object} day
 * @param {object} options { service: boolean }
 */
function saveDay(day, options = {}) {
  const weeks = loadWeeks();
  const week = weeks.find(w => w.weekKey === day.week);

  // Sprawdź czy to bieżący lub poprzedni tydzień
  const currentWeekKey = getWeekKey(today());
  const prevWeekDate = makeDate(today());
  prevWeekDate.setDate(prevWeekDate.getDate() - 7);
  const prevWeekKey = getWeekKey(formatDate(prevWeekDate));
  
  const isCurrentOrPrevWeek = (day.week === currentWeekKey || day.week === prevWeekKey);

  // BLOKADA: nie zapisujemy do zamkniętego tygodnia
  // WYJĄTKI:
  // 1. Karta serwisowa (options.service)
  // 2. Bieżący lub poprzedni tydzień (można uzupełniać spóźnione dane)
  if (week && week.status === "CLOSED" && !options.service && !isCurrentOrPrevWeek) {
    throw new Error("Tydzień jest zamknięty – edycja zablokowana");
  }

  const days = loadDays();
  const idx = days.findIndex(d => d.date === day.date);

  const payload = {
    ...day,
    serviceEdit: !!options.service,
    updatedAt: new Date().toISOString()
  };

  if (idx >= 0) {
    days[idx] = payload;
  } else {
    days.push(payload);
  }

  saveDays(days);
}

/**
 * Zwraca dni danego tygodnia (Pon–Sob)
 */
function loadWeekDays(weekKey) {
  return loadDays().filter(d => d.week === weekKey);
}

/* ===================== WEEKS (SIMPLIFIED) ===================== */
// UWAGA: System zamykania tygodni został usunięty!
// Tygodnie służą tylko do śledzenia wprowadzonych danych (dla wizualnego statusu)

/**
 * Zwraca wszystkie tygodnie (bez statusów OPEN/CLOSED)
 */
function loadWeeks() {
  return loadJSON(WEEKS_KEY, []);
}

/**
 * Zapis wszystkich tygodni
 */
function saveWeeks(weeks) {
  saveJSON(WEEKS_KEY, weeks);
}

/**
 * Zwraca tydzień po kluczu
 */
function loadWeek(weekKey) {
  return loadWeeks().find(w => w.weekKey === weekKey) || null;
}

/**
 * Upewnij się że tydzień istnieje w trackerze
 * (nie ma już statusów - tylko śledzenie że tydzień był używany)
 */
function ensureWeekExists(weekKey) {
  const weeks = loadWeeks();
  
  if (!weeks.find(w => w.weekKey === weekKey)) {
    weeks.push({
      weekKey,
      createdAt: new Date().toISOString()
    });
    saveWeeks(weeks);
  }
}

/* ===================== VALIDATION ===================== */

/**
 * Sprawdza, czy tydzień ma komplet dni (Pon–Sob) z zamkniętymi stanowiskami
 */
function isWeekComplete(weekKey) {
  const days = loadWeekDays(weekKey);
  const requiredDays = getWeekDays(weekKey);

  return requiredDays.every(d => {
    const day = days.find(x => x.date === d.date);
    // Sprawdź czy dzień istnieje I wszystkie stanowiska są zamknięte
    return day && day.s1Closed && day.s2Closed && day.shippingClosed;
  });
}

/* ===================== RETURNS INTEGRATION ===================== */

/**
 * Pobiera zwroty z modułu Zwrotów dla danego tygodnia
 * @param {string} weekKey - klucz tygodnia (np. "2026-W03")
 * @returns {number} - suma zwrotów w złotych
 */
function getReturnsFromModule(weekKey) {
  try {
    const returnsData = JSON.parse(localStorage.getItem("oplex:zwroty:data")) || [];
    const weekReturns = returnsData.filter(r => r.week === weekKey);
    const sum = weekReturns.reduce((total, r) => total + (r.amount || 0), 0);
    return sum;
  } catch (e) {
    console.error("Błąd pobierania zwrotów z modułu:", e);
    return 0;
  }
}

/**
 * Pobiera szczegóły zwrotów dla tygodnia (dla UI)
 * @param {string} weekKey
 * @returns {Array} - lista zwrotów
 */
function getReturnsDetails(weekKey) {
  try {
    const returnsData = JSON.parse(localStorage.getItem("oplex:zwroty:data")) || [];
    return returnsData.filter(r => r.week === weekKey);
  } catch (e) {
    console.error("Błąd pobierania szczegółów zwrotów:", e);
    return [];
  }
}

/* ===================== SUMMARIES ===================== */

/**
 * Podsumowanie pojedynczego dnia
 * @param {object} day
 * @returns {object} { shop, cash, shippingSum, shippingCount, total }
 */
function calcDayTotals(day) {
  const shop = (day.shop1 || 0) + (day.shop2 || 0);
  const cash = (day.cash1 || 0) + (day.cash2 || 0);
  const shippingSum = day.shippingSum || 0;
  const shippingCount = day.shippingCount || 0;
  
  return {
    shop,
    cash,
    shippingSum,
    shippingCount,
    total: shop + shippingSum
  };
}

/**
 * Podsumowanie tygodnia (z dni)
 */
function calcWeekSummary(weekKey) {
  const days = loadWeekDays(weekKey);

  let shop = 0;
  let cash = 0;
  let shippingSum = 0;
  let shippingCount = 0;

  days.forEach(d => {
    shop += (d.shop1 || 0) + (d.shop2 || 0);
    cash += (d.cash1 || 0) + (d.cash2 || 0);
    shippingSum += d.shippingSum || 0;
    shippingCount += d.shippingCount || 0;
  });

  return {
    shop,
    cash,
    shippingSum,
    shippingCount,
    total: shop + shippingSum
  };
}

/**
 * Statystyki miesiąca – LICZONE Z DNI
 * @param {string} month YYYY-MM
 */
function calcMonthFromDays(month) {
  const days = loadDays().filter(d => d.date.startsWith(month));

  let shop = 0;
  let cash = 0;
  let shippingSum = 0;
  let shippingCount = 0;

  days.forEach(d => {
    const week = loadWeek(d.week);
    if (!week || week.status !== "CLOSED") return;

    shop += (d.shop1 || 0) + (d.shop2 || 0);
    cash += (d.cash1 || 0) + (d.cash2 || 0);
    shippingSum += d.shippingSum || 0;
    shippingCount += d.shippingCount || 0;
  });

  return {
    shop,
    cash,
    shippingSum,
    shippingCount,
    total: shop + shippingSum
  };
}

/**
 * Statystyki roku – SUMA MIESIĘCY
 * @param {string} year YYYY
 * @returns {object} { shop, cash, shippingSum, shippingCount, total }
 */
function calcYearFromDays(year) {
  let shop = 0;
  let cash = 0;
  let shippingSum = 0;
  let shippingCount = 0;

  for (let i = 1; i <= 12; i++) {
    const monthKey = `${year}-${String(i).padStart(2, "0")}`;
    const monthData = calcMonthFromDays(monthKey);
    
    shop += monthData.shop;
    cash += monthData.cash;
    shippingSum += monthData.shippingSum;
    shippingCount += monthData.shippingCount;
  }

  return {
    shop,
    cash,
    shippingSum,
    shippingCount,
    total: shop + shippingSum
  };
}

/**
 * Lista tygodni w miesiącu (wszystkie, nie tylko zamknięte)
 * @param {string} monthKey YYYY-MM
 * @param {boolean} closedOnly - jeśli true, tylko zamknięte (dla wykresów)
 * @returns {Array} [{weekKey, shop, cash, shippingSum, shippingCount, total, returns, final, status}]
 */
function getWeeksInMonth(monthKey, closedOnly = false) {
  const allWeeks = closedOnly 
    ? loadWeeks().filter(w => w.status === "CLOSED")
    : loadWeeks();
  
  const result = [];

  allWeeks.forEach(week => {
    const days = loadWeekDays(week.weekKey);
    const hasMonthDays = days.some(d => d.date.startsWith(monthKey));
    
    if (hasMonthDays) {
      const summary = calcWeekSummary(week.weekKey);
      result.push({
        weekKey: week.weekKey,
        ...summary,
        returns: week.returns || 0,
        final: week.final || 0,
        status: week.status
      });
    }
  });

  return result.sort((a, b) => a.weekKey.localeCompare(b.weekKey));
}

/**
 * Najlepszy i najgorszy dzień w miesiącu (tylko zamknięte tygodnie)
 * @param {string} monthKey YYYY-MM
 * @returns {object} { best: {date, total}, worst: {date, total} }
 */
function getBestWorstDay(monthKey) {
  const days = loadDays().filter(d => {
    if (!d.date.startsWith(monthKey)) return false;
    
    const week = loadWeek(d.week);
    return week && week.status === "CLOSED";
  });

  if (days.length === 0) {
    return { best: null, worst: null };
  }

  let best = null;
  let worst = null;

  days.forEach(d => {
    const totals = calcDayTotals(d);
    
    if (!best || totals.total > best.total) {
      best = { date: d.date, total: totals.total };
    }
    
    if (!worst || totals.total < worst.total) {
      worst = { date: d.date, total: totals.total };
    }
  });

  return { best, worst };
}
