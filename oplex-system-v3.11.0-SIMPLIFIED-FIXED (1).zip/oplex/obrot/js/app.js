/* =========================================
   APP – OBRÓT (KOMPLETNE STATYSTYKI)
   Oplex Sklep
   ========================================= */

// ================= GLOBALS =================

// Przechowywanie instancji wykresów Chart.js
window.chartInstances = {
  month1: null,
  month2: null,
  month3: null,
  month4: null,
  year1: null,
  year2: null,
  year3: null,
  year4: null
};

// Funkcja niszcząca wszystkie instancje wykresów
function destroyAllCharts() {
  Object.keys(window.chartInstances).forEach(key => {
    if (window.chartInstances[key]) {
      window.chartInstances[key].destroy();
      window.chartInstances[key] = null;
    }
  });
}

// ================= POMOC =================

/**
 * Otwiera dokumentację PDF w nowej karcie
 */
function openHelp() {
  // Otwórz PDF w nowej karcie
  window.open('dokumentacja.pdf', '_blank');
}

// ================= FALLBACKS =================

// Fallback dla getUser jeśli auth.js nie jest załadowany
if (typeof getUser !== 'function') {
  window.getUser = function() {
    return localStorage.getItem("oplex_user") || "SYSTEM";
  };
}

// ================= ADMIN ACCESS =================

/**
 * Sprawdza uprawnienia administratora
 * Wymaga aktywnej sesji admin LUB roli manager/super-admin
 * @returns {boolean}
 */
function requireAdminAccess(actionName = "tej operacji") {
  // Sprawdź czy token admin aktywny
  if (typeof checkAdminSession === 'function' && checkAdminSession()) {
    return true;
  }
  
  // Sprawdź czy użytkownik ma uprawnienia zarządcze
  const username = getUser();
  
  if (typeof isManager === 'function' && typeof isSuperAdmin === 'function') {
    if (isManager(username) || isSuperAdmin(username)) {
      alert(
        `⚠️ WYMAGA UPRAWNIEŃ ADMIN\n\n` +
        `Operacja: ${actionName}\n\n` +
        `Zaloguj się jako Admin przez Dashboard:\n` +
        `1. Wróć do Dashboard (przycisk ⬅)\n` +
        `2. Kliknij kafelek "🔐 Zarządzanie"\n` +
        `3. Wprowadź hasło super-admin\n` +
        `4. Wróć tutaj z aktywnym tokenem admin`
      );
      return false;
    }
  }
  
  // Brak uprawnień
  alert(
    `❌ BRAK UPRAWNIEŃ\n\n` +
    `Operacja: ${actionName}\n\n` +
    `Tylko zarządcy i super-admini mogą wykonać tę akcję.\n\n` +
    `Skontaktuj się z administratorem.`
  );
  return false;
}

// Fallback dla modułu Zwrotów (jeśli nie załadowany)
if (typeof getReturnsFromModule !== 'function') {
  window.getReturnsFromModule = function(weekKey) {
    // Próbuj pobrać z localStorage modułu zwrotów
    try {
      const returnsData = localStorage.getItem('oplex:returns:data');
      if (!returnsData) return 0;
      
      const returns = JSON.parse(returnsData);
      
      // Filtruj zwroty dla tego tygodnia
      const weekReturns = returns.filter(r => {
        if (!r.date) return false;
        const returnWeek = getWeekKey(r.date);
        return returnWeek === weekKey;
      });
      
      // Sumuj wartości
      const total = weekReturns.reduce((sum, r) => sum + (parseFloat(r.amount) || 0), 0);
      
      console.log(`[FALLBACK] Zwroty dla ${weekKey}:`, total, 'zł (znaleziono:', weekReturns.length, 'zwrotów)');
      
      return total;
    } catch (error) {
      console.error('[FALLBACK] Błąd pobierania zwrotów:', error);
      return 0;
    }
  };
  
  window.getReturnsDetails = function(weekKey) {
    // Próbuj pobrać szczegóły zwrotów
    try {
      const returnsData = localStorage.getItem('oplex:returns:data');
      if (!returnsData) return [];
      
      const returns = JSON.parse(returnsData);
      
      // Filtruj zwroty dla tego tygodnia
      const weekReturns = returns.filter(r => {
        if (!r.date) return false;
        const returnWeek = getWeekKey(r.date);
        return returnWeek === weekKey;
      });
      
      console.log(`[FALLBACK] Szczegóły zwrotów dla ${weekKey}:`, weekReturns.length, 'zwrotów');
      
      return weekReturns;
    } catch (error) {
      console.error('[FALLBACK] Błąd pobierania szczegółów zwrotów:', error);
      return [];
    }
  };
  
  console.warn('⚠️ Moduł Zwrotów nie załadowany - używam fallback');
}

// ================= HELPERS =================

// Pobierz wczorajszy dzień (pomijając niedzielę)
function getYesterday() {
  const today = new Date();
  let yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  // Jeśli wczoraj była niedziela (0), cofnij do soboty
  if (yesterday.getDay() === 0) {
    yesterday.setDate(yesterday.getDate() - 1);
  }
  
  return formatDate(yesterday);
}

// ================= STATE =================
// Funkcja pomocnicza: pobierz dzisiejszą datę
/**
 * Pobiera odpowiednią datę startową dla OBROTU
 * Obrót zawsze zaczyna od dzisiejszej daty (nie patrzy na config wypłat!)
 */
/**
 * Pobiera datę startową systemu
 * - Jeśli użytkownik ustawił datę w Zarządzaniu - zwraca ją
 * - Jeśli nie - zwraca dzisiejszą datę
 */
function getStartDate() {
  const savedStartDate = localStorage.getItem('oplex:system:startDate');
  if (savedStartDate) {
    console.log(`📅 Używam zapisanej daty startowej: ${savedStartDate}`);
    return savedStartDate;
  }
  
  // Fallback - dzisiejsza data
  const today = new Date();
  return formatDate(today);
}

function getToday() {
  const today = new Date();
  return formatDate(today);
}

let currentDate = getStartDate(); // ✅ Zawsze DZIŚ (niezależnie od wypłat)
let currentWeek = getWeekKey(currentDate);
let currentDay = null;

// ================= ELEMENTS =================
const shop1 = document.getElementById("shop1");
const shop2 = document.getElementById("shop2");
const cash1 = document.getElementById("cash1");
const cash2 = document.getElementById("cash2");
const shippingSum = document.getElementById("shippingSum");
const shippingCount = document.getElementById("shippingCount");

const autoShop = document.getElementById("autoShop");
const autoCash = document.getElementById("autoCash");
const dayTotal = document.getElementById("dayTotal");

const userS1 = document.getElementById("userS1");
const userS2 = document.getElementById("userS2");

const dayTitle = document.getElementById("dayTitle");
const weekTitle = document.getElementById("weekTitle");

const closeWeekBtn = document.getElementById("closeWeekBtn");
const weekError = document.getElementById("weekError");

// ================= INIT =================
try {
  initWeekTracking();
  showView("day");
} catch (error) {
  console.error("Błąd inicjalizacji:", error);
  // Jeśli jest problem z inicjalizacją, spróbuj pokazać przynajmniej podstawowy widok
  setTimeout(() => {
    try {
      if (typeof showView === 'function') {
        showView("day");
      }
    } catch (e) {
      console.error("Nie udało się załadować widoku:", e);
    }
  }, 100);
}

// ================= WEEK TRACKING (SIMPLIFIED) =================
// UWAGA: System zamykania został usunięty!
// Teraz tylko upewniamy się że tydzień jest w trackerze

function initWeekTracking() {
  // Upewnij się że bieżący tydzień istnieje w trackerze
  ensureWeekExists(currentWeek);
  console.log(`Tydzień ${currentWeek} gotowy do pracy`);
}

// ================= VIEW =================
function showView(view) {
  ["dayView","weekView","statsView","manageView"].forEach(v =>
    document.getElementById(v).style.display = "none"
  );
  ["dayTab","weekTab","statsTab","manageTab"].forEach(t =>
    document.getElementById(t).classList.remove("active")
  );

  document.getElementById(view + "View").style.display = "block";
  document.getElementById(view + "Tab").classList.add("active");

  if (view === "day") renderDay();
  if (view === "week") renderWeek();
  if (view === "stats") renderStats();
  if (view === "manage") renderManage();
}

// ================= DAY =================
function renderDay() {
  currentWeek = getWeekKey(currentDate);
  
  // Sprawdź czy dzień jest w przyszłości
  const isFutureDay = isFuture(currentDate);
  
  // Dashboard tygodnia
  renderWeekDashboard();
  
  // Sprawdź czy dayTitle istnieje
  if (dayTitle) {
    if (isFutureDay) {
      dayTitle.innerHTML = `Dzień: ${currentDate} | Tydzień: ${formatWeekDisplay(currentWeek)} <span style="color: #f59e0b; margin-left: 10px;">⏰ Przyszły dzień</span>`;
    } else {
      dayTitle.innerText = `Dzień: ${currentDate} | Tydzień: ${formatWeekDisplay(currentWeek)}`;
    }
  }

  currentDay = loadDay(currentDate) || { date: currentDate, week: currentWeek };

  // Sprawdź czy to niedziela, święto lub ręcznie oznaczony dzień wolny
  const dayOfWeek = makeDate(currentDate).getDay();
  const isSunday = dayOfWeek === 0;
  const holidayName = isPublicHoliday(currentDate); // Sprawdź święta państwowe
  const isHoliday = holidayName !== null;
  const isManualDayOff = currentDay.dayOff === true;
  const isDayOff = isSunday || isHoliday || isManualDayOff;
  const debugMode = localStorage.getItem("oplex:debug_mode") === "true";
  
  // Określ etykietę dnia wolnego
  let dayOffLabel = "Dzień wolny";
  if (isSunday) {
    dayOffLabel = "Niedziela";
  } else if (isHoliday) {
    dayOffLabel = holidayName; // Nazwa święta (np. "Boże Narodzenie")
  }

  // Domyślne wartości 0 - TYLKO jeśli elementy istnieją
  if (shop1) shop1.value = currentDay.shop1 !== undefined ? currentDay.shop1 : 0;
  if (shop2) shop2.value = currentDay.shop2 !== undefined ? currentDay.shop2 : 0;
  if (cash1) cash1.value = currentDay.cash1 !== undefined ? currentDay.cash1 : 0;
  if (cash2) cash2.value = currentDay.cash2 !== undefined ? currentDay.cash2 : 0;
  if (shippingSum) shippingSum.value = currentDay.shippingSum !== undefined ? currentDay.shippingSum : 0;
  if (shippingCount) shippingCount.value = currentDay.shippingCount !== undefined ? currentDay.shippingCount : 0;

  // AUTO-ZAMKNIĘCIE DNI WOLNYCH (niedziela/święta)
  // Sprawdź czy JAKIEKOLWIEK stanowisko nie jest zamknięte
  if (isDayOff && (!currentDay.s1Closed || !currentDay.s2Closed || !currentDay.shippingClosed)) {
    // Jeśli dzień wolny i cokolwiek nie zamknięte - zamknij to
    const timestamp = new Date().toISOString();
    
    // Ustaw wszystkie wartości na 0 (może już są, ale upewnij się)
    currentDay.shop1 = 0;
    currentDay.shop2 = 0;
    currentDay.cash1 = 0;
    currentDay.cash2 = 0;
    currentDay.shippingSum = 0;
    currentDay.shippingCount = 0;
    
    // Zamknij tylko to co nie jest zamknięte
    if (!currentDay.s1Closed) {
      currentDay.s1Closed = true;
      currentDay.s1ClosedAt = timestamp;
      currentDay.s1ClosedBy = "SYSTEM";
    }
    
    if (!currentDay.s2Closed) {
      currentDay.s2Closed = true;
      currentDay.s2ClosedAt = timestamp;
      currentDay.s2ClosedBy = "SYSTEM";
    }
    
    if (!currentDay.shippingClosed) {
      currentDay.shippingClosed = true;
      currentDay.shippingClosedAt = timestamp;
      currentDay.shippingClosedBy = "SYSTEM";
    }
    
    currentDay.dayOff = true;
    
    saveDay(currentDay);
    
    // Odśwież wartości w polach
    if (shop1) shop1.value = 0;
    if (shop2) shop2.value = 0;
    if (cash1) cash1.value = 0;
    if (cash2) cash2.value = 0;
    if (shippingSum) shippingSum.value = 0;
    if (shippingCount) shippingCount.value = 0;
  }

  // BLOKADA DNI WOLNYCH (NIEDZIELA + ŚWIĘTA + RĘCZNE)
  if (isDayOff && !debugMode) {
    // Readonly dla dni wolnych (chyba że debug mode)
    if (shop1) shop1.readOnly = true;
    if (shop2) shop2.readOnly = true;
    if (cash1) cash1.readOnly = true;
    if (cash2) cash2.readOnly = true;
    if (shippingSum) shippingSum.readOnly = true;
    if (shippingCount) shippingCount.readOnly = true;
    
    // Zielone tło dla dni wolnych
    [shop1, shop2, cash1, cash2, shippingSum, shippingCount].filter(Boolean).forEach(input => {
      input.style.background = '#dcfce7';
      input.style.cursor = 'not-allowed';
    });
    
    // Ukryj przyciski zamknięcia
    const btnS1 = document.getElementById("closeS1Btn");
    const btnS2 = document.getElementById("closeS2Btn");
    const btnShipping = document.getElementById("closeShippingBtn");
    const btnAll = document.getElementById("closeAllBtn");
    const btnDayOff = document.getElementById("closeDayOffBtn");
    const btnEdit = document.getElementById("editDayBtn");
    
    if (btnS1) btnS1.style.display = "none";
    if (btnS2) btnS2.style.display = "none";
    if (btnShipping) btnShipping.style.display = "none";
    if (btnAll) btnAll.style.display = "none";
    if (btnDayOff) btnDayOff.style.display = "none";
    if (btnEdit) btnEdit.style.display = "none";
    
    // Pokaż komunikat dnia wolnego (używamy dayOffLabel zdefiniowanego wcześniej)
    const statusS1 = document.getElementById("statusS1");
    const statusS2 = document.getElementById("statusS2");
    const statusShipping = document.getElementById("statusShipping");
    
    if (statusS1) statusS1.innerHTML = `<span style="color: #16a34a;">🏖️ ${dayOffLabel}</span>`;
    if (statusS2) statusS2.innerHTML = `<span style="color: #16a34a;">🏖️ ${dayOffLabel}</span>`;
    if (statusShipping) statusShipping.innerHTML = `<span style="color: #16a34a;">🏖️ ${dayOffLabel}</span>`;
    
    if (dayTitle) {
      dayTitle.innerHTML = `Dzień: ${currentDate} | Tydzień: ${formatWeekDisplay(currentWeek)} <span style="color: #16a34a; margin-left: 10px;">🏖️ ${dayOffLabel}</span>`;
    }
    
    updateAuto(false);
    return; // Zakończ renderowanie
  }
  
  // BLOKADA PRZYSZŁYCH DNI
  if (isFutureDay) {
    if (shop1) shop1.readOnly = true;
    if (shop2) shop2.readOnly = true;
    if (cash1) cash1.readOnly = true;
    if (cash2) cash2.readOnly = true;
    if (shippingSum) shippingSum.readOnly = true;
    if (shippingCount) shippingCount.readOnly = true;
    
    // Dodaj klasę disabled do wizualizacji
    [shop1, shop2, cash1, cash2, shippingSum, shippingCount].filter(Boolean).forEach(input => {
      input.style.background = '#f3f4f6';
      input.style.cursor = 'not-allowed';
    });
    
    // Ukryj wszystkie przyciski zamknięcia
    const btnS1 = document.getElementById("closeS1Btn");
    const btnS2 = document.getElementById("closeS2Btn");
    const btnShipping = document.getElementById("closeShippingBtn");
    const btnAll = document.getElementById("closeAllBtn");
    const btnDayOff = document.getElementById("closeDayOffBtn");
    const btnEdit = document.getElementById("editDayBtn");
    
    if (btnS1) btnS1.style.display = "none";
    if (btnS2) btnS2.style.display = "none";
    if (btnShipping) btnShipping.style.display = "none";
    if (btnAll) btnAll.style.display = "none";
    if (btnDayOff) btnDayOff.style.display = "none";
    if (btnEdit) btnEdit.style.display = "none";
    
    // Pokaż komunikat
    const statusS1 = document.getElementById("statusS1");
    const statusS2 = document.getElementById("statusS2");
    const statusShipping = document.getElementById("statusShipping");
    
    if (statusS1) statusS1.innerHTML = '<span style="color: #f59e0b;">⏰ Przyszły dzień</span>';
    if (statusS2) statusS2.innerHTML = '<span style="color: #f59e0b;">⏰ Przyszły dzień</span>';
    if (statusShipping) statusShipping.innerHTML = '<span style="color: #f59e0b;">⏰ Przyszły dzień</span>';
    
  } else {
    // Odblokuj pola - TYLKO jeśli istnieją
    if (shop1) shop1.readOnly = false;
    if (shop2) shop2.readOnly = false;
    if (cash1) cash1.readOnly = false;
    if (cash2) cash2.readOnly = false;
    if (shippingSum) shippingSum.readOnly = false;
    if (shippingCount) shippingCount.readOnly = false;
    
    // Przywróć normalny wygląd
    [shop1, shop2, cash1, cash2, shippingSum, shippingCount].filter(Boolean).forEach(input => {
      input.style.background = '';
      input.style.cursor = '';
    });
    
    // Normalne statusy zamknięcia
    if (userS1) {
      if (currentDay.s1User) {
        const displayName = currentDay.s1UserData?.fullName || currentDay.s1User;
        userS1.innerText = `👤 ${displayName}`;
      } else {
        userS1.innerText = "";
      }
    }
    if (userS2) {
      if (currentDay.s2User) {
        const displayName = currentDay.s2UserData?.fullName || currentDay.s2User;
        userS2.innerText = `👤 ${displayName}`;
      } else {
        userS2.innerText = "";
      }
    }
    updateClosedStatus();
  }
  
  updateAuto(false);
}

// Sprawdź czy data jest w przyszłości
function isFuture(dateStr) {
  const date = makeDate(dateStr);
  date.setHours(0, 0, 0, 0); // ✅ Ustaw na 00:00:00
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return date > today;
}

// ================= DASHBOARD =================

// Dashboard statusu tygodnia
function renderWeekDashboard() {
  const dashboardEl = document.getElementById("weekDashboard");
  if (!dashboardEl) return;
  
  // Sprawdź czy aktualny dzień jest w PRAWDZIWEJ przyszłości (nie dzisiaj!)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const currentDayDate = makeDate(currentDate);
  currentDayDate.setHours(0, 0, 0, 0); // ✅ KLUCZOWE: ustaw też na 00:00:00
  const isFutureDay = currentDayDate > today;
  
  if (isFutureDay) {
    dashboardEl.innerHTML = `
      <div class="dashboard-card dashboard-future">
        <h4>⏰ Przyszły dzień</h4>
        <p>Dzień <strong>${currentDate}</strong> jeszcze się nie rozpoczął.</p>
        <p style="color: #6b7280; font-size: 14px;">Wprowadzanie danych będzie możliwe po rozpoczęciu tego dnia.</p>
      </div>
    `;
    return;
  }
  
  // Sprawdź czy to niedziela lub święto
  const dayOfWeek = currentDayDate.getDay();
  const holidayName = isPublicHoliday(currentDate);
  
  if (dayOfWeek === 0) {
    // NIEDZIELA
    dashboardEl.innerHTML = `
      <div class="dashboard-card" style="background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%); border-color: #ef4444;">
        <h4>🔴 Dzień wolny - Niedziela</h4>
        <p>Niedziela <strong>${currentDate}</strong> jest dniem wolnym.</p>
        <p style="color: #991b1b; font-size: 14px;">System automatycznie zamknął wszystkie stanowiska z wartościami 0.</p>
      </div>
    `;
    return;
  }
  
  if (holidayName) {
    // ŚWIĘTO PAŃSTWOWE
    dashboardEl.innerHTML = `
      <div class="dashboard-card" style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-color: #f59e0b;">
        <h4>⭐ Dzień wolny - Święto państwowe</h4>
        <p><strong>${holidayName}</strong> (${currentDate})</p>
        <p style="color: #92400e; font-size: 14px;">System automatycznie zamknął wszystkie stanowiska z wartościami 0.</p>
      </div>
    `;
    return;
  }
  
  // DZIEŃ ROBOCZY - pokaż normalny dashboard
  const days = getWeekDays(currentWeek);
  const savedDays = loadWeekDays(currentWeek);
  const map = {};
  savedDays.forEach(d => map[d.date] = d);
  
  let completed = 0;
  let statusHTML = '<div class="week-days-status">';
  
  days.forEach(d => {
    // Sprawdź czy to niedziela, święto lub ręcznie oznaczony dzień wolny
    const holidayName = isPublicHoliday(d.date);
    const isHoliday = holidayName !== null;
    const day = map[d.date];
    const isDayOff = d.isDayOff || isHoliday || day?.dayOff === true;
    
    // POMIŃ NIEDZIELĘ - nie pokazuj w dashboardzie
    if (d.isDayOff) {
      return; // Niedziela pomijamy
    }
    
    // Sprawdź czy pola wypełnione (zamiast closed)
    const dayData = map[d.date];
    const s1Filled = dayData && (dayData.shop1 > 0 || dayData.cash1 > 0);
    const s2Filled = dayData && (dayData.shop2 > 0 || dayData.cash2 > 0);
    const shipFilled = dayData && (dayData.shippingSum > 0 || dayData.shippingCount > 0);
    
    let status = '❌'; // Żadne
    let cssClass = 'day-status-none';
    
    if (isDayOff) {
      // ŚWIĘTO - CZERWONY kafelek
      status = '🏖️';
      cssClass = 'day-status-holiday';
      // Nie liczymy jako completed
    } else if (s1Filled && s2Filled && shipFilled) {
      // DZIEŃ ROBOCZY I WYPEŁNIONY
      status = '✅';
      cssClass = 'day-status-complete';
      completed++; // ZLICZ
    } else if (s1Filled || s2Filled || shipFilled) {
      status = '⚠️';
      cssClass = 'day-status-partial';
    }
    
    const isToday = d.date === currentDate;
    const isFutureInWeek = isFuture(d.date);
    
    // Jeśli dzień jest w przyszłości, pokaż ikonę zegara
    if (isFutureInWeek && !isDayOff) {
      status = '⏰';
      cssClass = 'day-status-future';
    }
    
    // Tooltip
    let tooltipText = '';
    if (isDayOff) {
      tooltipText = holidayName || 'Dzień wolny';
    } else if (isFutureInWeek) {
      tooltipText = 'Przyszły dzień';
    } else {
      tooltipText = `${s1Filled?'S1✓':''} ${s2Filled?'S2✓':''} ${shipFilled?'P✓':''}`;
    }
    
    statusHTML += `<div class="day-status-item ${cssClass} ${isToday ? 'day-status-today' : ''}" title="${d.date}: ${tooltipText}">${d.label}<br>${status}</div>`;
  });
  
  statusHTML += '</div>';
  
  // Dni robocze (bez niedzieli, świąt i ręcznych dni wolnych)
  const workingDays = days.filter(d => {
    const holidayName = isPublicHoliday(d.date);
    const isHoliday = holidayName !== null;
    const day = map[d.date];
    const isDayOff = d.isDayOff || isHoliday || day?.dayOff === true;
    return !isDayOff; // Zwróć tylko dni robocze
  }).length;
  
  dashboardEl.innerHTML = `
    <div class="dashboard-card">
      <h4>📊 Status tygodnia ${formatWeekDisplay(currentWeek)}</h4>
      <p>Dni robocze uzupełnione: <strong>${completed}/${workingDays}</strong> ${completed === workingDays ? '🎉' : completed >= Math.floor(workingDays/2) ? '⚠️' : '❌'}</p>
      ${statusHTML}
    </div>
  `;
}

// Aktualizuj statusy zamknięcia stanowisk
// ================= STATUS KART (UPROSZCZONY) =================
// Zielone tło gdy OBA pola wypełnione, szare gdy nie
function updateClosedStatus() {
  // Sprawdź czy pola wypełnione (zamiast flag "closed")
  const s1 = +shop1.value || 0;
  const c1 = +cash1.value || 0;
  const s2 = +shop2.value || 0;
  const c2 = +cash2.value || 0;
  const ship = +shippingSum.value || 0;
  const count = +shippingCount.value || 0;
  
  const s1Filled = (s1 > 0 || c1 > 0); // Wypełnione gdy przynajmniej jedno pole
  const s2Filled = (s2 > 0 || c2 > 0);
  const shippingFilled = (ship > 0 || count > 0);
  
  // Statusy wizualne
  const statusS1 = document.getElementById("statusS1");
  const statusS2 = document.getElementById("statusS2");
  const statusShipping = document.getElementById("statusShipping");
  
  if (statusS1) statusS1.innerText = s1Filled ? "✅ Wypełnione" : "⚪ Do uzupełnienia";
  if (statusS2) statusS2.innerText = s2Filled ? "✅ Wypełnione" : "⚪ Do uzupełnienia";
  if (statusShipping) statusShipping.innerText = shippingFilled ? "✅ Wypełnione" : "⚪ Do uzupełnienia";
  
  // Zielone tło dla wypełnionych stanowisk
  const shop1Input = document.getElementById("shop1");
  const shop2Input = document.getElementById("shop2");
  const shippingInput = document.getElementById("shippingSum");
  
  if (shop1Input && shop1Input.parentElement) {
    if (s1Filled && s1 > 0 && c1 > 0) { // Zielone gdy OBA pola
      shop1Input.parentElement.classList.add('station-closed');
    } else {
      shop1Input.parentElement.classList.remove('station-closed');
    }
  }
  
  if (shop2Input && shop2Input.parentElement) {
    if (s2Filled && s2 > 0 && c2 > 0) { // Zielone gdy OBA pola
      shop2Input.parentElement.classList.add('station-closed');
    } else {
      shop2Input.parentElement.classList.remove('station-closed');
    }
  }
  
  if (shippingInput && shippingInput.parentElement) {
    if (shippingFilled && ship > 0 && count > 0) { // Zielone gdy OBA pola
      shippingInput.parentElement.classList.add('station-closed');
    } else {
      shippingInput.parentElement.classList.remove('station-closed');
    }
  }
}

// Zamknij stanowisko 1
// USUNIĘTE: closeStation1() - system zamykania wyłączony
// Karty stanowisk są teraz zawsze edytowalne
function closeStation1() {
  // Funkcja wyłączona - zawsze można edytować
  console.log("closeStation1: funkcja wyłączona w uproszczonym systemie");
}

// Zamknij stanowisko 2
function closeStation2() {
  const s2 = +shop2.value || 0;
  const c2 = +cash2.value || 0;
  
  // USUNIĘTO WALIDACJĘ - można zamknąć z 0 zł (stanowisko wyłączone)
  
  currentDay.s2Closed = true;
  currentDay.s2ClosedAt = new Date().toISOString();
  currentDay.s2ClosedBy = getUser();
  saveDay(currentDay);
  updateClosedStatus();
  renderWeekDashboard();
  
  // LOG
  addLog("CLOSE_STATION_2", {
    date: currentDate,
    weekKey: currentWeek,
    shop: s2,
    cash: c2,
    total: s2 + c2
  });
  
  // AUTO-BACKUP jeśli wszystkie zamknięte (jeśli funkcja istnieje)
  if (typeof checkAndAutoBackup === 'function') {
    checkAndAutoBackup();
  }
}

// Zamknij wszystkie stanowiska jednocześnie
// USUNIĘTE: closeAllStations() - system zamykania wyłączony
function closeAllStations() {
  // Funkcja wyłączona - zawsze można edytować
  console.log("closeAllStations: funkcja wyłączona w uproszczonym systemie");
}

// Zamknij dzień jako DZIEŃ WOLNY (święto, urlop, etc.)
function closeDayOff() {
  const confirmed = confirm(
    "🏖️ DZIEŃ WOLNY\n\n" +
    "Czy zamknąć ten dzień jako dzień wolny?\n\n" +
    "Wszystkie wartości zostaną ustawione na 0.\n" +
    "Dzień zostanie oznaczony jako zamknięty."
  );
  
  if (!confirmed) return;
  
  const timestamp = new Date().toISOString();
  const user = getUser();
  
  // Ustaw wszystkie wartości na 0
  currentDay.shop1 = 0;
  currentDay.shop2 = 0;
  currentDay.cash1 = 0;
  currentDay.cash2 = 0;
  currentDay.shippingSum = 0;
  currentDay.shippingCount = 0;
  
  // Zamknij wszystkie stanowiska
  currentDay.s1Closed = true;
  currentDay.s1ClosedAt = timestamp;
  currentDay.s1ClosedBy = user;
  
  currentDay.s2Closed = true;
  currentDay.s2ClosedAt = timestamp;
  currentDay.s2ClosedBy = user;
  
  currentDay.shippingClosed = true;
  currentDay.shippingClosedAt = timestamp;
  currentDay.shippingClosedBy = user;
  
  // Oznacz jako dzień wolny
  currentDay.dayOff = true;
  
  saveDay(currentDay);
  updateClosedStatus();
  renderWeekDashboard();
  
  // LOG
  addLog("CLOSE_DAY_OFF", {
    date: currentDate,
    weekKey: currentWeek
  });
  
  // AUTO-BACKUP jeśli wszystkie zamknięte
  if (typeof checkAndAutoBackup === 'function') {
    checkAndAutoBackup();
  }
  
  alert("✅ Dzień wolny zamknięty!");
  
  // Odśwież widok
  renderDay();
}

// Odblokuj zamknięty dzień (umożliwia edycję)
function unlockDay() {
  const confirmed = confirm(
    "✏️ EDYCJA ZAMKNIĘTEGO DNIA\n\n" +
    `Czy odblokować dzień ${currentDate}?\n\n` +
    "Wszystkie stanowiska zostaną ponownie otwarte.\n" +
    "Będzie można edytować dane i zamknąć ponownie."
  );
  
  if (!confirmed) return;
  
  // Odblokuj wszystkie stanowiska
  currentDay.s1Closed = false;
  currentDay.s2Closed = false;
  currentDay.shippingClosed = false;
  
  // Usuń znaczniki czasowe zamknięcia (opcjonalnie)
  // Można je zachować dla historii
  
  saveDay(currentDay);
  updateClosedStatus();
  renderWeekDashboard();
  
  // LOG
  addLog("EDIT_DAY", {
    date: currentDate,
    weekKey: currentWeek,
    reason: "Odblokowano dzień do edycji"
  });
  
  alert("✅ Dzień odblokowany!\n\nMożesz teraz edytować dane i zamknąć ponownie.");
  
  // Odśwież widok
  renderDay();
}

// Zamknij wysyłki
function closeShipping() {
  const ship = +shippingSum.value || 0;
  const count = +shippingCount.value || 0;
  
  // USUNIĘTO WALIDACJĘ - można zamknąć z 0 zł (brak wysyłek dziś)
  
  currentDay.shippingClosed = true;
  currentDay.shippingClosedAt = new Date().toISOString();
  currentDay.shippingClosedBy = getUser();
  saveDay(currentDay);
  updateClosedStatus();
  renderWeekDashboard();
  
  // LOG
  addLog("CLOSE_SHIPPING", {
    date: currentDate,
    weekKey: currentWeek,
    sum: ship,
    count: count
  });
  
  // AUTO-BACKUP jeśli wszystkie zamknięte
  if (typeof checkAndAutoBackup === 'function') {
    checkAndAutoBackup();
  }
}

// ================= AUTO =================
function updateAuto(save = true) {
  // Sprawdź czy wszystkie elementy istnieją
  if (!shop1 || !shop2 || !cash1 || !cash2 || !shippingSum || !shippingCount) {
    console.warn("updateAuto: Brak elementów DOM");
    return;
  }
  
  const s1 = +shop1.value || 0;
  const s2 = +shop2.value || 0;
  const c1 = +cash1.value || 0;
  const c2 = +cash2.value || 0;
  const ship = +shippingSum.value || 0;
  const shipCount = +shippingCount.value || 0;

  // WYNIKI - nowa struktura
  if (autoShop) autoShop.innerText = (s1 + s2) + " zł";  // Obrót łączny sklepu
  if (autoCash) autoCash.innerText = (c1 + c2) + " zł";  // Gotówka do oddania
  
  // NOWE pola
  const autoShippingEl = document.getElementById('autoShipping');
  const autoShippingCountEl = document.getElementById('autoShippingCount');
  if (autoShippingEl) autoShippingEl.innerText = ship + " zł";  // Obrót wysyłki
  if (autoShippingCountEl) autoShippingCountEl.innerText = shipCount + " szt.";  // Ilość paczek
  
  // ŁĄCZNIE = sklep + wysyłki (bez gotówki)
  if (dayTotal) dayTotal.innerText = (s1 + s2 + ship) + " zł";

  currentDay = {
    ...currentDay,
    shop1: s1, shop2: s2,
    cash1: c1, cash2: c2,
    shippingSum: ship,
    shippingCount: shipCount
  };

  // NIE ZAPISUJ jeśli dzień jest w przyszłości
  if (isFuture(currentDate)) {
    return;
  }

  if (save) {
    try {
      // Sprawdź czy tryb edycji aktywny
      if (typeof editModeActive !== 'undefined' && editModeActive) {
        saveDay(currentDay, { service: true }); // Zapisz jako edycja serwisowa
        resetEditTimer(); // Zresetuj timer
      } else {
        saveDay(currentDay);
      }
    } catch (err) {
      alert(err.message);
    }
  }
}

// ================= USER ASSIGN =================
function assignUserS1() {
  if (!currentDay.s1User) {
    const username = getUser();
    currentDay.s1User = username;
    
    // Zapisz pełne dane pracownika z profilu
    if (typeof getEmployeeByUsername === 'function') {
      const employee = getEmployeeByUsername(username);
      if (employee) {
        currentDay.s1UserData = {
          username: username,
          fullName: employee.fullName,
          role: employee.role
        };
      }
    }
    
    // Sprawdź czy to sobota
    const date = new Date(currentDate);
    const isSaturday = date.getDay() === 6;
    if (isSaturday) {
      currentDay.s1Saturday = true;
      console.log(`✅ Sobota wykryta! Stanowisko 1: ${username}`);
    }
    
    userS1.innerText = `👤 ${currentDay.s1UserData?.fullName || username}`;
  }
}

function assignUserS2() {
  if (!currentDay.s2User) {
    const username = getUser();
    currentDay.s2User = username;
    
    // Zapisz pełne dane pracownika z profilu
    if (typeof getEmployeeByUsername === 'function') {
      const employee = getEmployeeByUsername(username);
      if (employee) {
        currentDay.s2UserData = {
          username: username,
          fullName: employee.fullName,
          role: employee.role
        };
      }
    }
    
    // Sprawdź czy to sobota
    const date = new Date(currentDate);
    const isSaturday = date.getDay() === 6;
    if (isSaturday) {
      currentDay.s2Saturday = true;
      console.log(`✅ Sobota wykryta! Stanowisko 2: ${username}`);
    }
    
    userS2.innerText = `👤 ${currentDay.s2UserData?.fullName || username}`;
  }
}

// ================= INPUTS =================
shop1.oninput = cash1.oninput = () => {
  if (shop1.value || cash1.value) assignUserS1();
  updateAuto();
};
shop2.oninput = cash2.oninput = () => {
  if (shop2.value || cash2.value) assignUserS2();
  updateAuto();
};
shippingSum.oninput = shippingCount.oninput = () => updateAuto();

// ================= WEEK =================
function renderWeek() {
  weekTitle.innerText = `Tydzień: ${formatWeekDisplay(currentWeek)} (${getWeekDateRange(currentWeek)})`;

  const days = getWeekDays(currentWeek);
  const saved = loadWeekDays(currentWeek);
  const map = {};
  saved.forEach(d => map[d.date] = d);

  const c = document.getElementById("daysContainer");
  c.innerHTML = "";

  days.forEach(d => {
    const x = map[d.date] || {};
    const shop = (x.shop1||0) + (x.shop2||0);
    const total = shop + (x.shippingSum||0);
    
    // Sprawdź czy to niedziela lub święto
    const holidayName = isPublicHoliday(d.date);
    const isHoliday = holidayName !== null;
    const isDayOff = d.isDayOff || isHoliday || x.dayOff === true;
    
    // POMIŃ NIEDZIELĘ - nie pokazuj kafelka
    if (d.isDayOff) {
      return; // Niedziela - pomijamy
    }
    
    if (isDayOff) {
      // Dzień wolny (święto) - CZERWONY kafelek
      const dayOffLabel = isHoliday ? holidayName : "Dzień wolny";
      c.innerHTML += `
        <div class="day-card" style="background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%); border-color: #dc2626; min-height: 60px; display: flex; align-items: center; justify-content: center;">
          <strong style="color: #991b1b; font-size: 16px;">🏖️ ${dayOffLabel.toUpperCase()}</strong>
        </div>`;
    } else {
      // Dzień roboczy - pełne dane
      c.innerHTML += `
        <div class="day-card">
          <strong>${d.label} – ${d.date}</strong><br>
          Sklep: ${shop} zł |
          Paczki: ${x.shippingSum||0} zł |
          <strong>${total} zł</strong>
        </div>`;
    }
  });

  const s = calcWeekSummary(currentWeek);
  sumShop.innerText = s.shop + " zł";
  sumShipping.innerText = s.shippingSum + " zł";
  sumShippingCount.innerText = s.shippingCount + " szt.";
  sumCash.innerText = s.cash + " zł";
  sumTotal.innerText = s.total + " zł";

  // Pobierz zwroty z modułu Zwrotów (ZAWSZE ŚWIEŻE)
  const autoReturns = getReturnsFromModule(currentWeek);
  const returnsDetails = getReturnsDetails(currentWeek);
  
  // Sprawdź czy tydzień zamknięty
  const week = loadWeek(currentWeek);
  const isClosed = week && week.status === "CLOSED";
  
  // Wyświetl informację o zwrotach
  const returnsInfoEl = document.getElementById("returnsInfo");
  if (returnsInfoEl) {
    if (autoReturns > 0) {
      let html = `
        <div style="padding: 10px; background: #dcfce7; border-left: 4px solid #16a34a; border-radius: 6px; margin-top: 10px;">
          <strong>✅ Zwroty z modułu Zwrotów:</strong> ${autoReturns} zł (${returnsDetails.length} zwrotów)
      `;
      
      // Jeśli tydzień zamknięty, pokaż różnicę jeśli jest
      if (isClosed && week.returns !== autoReturns) {
        html += `<br><span style="color: #f59e0b;">⚠️ Zapisane przy zamknięciu: ${week.returns} zł (różnica: ${autoReturns - week.returns} zł)</span>`;
      }
      
      html += `</div>`;
      returnsInfoEl.innerHTML = html;
    } else {
      returnsInfoEl.innerHTML = `
        <div style="padding: 10px; background: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 6px; margin-top: 10px;">
          <strong>⚠️ Brak zwrotów</strong> w module Zwrotów dla tego tygodnia
        </div>
      `;
    }
    
    // AKTUALIZUJ FINAL jeśli tydzień zamknięty i zwroty się zmieniły
    if (isClosed && week.returns !== autoReturns) {
      const newFinal = s.total - autoReturns;
      returnsInfoEl.innerHTML += `
        <div style="padding: 10px; background: #dbeafe; border-left: 4px solid #3b82f6; border-radius: 6px; margin-top: 10px;">
          <strong>📊 FINAL (przeliczony):</strong> ${newFinal} zł
          <br><small style="color: #6b7280;">Zapisany przy zamknięciu: ${week.final} zł</small>
        </div>
      `;
    }
  }

  // Tydzień zamknięty? Pokaż przycisk edycji (week już zadeklarowane wcześniej)
  const editBtn = document.getElementById("editWeekBtn");
  
  if (week && week.status === "CLOSED") {
    if (editBtn) editBtn.style.display = "block";
    closeWeekBtn.style.display = "none";
  } else {
    if (editBtn) editBtn.style.display = "none";
    validateWeek();
  }
  
  // Renderuj logi tygodnia (jeśli funkcja istnieje)
  if (typeof renderWeekLogs === 'function') {
    renderWeekLogs();
  }
}

// ================= WEEK EDIT =================

let editTimer = null;
let editModeActive = false;

function enableWeekEdit() {
  const week = loadWeek(currentWeek);
  if (!week || week.status !== "CLOSED") return;
  
  // SUPER-ADMIN - hasło
  // Sprawdź uprawnienia admin
  if (!requireAdminAccess("Edycja zamkniętego tygodnia")) {
    return;
  }
  
  const confirmed = confirm(`Czy na pewno chcesz edytować zamknięty tydzień ${formatWeekDisplay(currentWeek)}?\n\nOtworzysz formularz edycji wartości dla wszystkich dni.`);
  
  if (!confirmed) return;
  
  // Pobierz dni tygodnia
  const weekDays = getWeekDays(currentWeek);
  const savedDays = loadWeekDays(currentWeek);
  const daysMap = {};
  savedDays.forEach(d => daysMap[d.date] = d);
  
  // Stwórz formularz edycji
  let formHTML = `
    <div style="background: #fef3c7; border: 3px solid #f59e0b; border-radius: 12px; padding: 20px; margin-top: 20px;">
      <h3 style="color: #92400e; margin-top: 0;">✏️ Edycja wartości tygodnia ${formatWeekDisplay(currentWeek)}</h3>
      <p style="color: #78350f;"><strong>Wprowadź poprawione wartości dla każdego dnia:</strong></p>
      
      <div style="display: grid; gap: 15px;">
  `;
  
  // Dla każdego dnia (pomiń niedziela)
  weekDays.forEach(d => {
    if (d.isDayOff) return; // Pomiń niedzielę
    
    // Sprawdź czy to święto
    const holidayName = isPublicHoliday(d.date);
    const isHoliday = holidayName !== null;
    
    if (isHoliday) {
      // Święto - pomiń lub pokaż jako zablokowane
      formHTML += `
        <div style="background: #fee2e2; padding: 15px; border-radius: 8px; border: 2px solid #dc2626;">
          <h4 style="color: #991b1b; margin: 0 0 5px 0;">${d.label} (${d.date}) - ${holidayName}</h4>
          <p style="color: #991b1b; font-size: 14px; margin: 0;">🏖️ Dzień wolny - brak edycji</p>
        </div>
      `;
      return;
    }
    
    const day = daysMap[d.date] || {};
    
    formHTML += `
      <div style="background: white; padding: 15px; border-radius: 8px; border: 2px solid #e5e7eb;">
        <h4 style="margin: 0 0 10px 0; color: #111827;">${d.label} (${d.date})</h4>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
          <div>
            <label style="font-size: 12px; color: #6b7280;">Sklep 1</label>
            <input type="number" id="edit_${d.date}_shop1" value="${day.shop1 || 0}" 
                   style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
          </div>
          <div>
            <label style="font-size: 12px; color: #6b7280;">Sklep 2</label>
            <input type="number" id="edit_${d.date}_shop2" value="${day.shop2 || 0}" 
                   style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
          </div>
          <div>
            <label style="font-size: 12px; color: #6b7280;">Gotówka 1</label>
            <input type="number" id="edit_${d.date}_cash1" value="${day.cash1 || 0}" 
                   style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
          </div>
          <div>
            <label style="font-size: 12px; color: #6b7280;">Gotówka 2</label>
            <input type="number" id="edit_${d.date}_cash2" value="${day.cash2 || 0}" 
                   style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
          </div>
          <div>
            <label style="font-size: 12px; color: #6b7280;">Paczki suma</label>
            <input type="number" id="edit_${d.date}_shippingSum" value="${day.shippingSum || 0}" 
                   style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
          </div>
          <div>
            <label style="font-size: 12px; color: #6b7280;">Paczki ilość</label>
            <input type="number" id="edit_${d.date}_shippingCount" value="${day.shippingCount || 0}" 
                   style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
          </div>
        </div>
      </div>
    `;
  });
  
  formHTML += `
      </div>
      
      <div style="margin-top: 20px; display: flex; gap: 10px;">
        <button onclick="saveWeekEditForm()" style="flex: 1; padding: 12px; background: linear-gradient(135deg, #16a34a 0%, #15803d 100%); color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">
          💾 ZAPISZ ZMIANY
        </button>
        <button onclick="cancelWeekEditForm()" style="flex: 1; padding: 12px; background: #6b7280; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">
          ❌ ANULUJ
        </button>
      </div>
    </div>
  `;
  
  // Wstaw formularz
  const editContainer = document.getElementById('weekEditFormContainer');
  if (editContainer) {
    editContainer.innerHTML = formHTML;
  }
  
  // Ukryj przycisk "Edytuj tydzień"
  document.getElementById("editWeekBtn").style.display = "none";
}

function saveWeekEditForm() {
  const confirmed = confirm("Czy na pewno zapisać zmiany?\n\nWartości zostaną zaktualizowane dla wszystkich dni.");
  if (!confirmed) return;
  
  const weekDays = getWeekDays(currentWeek);
  let changedCount = 0;
  
  weekDays.forEach(d => {
    if (d.isDayOff) return; // Pomiń niedziela
    
    const holidayName = isPublicHoliday(d.date);
    if (holidayName) return; // Pomiń święta
    
    // Pobierz wartości z formularza
    const shop1Input = document.getElementById(`edit_${d.date}_shop1`);
    const shop2Input = document.getElementById(`edit_${d.date}_shop2`);
    const cash1Input = document.getElementById(`edit_${d.date}_cash1`);
    const cash2Input = document.getElementById(`edit_${d.date}_cash2`);
    const shippingSumInput = document.getElementById(`edit_${d.date}_shippingSum`);
    const shippingCountInput = document.getElementById(`edit_${d.date}_shippingCount`);
    
    if (!shop1Input) return; // Pole nie istnieje
    
    // Pobierz stary dzień
    const oldDay = loadDay(d.date) || {};
    
    // Nowe wartości
    const newDay = {
      ...oldDay,
      shop1: parseInt(shop1Input.value) || 0,
      shop2: parseInt(shop2Input.value) || 0,
      cash1: parseInt(cash1Input.value) || 0,
      cash2: parseInt(cash2Input.value) || 0,
      shippingSum: parseInt(shippingSumInput.value) || 0,
      shippingCount: parseInt(shippingCountInput.value) || 0,
      editedAt: new Date().toISOString(),
      editedBy: getUser()
    };
    
    // Zapisz
    saveDay(newDay);
    changedCount++;
  });
  
  // LOG
  addLog("EDIT_WEEK_VALUES", {
    week: currentWeek,
    changedDays: changedCount,
    by: getUser()
  });
  
  alert(`✅ Zapisano zmiany!\n\nZaktualizowano ${changedCount} dni.`);
  
  // Odśwież widok
  location.reload();
}

function cancelWeekEditForm() {
  const confirmed = confirm("Anulować edycję?\n\nWszystkie zmiany zostaną utracone.");
  if (!confirmed) return;
  
  // Wyczyść formularz
  const editContainer = document.getElementById('weekEditFormContainer');
  if (editContainer) {
    editContainer.innerHTML = '';
  }
  
  // Pokaż przycisk "Edytuj tydzień"
  document.getElementById("editWeekBtn").style.display = "block";
}

function startEditTimer() {
  let timeLeft = 30;
  
  const countdown = document.getElementById("editCountdown");
  
  editTimer = setInterval(() => {
    timeLeft--;
    if (countdown) countdown.innerText = timeLeft;
    
    if (timeLeft <= 0) {
      disableWeekEdit();
    }
  }, 1000);
}

function resetEditTimer() {
  if (!editModeActive) return;
  
  // Anuluj stary timer
  if (editTimer) clearInterval(editTimer);
  
  // Restart timera
  startEditTimer();
}

function disableWeekEdit() {
  if (!editModeActive) return;
  
  editModeActive = false;
  
  if (editTimer) {
    clearInterval(editTimer);
    editTimer = null;
  }
  
  // Ukryj komunikat
  const editStatus = document.getElementById("editStatus");
  if (editStatus) editStatus.style.display = "none";
  
  // Przywróć przyciski
  document.getElementById("editWeekBtn").style.display = "block";
  document.getElementById("saveWeekEditBtn").style.display = "none";
  
  alert("Tryb edycji zakończony.");
}

function saveWeekEdit() {
  if (!editModeActive) return;
  
  const confirmed = confirm("Czy na pewno chcesz zapisać zmiany i zakończyć edycję?");
  
  if (!confirmed) return;
  
  disableWeekEdit();
  alert("Zmiany zapisane!");
  location.reload();
}

// ================= CLOSE WEEK =================
function validateWeek() {
  if (!isWeekComplete(currentWeek)) {
    weekError.innerText = "⚠️ Tydzień niekompletny";
    closeWeekBtn.disabled = true;
    return;
  }
  weekError.innerText = "";
  closeWeekBtn.disabled = false;
}

// Sprawdza czy tydzień jest kompletny (wszystkie dni robocze zamknięte)
function isWeekComplete(weekKey) {
  const days = getWeekDays(weekKey);
  const saved = loadWeekDays(weekKey);
  const map = {};
  saved.forEach(d => map[d.date] = d);
  
  // Zlicz dni robocze niezamknięte
  let workingDaysIncomplete = 0;
  
  days.forEach(d => {
    // Pomiń niedziele, święta i ręcznie oznaczone dni wolne
    const holidayName = isPublicHoliday(d.date);
    const isHoliday = holidayName !== null;
    const day = map[d.date];
    const isDayOff = d.isDayOff || isHoliday || day?.dayOff === true;
    
    if (isDayOff) {
      return; // Pomiń dni wolne
    }
    
    // Dzień roboczy - sprawdź czy zamknięty
    if (!day || !day.s1Closed || !day.s2Closed || !day.shippingClosed) {
      workingDaysIncomplete++;
    }
  });
  
  return workingDaysIncomplete === 0;
}

function closeCurrentWeek() {
  if (!isWeekComplete(currentWeek)) return;

  const s = calcWeekSummary(currentWeek);
  
  // Pobierz zwroty z modułu Zwrotów
  const autoReturns = getReturnsFromModule(currentWeek);
  const returnsDetails = getReturnsDetails(currentWeek);
  
  let message = `Zamknąć tydzień ${formatWeekDisplay(currentWeek)}?\n\n`;
  message += `Łączny obrót: ${s.total} zł\n\n`;
  
  if (autoReturns > 0) {
    message += `✅ Automatycznie wykryto zwroty z modułu Zwrotów:\n`;
    message += `Suma zwrotów: ${autoReturns} zł\n`;
    message += `Liczba zwrotów: ${returnsDetails.length}\n\n`;
    message += `FINAL: ${s.total - autoReturns} zł\n\n`;
    message += `Czy chcesz użyć tych danych?`;
  } else {
    message += `⚠️ Brak zwrotów w module Zwrotów dla tego tygodnia.\n\n`;
    message += `FINAL: ${s.total} zł\n\n`;
    message += `Potwierdź zamknięcie.`;
  }
  
  const confirmed = confirm(message);
  
  if (!confirmed) {
    // Opcja ręcznego wprowadzenia
    const manualReturns = prompt("Wprowadź zwroty ręcznie (lub 0):", autoReturns);
    if (manualReturns === null) return; // Anulowano
    
    const returns = +manualReturns || 0;
    closeWeek(currentWeek, { returns, final: s.total - returns });
  } else {
    closeWeek(currentWeek, { returns: autoReturns, final: s.total - autoReturns });
  }
  
  location.reload();
}

// Nawigacja tygodniowa
function prevWeek() {
  const d = makeDate(currentDate);
  d.setDate(d.getDate() - 7); // Tydzień wstecz
  currentDate = formatDate(d);
  currentWeek = getWeekKey(currentDate);
  renderWeek();
}

function nextWeek() {
  const d = makeDate(currentDate);
  d.setDate(d.getDate() + 7); // Tydzień do przodu
  currentDate = formatDate(d);
  currentWeek = getWeekKey(currentDate);
  renderWeek();
}

function goToCurrentWeek() {
  const today = new Date();
  if (today.getDay() === 0) {
    today.setDate(today.getDate() - 1);
  }
  currentDate = formatDate(today);
  currentWeek = getWeekKey(currentDate);
  renderWeek();
}

// ================= NAVIGATION =================
function prevDay() {
  const d = makeDate(currentDate);
  d.setDate(d.getDate() - 1);
  
  // Sprawdź tryb debugowania
  const debugMode = localStorage.getItem("oplex:debug_mode") === "true";
  
  // Blokada: sprawdź datę uruchomienia sklepu (shop_launch_date)
  const shopLaunchDate = localStorage.getItem("oplex:shop_launch_date");
  
  if (!debugMode) {
    // Sprawdź datę uruchomienia sklepu
    if (shopLaunchDate) {
      // Jeśli sklep został uruchomiony - nie cofaj się przed tą datą
      const minDate = makeDate(shopLaunchDate);
      
      if (d < minDate) {
        alert(`🔒 Nie można cofnąć przed datą uruchomienia sklepu\n\nData startu: ${shopLaunchDate}\n\n💡 Sklep działa w trybie produkcyjnym`);
        return;
      }
    }
    // Jeśli sklep nie został uruchomiony - brak blokady
  }
  
  // NIEDZIELA WIDOCZNA - nie pomijamy
  
  currentDate = formatDate(d);
  renderDay();
}

function nextDay() {
  const d = makeDate(currentDate);
  d.setDate(d.getDate() + 1);
  
  // NIEDZIELA WIDOCZNA - nie pomijamy
  // USUNIĘTO BLOKADĘ: Przyszłe dni są dostępne do przeglądania
  // (readonly ustawiane automatycznie w renderDay)
  
  currentDate = formatDate(d);
  renderDay();
}

function goToToday() {
  const today = new Date();
  
  // NIEDZIELA WIDOCZNA - nie pomijamy
  
  currentDate = formatDate(today);
  renderDay();
}

// ================= STATS =================

function renderStats() {
  const t = today();
  const w = getWeekKey(t);
  const m = t.slice(0, 7);
  const y = t.slice(0, 4);

  const el = document.getElementById("statsView");
  
  el.innerHTML = `
    <h3>📊 Statystyki</h3>
    
    <div style="text-align: right; margin-bottom: 10px; color: #6b7280; font-size: 14px;">
      <strong id="activeViewLabel">Aktualnie przeglądasz: Miesiąc</strong>
    </div>
    
    <div class="stats-period-selector">
      <div class="period-item" id="periodDay" onclick="switchToView('day')" style="cursor: pointer;">
        <h4>Dzień</h4>
        <input id="statsDay" type="date" value="${t}" onchange="updateStatsDay()" onclick="event.stopPropagation();">
      </div>
      <div class="period-item" id="periodWeek" onclick="switchToView('week')" style="cursor: pointer;">
        <h4>Tydzień</h4>
        <input id="statsWeek" type="week" value="${w}" onchange="updateStatsWeek()" onclick="event.stopPropagation();">
      </div>
      <div class="period-item active-period" id="periodMonth" onclick="switchToView('month')" style="cursor: pointer;">
        <h4>Miesiąc</h4>
        <input id="statsMonth" type="month" value="${m}" onchange="updateStatsMonth()" onclick="event.stopPropagation();">
      </div>
      <div class="period-item" id="periodYear" onclick="switchToView('year')" style="cursor: pointer;">
        <h4>Rok</h4>
        <input id="statsYear" type="number" value="${y}" min="2026" max="2030" onchange="updateStatsYear()" onclick="event.stopPropagation();">
      </div>
    </div>

    <div class="stats-results">
      <div class="stats-numbers" style="display: flex; gap: 15px; margin-bottom: 30px; flex-wrap: wrap;">
        <div id="statsDayContainer" style="flex: 1; min-width: 200px;"></div>
        <div id="statsWeekContainer" style="flex: 1; min-width: 200px;"></div>
        <div id="statsMonthContainer" style="flex: 1; min-width: 200px;"></div>
        <div id="statsYearContainer" style="flex: 1; min-width: 200px;"></div>
      </div>
      <div id="currentMonthWeeks" class="current-month-weeks"></div>
      <div id="statsAnalysis" class="stats-analysis"></div>
      <div id="statsCharts" class="stats-charts"></div>
    </div>
  `;

  // Renderuj TYLKO miesiąc domyślnie
  updateStatsMonth();
  updateCurrentMonthWeeks(m);
}

// Funkcja przełączania widoku
function switchToView(view) {
  // Usuń active ze wszystkich
  document.querySelectorAll('.period-item').forEach(el => el.classList.remove('active-period'));
  
  // Wyczyść wszystkie kontenery
  document.getElementById('statsDayContainer').innerHTML = '';
  document.getElementById('statsWeekContainer').innerHTML = '';
  document.getElementById('statsMonthContainer').innerHTML = '';
  document.getElementById('statsYearContainer').innerHTML = '';
  document.getElementById('statsAnalysis').innerHTML = '';
  document.getElementById('currentMonthWeeks').innerHTML = '';
  document.getElementById('statsCharts').innerHTML = '';
  
  // Dodaj active do wybranego
  const labelMap = {
    'day': 'Dzień',
    'week': 'Tydzień',
    'month': 'Miesiąc',
    'year': 'Rok'
  };
  
  document.getElementById('activeViewLabel').innerText = `Aktualnie przeglądasz: ${labelMap[view]}`;
  document.getElementById(`period${view.charAt(0).toUpperCase() + view.slice(1)}`).classList.add('active-period');
  
  // Renderuj odpowiedni widok
  if (view === 'day') {
    updateStatsDay();
  } else if (view === 'week') {
    updateStatsWeek();
  } else if (view === 'month') {
    const monthKey = document.getElementById("statsMonth").value;
    updateStatsMonth();
    updateCurrentMonthWeeks(monthKey);
  } else if (view === 'year') {
    updateStatsYear();
  }
}

function updateStatsDay() {
  const date = document.getElementById("statsDay").value;
  const day = loadDay(date);
  
  const container = document.getElementById("statsDayContainer");
  if (!container) return;
  
  // Wyczyść kontenery analiz i wykresów (dzień nie ma wykresów)
  const analysisContainer = document.getElementById("statsAnalysis");
  const chartsContainer = document.getElementById("statsCharts");
  const weeksContainer = document.getElementById("currentMonthWeeks");
  if (analysisContainer) analysisContainer.innerHTML = '';
  if (chartsContainer) chartsContainer.innerHTML = '';
  if (weeksContainer) weeksContainer.innerHTML = '';
  
  // Sprawdź czy to niedziela lub święto
  const dayOfWeek = makeDate(date).getDay();
  const isSunday = dayOfWeek === 0;
  const holidayName = isPublicHoliday(date);
  const isHoliday = holidayName !== null;
  
  if (!day || (day && day.shop1 === 0 && day.shop2 === 0 && day.shippingSum === 0)) {
    // BRAK DANYCH lub DZIEŃ WOLNY - niebieski styl
    let text = "Brak danych";
    if (isSunday) {
      text = "Niedziela";
    } else if (isHoliday) {
      text = holidayName; // Nazwa święta
    }
    container.innerHTML = `
      <div class="week-tile week-tile-empty" style="border-color: #3b82f6; background: #dbeafe;">
        <div class="week-tile-header">Dzień</div>
        <div class="week-tile-key">${date}</div>
        <div class="week-tile-empty-text" style="color: #1e40af;">ℹ️ ${text}</div>
      </div>
    `;
    return;
  }

  const totals = calcDayTotals(day);
  
  container.innerHTML = `
    <div class="stats-card">
      <h4>Dzień ${date}</h4>
      <table class="stats-table">
        <tr><td>Sklep (stanowisko 1+2)</td><td><strong>${totals.shop} zł</strong></td></tr>
        <tr><td>Gotówka (stanowisko 1+2)</td><td>${totals.cash} zł</td></tr>
        <tr><td>Paczki (kasa)</td><td>${totals.shippingSum} zł</td></tr>
        <tr><td>Ilość paczek</td><td>${totals.shippingCount} szt.</td></tr>
        <tr><td><strong>Łączny</strong></td><td><strong>${totals.total} zł</strong></td></tr>
      </table>
    </div>
  `;
}

function updateStatsWeek() {
  const weekInput = document.getElementById("statsWeek").value;
  const weekKey = weekInput;
  
  const week = loadWeek(weekKey);
  const container = document.getElementById("statsWeekContainer");
  if (!container) return;
  
  // Wyczyść kontenery analiz i wykresów (tydzień nie ma wykresów)
  const analysisContainer = document.getElementById("statsAnalysis");
  const chartsContainer = document.getElementById("statsCharts");
  const weeksContainer = document.getElementById("currentMonthWeeks");
  if (analysisContainer) analysisContainer.innerHTML = '';
  if (chartsContainer) chartsContainer.innerHTML = '';
  if (weeksContainer) weeksContainer.innerHTML = '';
  
  if (!week || week.status !== "CLOSED") {
    // NIEZAMKNIĘTY - styl week-tile-empty
    container.innerHTML = `
      <div class="week-tile week-tile-empty">
        <div class="week-tile-header">Tydzień</div>
        <div class="week-tile-key">${weekKey}</div>
        <div class="week-tile-empty-text">⚠️ Nie zamknięty</div>
      </div>
    `;
    return;
  }

  const summary = calcWeekSummary(weekKey);
  const currentReturns = getReturnsFromModule(weekKey);
  const currentFinal = summary.total - currentReturns;
  
  // ZAMKNIĘTY - styl week-tile z danymi
  container.innerHTML = `
    <div class="week-tile">
      <div class="week-tile-header">Tydzień</div>
      <div class="week-tile-key">${weekKey}</div>
      <div class="week-tile-stats">
        <div class="week-tile-row">
          <span>Sklep:</span>
          <strong>${summary.shop} zł</strong>
        </div>
        <div class="week-tile-row">
          <span>Gotówka:</span>
          <span>${summary.cash} zł</span>
        </div>
        <div class="week-tile-row">
          <span>Paczki:</span>
          <span>${summary.shippingSum} zł</span>
        </div>
        <div class="week-tile-divider"></div>
        <div class="week-tile-row week-tile-total">
          <span>Łączny:</span>
          <strong>${summary.total} zł</strong>
        </div>
        <div class="week-tile-row">
          <span>Zwroty:</span>
          <span>${currentReturns} zł</span>
        </div>
        <div class="week-tile-row week-tile-final">
          <span>FINAL:</span>
          <strong>${currentFinal} zł</strong>
        </div>
      </div>
    </div>
  `;
}

function updateStatsMonth() {
  const monthKey = document.getElementById("statsMonth").value;
  const summary = calcMonthFromDays(monthKey);
  
  const container = document.getElementById("statsMonthContainer");
  if (!container) return;
  
  container.innerHTML = `
    <div class="stats-card">
      <h4>Miesiąc ${monthKey}</h4>
      <table class="stats-table">
        <tr><td>Sklep (stanowisko 1+2)</td><td><strong>${summary.shop} zł</strong></td></tr>
        <tr><td>Gotówka (stanowisko 1+2)</td><td>${summary.cash} zł</td></tr>
        <tr><td>Paczki (kasa)</td><td>${summary.shippingSum} zł</td></tr>
        <tr><td>Ilość paczek</td><td>${summary.shippingCount} szt.</td></tr>
        <tr><td><strong>Łączny</strong></td><td><strong>${summary.total} zł</strong></td></tr>
      </table>
    </div>
  `;

  // Wyczyść kontener analiz
  const analysisContainer = document.getElementById("statsAnalysis");
  if (analysisContainer) analysisContainer.innerHTML = '';

  // 1. Analiza
  const analysis = getBestWorstDay(monthKey);
  
  if (analysis.best && analysis.worst) {
    analysisContainer.innerHTML = `
      <div class="stats-card">
        <h4>📈 Najlepszy i najgorszy dzień w miesiącu ${monthKey}</h4>
        <table class="stats-table">
          <tr>
            <td>🏆 Najlepszy dzień</td>
            <td><strong>${analysis.best.date}</strong></td>
            <td><strong>${analysis.best.total} zł</strong></td>
          </tr>
          <tr>
            <td>📉 Najgorszy dzień</td>
            <td>${analysis.worst.date}</td>
            <td>${analysis.worst.total} zł</td>
          </tr>
        </table>
      </div>
    `;
  }

  // Wyczyść kontener wykresów przed dodaniem nowych
  const chartsContainer = document.getElementById("statsCharts");
  if (chartsContainer) {
    // ZNISZCZ stare instancje Chart.js
    destroyAllCharts();
    
    // Stwórz grid 2x2 dla wykresów
    chartsContainer.innerHTML = `
      <div class="charts-grid">
        <div class="chart-tile">
          <h4>Obrót sklepu</h4>
          <canvas id="chartMonthShopCash"></canvas>
        </div>
        <div class="chart-tile">
          <h4>Paczki (wartość)</h4>
          <canvas id="chartMonthPackagesCash"></canvas>
        </div>
        <div class="chart-tile">
          <h4>Paczki (ilość)</h4>
          <canvas id="chartMonthPackagesCount"></canvas>
        </div>
        <div class="chart-tile">
          <h4>Łączny - Zwroty</h4>
          <canvas id="chartMonthFinal"></canvas>
        </div>
      </div>
    `;
  }
  
  // Renderuj nowe wykresy
  renderMonthChart1(monthKey); // Obrót sklepu
  renderMonthChart2(monthKey); // Paczki (wartość)
  renderMonthChart3(monthKey); // Paczki (ilość)
  renderMonthChart4(monthKey); // Łączny - Zwroty
  
  // Aktualizuj tygodnie miesiąca (4 kafelki)
  updateCurrentMonthWeeks(monthKey);
}

function updateStatsYear() {
  const year = document.getElementById("statsYear").value;
  const summary = calcYearFromDays(year);
  
  const container = document.getElementById("statsYearContainer");
  if (!container) return;
  
  container.innerHTML = `
    <div class="stats-card">
      <h4>Rok ${year}</h4>
      <table class="stats-table">
        <tr><td>Sklep (stanowisko 1+2)</td><td><strong>${summary.shop} zł</strong></td></tr>
        <tr><td>Gotówka (stanowisko 1+2)</td><td>${summary.cash} zł</td></tr>
        <tr><td>Paczki (kasa)</td><td>${summary.shippingSum} zł</td></tr>
        <tr><td>Ilość paczek</td><td>${summary.shippingCount} szt.</td></tr>
        <tr><td><strong>Łączny</strong></td><td><strong>${summary.total} zł</strong></td></tr>
      </table>
    </div>
  `;

  // Wyczyść kontenery analiz, tygodni i wykresów
  const analysisContainer = document.getElementById("statsAnalysis");
  const weeksContainer = document.getElementById("currentMonthWeeks");
  const chartsContainer = document.getElementById("statsCharts");
  if (analysisContainer) analysisContainer.innerHTML = '';
  if (weeksContainer) weeksContainer.innerHTML = '';
  if (chartsContainer) {
    // ZNISZCZ stare instancje Chart.js
    destroyAllCharts();
    
    // Stwórz grid 2x2 dla wykresów
    chartsContainer.innerHTML = `
      <div class="charts-grid">
        <div class="chart-tile">
          <h4>Obrót sklepu</h4>
          <canvas id="chartYearShopCash"></canvas>
        </div>
        <div class="chart-tile">
          <h4>Paczki (wartość)</h4>
          <canvas id="chartYearPackagesCash"></canvas>
        </div>
        <div class="chart-tile">
          <h4>Paczki (ilość)</h4>
          <canvas id="chartYearPackagesCount"></canvas>
        </div>
        <div class="chart-tile">
          <h4>Łączny - Zwroty</h4>
          <canvas id="chartYearFinal"></canvas>
        </div>
      </div>
    `;
  }

  // Renderuj nowe wykresy
  renderYearChart1(year); // Obrót sklepu
  renderYearChart2(year); // Paczki (wartość)
  renderYearChart3(year); // Paczki (ilość)
  renderYearChart4(year); // Łączny - Zwroty
}

// ================= WYKRESY V3.0 =================

function getMonthName(month) {
  const names = [
    "Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec",
    "Lipiec", "Sierpień", "Wrzesień", "Październik", "Listopad", "Grudzień"
  ];
  return names[month - 1];
}

// ========== WYKRESY MIESIĄCA (4 sztuki) ==========

// 1. Obrót sklepu (bez gotówki i paczek)
function renderMonthChart1(monthKey) {
  const weeks = getWeeksInMonth(monthKey, true);
  if (weeks.length === 0) return;
  
  const labels = weeks.map(w => formatWeekDisplay(w.weekKey));
  const data = weeks.map(w => w.shop);
  
  const ctx = document.getElementById("chartMonthShopCash");
  if (!ctx) return;
  
  window.chartInstances.month1 = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Obrót sklepu",
        data: data,
        backgroundColor: "#3b82f6",
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          color: '#111827',
          font: { weight: 'bold', size: 11 },
          formatter: (value) => value === 0 ? '' : value.toLocaleString('pl-PL') + ' zł'
        }
      },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// 2. Paczki (wartość)
function renderMonthChart2(monthKey) {
  const weeks = getWeeksInMonth(monthKey, true);
  if (weeks.length === 0) return;
  
  const labels = weeks.map(w => formatWeekDisplay(w.weekKey));
  const data = weeks.map(w => w.shippingSum);
  
  const ctx = document.getElementById("chartMonthPackagesCash");
  if (!ctx) return;
  
  window.chartInstances.month2 = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Paczki (wartość)",
        data: data,
        backgroundColor: "#facc15",
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          color: '#111827',
          font: { weight: 'bold', size: 11 },
          formatter: (value) => value === 0 ? '' : value.toLocaleString('pl-PL') + ' zł'
        }
      },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// 3. Paczki (ilość)
function renderMonthChart3(monthKey) {
  const weeks = getWeeksInMonth(monthKey, true);
  if (weeks.length === 0) return;
  
  const labels = weeks.map(w => formatWeekDisplay(w.weekKey));
  const data = weeks.map(w => w.shippingCount);
  
  const ctx = document.getElementById("chartMonthPackagesCount");
  if (!ctx) return;
  
  window.chartInstances.month3 = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Paczki (ilość)",
        data: data,
        backgroundColor: "#10b981",
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          color: '#111827',
          font: { weight: 'bold', size: 11 },
          formatter: (value) => value === 0 ? '' : value + ' szt.'
        }
      },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// 4. Łączny - Zwroty
function renderMonthChart4(monthKey) {
  const weeks = getWeeksInMonth(monthKey, true);
  if (weeks.length === 0) return;
  
  const labels = weeks.map(w => formatWeekDisplay(w.weekKey));
  const data = weeks.map(w => w.finalValue);
  
  const ctx = document.getElementById("chartMonthFinal");
  if (!ctx) return;
  
  window.chartInstances.month4 = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [{
        label: "Łączny - Zwroty",
        data: data,
        backgroundColor: "#8b5cf6",
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          color: '#111827',
          font: { weight: 'bold', size: 11 },
          formatter: (value) => value === 0 ? '' : value.toLocaleString('pl-PL') + ' zł'
        }
      },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// ========== WYKRESY ROKU (4 sztuki) ==========

// 1. Obrót sklepu (bez gotówki i paczek) - miesiące
function renderYearChart1(year) {
  const months = [];
  const data = [];
  
  for (let i = 1; i <= 12; i++) {
    const monthKey = `${year}-${String(i).padStart(2, "0")}`;
    const monthData = calcMonthFromDays(monthKey);
    months.push(getMonthName(i));
    data.push(monthData.shop);
  }
  
  const ctx = document.getElementById("chartYearShopCash");
  if (!ctx) return;
  
  window.chartInstances.year1 = new Chart(ctx, {
    type: "bar",
    data: {
      labels: months,
      datasets: [{
        label: "Obrót sklepu",
        data: data,
        backgroundColor: "#3b82f6",
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          color: '#111827',
          font: { weight: 'bold', size: 10 },
          formatter: (value) => value === 0 ? '' : (value / 1000).toFixed(0) + 'k zł'
        }
      },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// 2. Paczki (wartość) - miesiące
function renderYearChart2(year) {
  const months = [];
  const data = [];
  
  for (let i = 1; i <= 12; i++) {
    const monthKey = `${year}-${String(i).padStart(2, "0")}`;
    const monthData = calcMonthFromDays(monthKey);
    months.push(getMonthName(i));
    data.push(monthData.shippingSum);
  }
  
  const ctx = document.getElementById("chartYearPackagesCash");
  if (!ctx) return;
  
  window.chartInstances.year2 = new Chart(ctx, {
    type: "bar",
    data: {
      labels: months,
      datasets: [{
        label: "Paczki (wartość)",
        data: data,
        backgroundColor: "#facc15",
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          color: '#111827',
          font: { weight: 'bold', size: 10 },
          formatter: (value) => value === 0 ? '' : (value / 1000).toFixed(0) + 'k zł'
        }
      },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// 3. Paczki (ilość) - miesiące
function renderYearChart3(year) {
  const months = [];
  const data = [];
  
  for (let i = 1; i <= 12; i++) {
    const monthKey = `${year}-${String(i).padStart(2, "0")}`;
    const monthData = calcMonthFromDays(monthKey);
    months.push(getMonthName(i));
    data.push(monthData.shippingCount);
  }
  
  const ctx = document.getElementById("chartYearPackagesCount");
  if (!ctx) return;
  
  window.chartInstances.year3 = new Chart(ctx, {
    type: "bar",
    data: {
      labels: months,
      datasets: [{
        label: "Paczki (ilość)",
        data: data,
        backgroundColor: "#10b981",
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          color: '#111827',
          font: { weight: 'bold', size: 10 },
          formatter: (value) => value === 0 ? '' : value + ' szt.'
        }
      },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// 4. Łączny - Zwroty - miesiące
function renderYearChart4(year) {
  const months = [];
  const data = [];
  
  for (let i = 1; i <= 12; i++) {
    const monthKey = `${year}-${String(i).padStart(2, "0")}`;
    const monthData = calcMonthFromDays(monthKey);
    months.push(getMonthName(i));
    // Łączny - Zwroty (final value)
    data.push(monthData.total - (monthData.returns || 0));
  }
  
  const ctx = document.getElementById("chartYearFinal");
  if (!ctx) return;
  
  window.chartInstances.year4 = new Chart(ctx, {
    type: "bar",
    data: {
      labels: months,
      datasets: [{
        label: "Łączny - Zwroty",
        data: data,
        backgroundColor: "#8b5cf6",
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          anchor: 'end',
          align: 'top',
          color: '#111827',
          font: { weight: 'bold', size: 10 },
          formatter: (value) => value === 0 ? '' : (value / 1000).toFixed(0) + 'k zł'
        }
      },
      scales: { y: { beginAtZero: true } }
    }
  });
}

// ========== STARE FUNKCJE (DO USUNIĘCIA PÓŹNIEJ) ==========

// ================= ZARZĄDZANIE =================

function renderManage() {
  // Funkcja wywoływana przy otwarciu zakładki Zarządzanie
  updateWeeksLabel();
  
  // Sprawdź stan trybu debugowania
  const debugMode = localStorage.getItem("oplex:debug_mode") === "true";
  const checkbox = document.getElementById("debugMode");
  const debugInfo = document.getElementById("debugInfo");
  
  if (checkbox) checkbox.checked = debugMode;
  if (debugInfo) debugInfo.style.display = debugMode ? "block" : "none";
  
  // Renderuj logi (jeśli funkcja istnieje)
  if (typeof refreshLogs === 'function') {
    refreshLogs();
  }
  
  // Renderuj backupy (jeśli funkcja istnieje)
  if (typeof renderBackupsList === 'function') {
    renderBackupsList();
  }
}

function toggleDebugMode() {
  const checkbox = document.getElementById("debugMode");
  const debugInfo = document.getElementById("debugInfo");
  const isEnabled = checkbox.checked;
  
  // SUPER-ADMIN - hasło wymagane TYLKO przy włączaniu
  if (isEnabled) {
    // Sprawdź uprawnienia admin
    if (!requireAdminAccess("Włączenie trybu debugowania")) {
      checkbox.checked = false; // Cofnij checkbox
      return;
    }
  }
  
  localStorage.setItem("oplex:debug_mode", isEnabled);
  
  if (debugInfo) {
    debugInfo.style.display = isEnabled ? "block" : "none";
  }
  
  if (isEnabled) {
    alert("🔧 Tryb debugowania WŁĄCZONY\n\n" +
          "✅ Odblokowano cofanie dat przed uruchomieniem sklepu\n" +
          "✅ Możliwość testowania na różnych okresach\n" +
          "✅ Generator danych testowych dostępny");
  } else {
    alert("🔒 Tryb debugowania WYŁĄCZONY\n\n" +
          "Przywrócono normalne limity dat.\n" +
          "Generator danych testowych zablokowany.");
  }
}

function updateWeeksLabel() {
  const weeks = document.getElementById("weeksRange").value;
  document.getElementById("weeksLabel").innerText = `${weeks} ${weeks == 1 ? 'tydzień' : weeks < 5 ? 'tygodnie' : 'tygodni'}`;
}

// Generator danych testowych
function generateTestData() {
  // ZABEZPIECZENIE: Generator dostępny tylko w trybie debugowania
  const debugMode = localStorage.getItem("oplex:debug_mode") === "true";
  
  if (!debugMode) {
    alert("⚠️ Generator testowy wymaga trybu debugowania!\n\n" +
          "Włącz tryb debugowania w zakładce Zarządzanie,\n" +
          "aby móc generować dane testowe.");
    return;
  }
  
  const weeks = parseInt(document.getElementById("weeksRange").value);
  const startDateStr = document.getElementById("startDate").value;
  
  if (!startDateStr) {
    alert("Wybierz datę początkową!");
    return;
  }
  
  const confirmed = confirm(`Czy na pewno wygenerować ${weeks} tygodni danych testowych?\n\nRozpoczną się od: ${startDateStr}`);
  
  if (!confirmed) return;
  
  const statusEl = document.getElementById("generatorStatus");
  statusEl.innerHTML = "⏳ Generowanie...";
  
  setTimeout(() => {
    try {
      // KROK 1: Zamknij wszystkie otwarte tygodnie przed generowaniem
      const allWeeks = loadWeeks();
      const openWeeks = allWeeks.filter(w => w.status === "OPEN");
      
      if (openWeeks.length > 0) {
        statusEl.innerHTML = `⏳ Zamykanie ${openWeeks.length} otwartych tygodni...`;
        
        openWeeks.forEach(week => {
          const returns = getReturnsFromModule(week.weekKey);
          const summary = calcWeekSummary(week.weekKey);
          
          closeWeek(week.weekKey, {
            returns: returns,
            final: summary.total - returns
          });
        });
      }
      
      statusEl.innerHTML = "⏳ Generowanie danych...";
      
      let startDate = makeDate(startDateStr);
      let generatedWeeks = 0;
      let generatedDays = 0;
      
      for (let w = 0; w < weeks; w++) {
        // Oblicz datę poniedziałku dla tego tygodnia
        const monday = new Date(startDate);
        monday.setDate(startDate.getDate() + (w * 7));
        
        // Pomiń jeśli niedziela
        if (monday.getDay() === 0) {
          monday.setDate(monday.getDate() + 1);
        }
        
        const weekKey = getWeekKey(formatDate(monday));
        
        // POPRAWKA: Zamknij poprzedni tydzień przed otwarciem nowego
        if (w > 0) {
          const prevMonday = new Date(startDate);
          prevMonday.setDate(startDate.getDate() + ((w - 1) * 7));
          const prevWeekKey = getWeekKey(formatDate(prevMonday));
          
          const prevWeek = loadWeek(prevWeekKey);
          if (prevWeek && prevWeek.status === "OPEN") {
            // Pobierz zwroty z modułu Zwrotów
            const returns = getReturnsFromModule(prevWeekKey);
            const prevSummary = calcWeekSummary(prevWeekKey);
            
            closeWeek(prevWeekKey, {
              returns: returns,
              final: prevSummary.total - returns
            });
          }
        }
        
        // Sprawdź czy tydzień już istnieje
        if (loadWeek(weekKey)) {
          continue; // Pomiń jeśli już istnieje
        }
        
        // Otwórz tydzień
        openWeek(weekKey);
        
        // Generuj 7 dni (Pon-Nie)
        const days = getWeekDays(weekKey);
        
        days.forEach(dayInfo => {
          // Sprawdź czy to niedziela (dzień wolny)
          const isDayOff = dayInfo.isDayOff;
          
          // Dla niedzieli generuj 0, dla innych dni normalne wartości
          const shop1Val = isDayOff ? 0 : Math.floor(Math.random() * 3000) + 1000;
          const shop2Val = isDayOff ? 0 : Math.floor(Math.random() * 3000) + 1000;
          const cash1Val = isDayOff ? 0 : Math.floor(Math.random() * 500);
          const cash2Val = isDayOff ? 0 : Math.floor(Math.random() * 500);
          const shippingVal = isDayOff ? 0 : Math.floor(Math.random() * 2000) + 500;
          const shippingCountVal = isDayOff ? 0 : Math.floor(Math.random() * 50) + 10;
          
          const timestamp = new Date().toISOString();
          
          const day = {
            date: dayInfo.date,
            week: weekKey,
            shop1: shop1Val,
            shop2: shop2Val,
            cash1: cash1Val,
            cash2: cash2Val,
            shippingSum: shippingVal,
            shippingCount: shippingCountVal,
            s1User: "GENERATOR",
            s2User: "GENERATOR",
            s1Closed: true,
            s2Closed: true,
            shippingClosed: true,
            s1ClosedAt: timestamp,
            s2ClosedAt: timestamp,
            shippingClosedAt: timestamp,
            s1ClosedBy: "GENERATOR",
            s2ClosedBy: "GENERATOR",
            shippingClosedBy: "GENERATOR",
            dayOff: isDayOff // Oznacz niedzielę i święta jako dni wolne
          };
          
          saveDay(day);
          generatedDays++;
        });
        
        generatedWeeks++;
      }
      
      // Zamknij ostatni tydzień
      if (generatedWeeks > 0) {
        const lastMonday = new Date(startDate);
        lastMonday.setDate(startDate.getDate() + ((weeks - 1) * 7));
        const lastWeekKey = getWeekKey(formatDate(lastMonday));
        
        const lastWeek = loadWeek(lastWeekKey);
        if (lastWeek && lastWeek.status === "OPEN") {
          const returns = getReturnsFromModule(lastWeekKey);
          const lastSummary = calcWeekSummary(lastWeekKey);
          
          closeWeek(lastWeekKey, {
            returns: returns,
            final: lastSummary.total - returns
          });
        }
      }
      
      // LOG
      addLog("GENERATE_DATA", {
        weeks: generatedWeeks,
        days: generatedDays,
        startDate: startDateStr
      });
      
      statusEl.innerHTML = `✅ Wygenerowano:<br>- ${generatedWeeks} tygodni<br>- ${generatedDays} dni<br><br><em>Odśwież stronę aby zobaczyć dane</em>`;
      
    } catch (err) {
      statusEl.innerHTML = `❌ Błąd: ${err.message}`;
    }
  }, 100);
}

// Reset wszystkich danych
function resetAllData() {
  // Sprawdź uprawnienia admin
  if (!requireAdminAccess("Reset wszystkich danych")) {
    return;
  }
  
  const confirmed = confirm("⚠️ CZY NA PEWNO?\n\nUsuń WSZYSTKIE dane z localStorage?\n\nOperacja NIEODWRACALNA!");
  
  if (!confirmed) return;
  
  const doubleConfirm = confirm("Ostatnie potwierdzenie!\n\nNaprawdę usunąć wszystkie dane?");
  
  if (!doubleConfirm) return;
  
  // LOG przed usunięciem
  addLog("RESET_DATA", {
    daysCount: loadDays().length,
    weeksCount: loadWeeks().length,
    logsCount: loadLogs().length
  });
  
  localStorage.removeItem(DAYS_KEY);
  localStorage.removeItem(WEEKS_KEY);
  localStorage.removeItem(LOGS_KEY);
  
  alert("✅ Wszystkie dane zostały usunięte!\n\nStrona zostanie odświeżona.");
  location.reload();
}

// ============ SUPER-ADMIN: URUCHOM SKLEP ============
function launchShop() {
  // Sprawdź uprawnienia admin
  if (!requireAdminAccess("Uruchomienie sklepu (reset systemu)")) {
    return;
  }
  
  // Krok 1: Potwierdzenie
  const confirmed = confirm(
    "🚀 URUCHOMIENIE SKLEPU\n\n" +
    "Ta operacja:\n" +
    "• Wyczyści WSZYSTKIE dane\n" +
    "• Wygeneruje aktualny tydzień z wartościami 0\n" +
    "• Ustawi start na dzisiaj (" + formatDate(new Date()) + ")\n" +
    "• Zablokuje cofanie wstecz\n" +
    "• Wyłączy tryb debugowania\n\n" +
    "CZY NA PEWNO URUCHOMIĆ SKLEP?"
  );
  
  if (!confirmed) return;
  
  // Krok 2: Ostatnie potwierdzenie
  const finalConfirm = confirm(
    "OSTATNIE POTWIERDZENIE!\n\n" +
    "Po tej operacji nie będzie można cofnąć zmian.\n" +
    "Sklep zostanie uruchomiony w trybie produkcyjnym.\n\n" +
    "KONTYNUOWAĆ?"
  );
  
  if (!finalConfirm) return;
  
  // Krok 5: Wykonanie
  try {
    // LOG przed usunięciem (dla historii)
    addLog("LAUNCH_SHOP", {
      date: formatDate(new Date()),
      by: getUser(),
      daysCount: loadDays().length,
      weeksCount: loadWeeks().length,
      note: "Uruchomienie sklepu - super-admin"
    });
    
    // Eksport backupu przed czyszczeniem (opcjonalnie)
    const createBackup = confirm("Czy utworzyć backup przed czyszczeniem?\n\n(Zalecane!)");
    
    if (createBackup) {
      exportData(); // Pobierze plik JSON
      alert("Backup utworzony!\n\nKlik OK aby kontynuować uruchomienie sklepu.");
    }
    
    // Wyczyść wszystkie dane
    localStorage.removeItem(DAYS_KEY);
    localStorage.removeItem(WEEKS_KEY);
    localStorage.removeItem(LOGS_KEY);
    
    // Wyłącz tryb debugowania
    localStorage.setItem("oplex:debug_mode", "false");
    
    // Ustaw datę startową na dzisiaj
    const today = new Date();
    const todayStr = formatDate(today);
    localStorage.setItem("oplex:shop_launch_date", todayStr);
    
    // ========== GENERUJ AKTUALNY TYDZIEŃ Z WARTOŚCIAMI 0 ==========
    // Zapobiega bugom - system gotowy od razu do pracy
    const currentWeekKey = getWeekKey(todayStr);
    const weekDays = getWeekDays(currentWeekKey);
    
    let generatedDays = 0;
    
    weekDays.forEach(d => {
      // Sprawdź czy to niedziela lub święto
      const holidayName = isPublicHoliday(d.date);
      const isHoliday = holidayName !== null;
      const isDayOff = d.isDayOff || isHoliday;
      
      // Stwórz dzień z wartościami 0
      const day = {
        date: d.date,
        week: currentWeekKey,  // DODANE - KRYTYCZNE!
        shop1: 0,
        shop2: 0,
        cash1: 0,
        cash2: 0,
        shippingSum: 0,
        shippingCount: 0,
        s1Closed: false,  // OTWARTE
        s2Closed: false,  // OTWARTE
        shippingClosed: false,  // OTWARTE
        s1ClosedAt: null,
        s2ClosedAt: null,
        shippingClosedAt: null,
        s1ClosedBy: null,
        s2ClosedBy: null,
        shippingClosedBy: null,
        dayOff: isDayOff,  // Oznacz święta/niedziele
        createdAt: new Date().toISOString(),
        createdBy: "SYSTEM"
      };
      
      saveDay(day);
      generatedDays++;
    });
    
    console.log(`[LAUNCH] Wygenerowano ${generatedDays} dni aktualnego tygodnia (${currentWeekKey}) z wartościami 0`);
    
    // LOG uruchomienia
    addLog("SHOP_LAUNCHED", {
      launchDate: todayStr,
      currentWeek: currentWeekKey,
      generatedDays: generatedDays,
      by: getUser(),
      timestamp: new Date().toISOString()
    });
    
    alert(
      "✅ SKLEP URUCHOMIONY!\n\n" +
      "Data startu: " + todayStr + "\n" +
      "Tydzień: " + formatWeekDisplay(currentWeekKey) + "\n" +
      "Wygenerowano: " + generatedDays + " dni z wartościami 0\n" +
      "Tryb: Produkcyjny\n" +
      "Status: Aktywny\n\n" +
      "Strona zostanie odświeżona."
    );
    
    location.reload();
    
  } catch (error) {
    alert("❌ BŁĄD podczas uruchamiania sklepu!\n\n" + error.message);
    console.error("Launch shop error:", error);
  }
}

// Eksport danych
function exportData() {
  const data = {
    days: loadDays(),
    weeks: loadWeeks(),
    exportDate: new Date().toISOString(),
    version: "1.0"
  };
  
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `obrot-backup-${formatDate(new Date())}.json`;
  a.click();
  
  URL.revokeObjectURL(url);
  
  // LOG
  addLog("EXPORT_DATA", {
    daysCount: data.days.length,
    weeksCount: data.weeks.length
  });
  
  alert("✅ Dane zostały wyeksportowane!");
}

// Import danych
// Odblokuj import danych (SUPER-ADMIN)
function unlockImport() {
  // Sprawdź uprawnienia admin
  if (!requireAdminAccess("Odblokowanie importu danych")) {
    return;
  }
  
  // Odblokuj przycisk
  const importBtn = document.getElementById("importBtn");
  if (!importBtn) return;
  
  importBtn.disabled = false;
  importBtn.style.opacity = "1";
  importBtn.style.cursor = "pointer";
  importBtn.innerText = "📤 Importuj dane (ODBLOKOWANE)";
  importBtn.onclick = function() {
    document.getElementById('importFile').click();
  };
  
  alert("✅ Import odblokowany na 60 sekund!\n\nMożesz teraz zaimportować dane.");
  
  // Auto-blokada po 60 sekundach
  setTimeout(() => {
    importBtn.disabled = true;
    importBtn.style.opacity = "0.5";
    importBtn.style.cursor = "not-allowed";
    importBtn.innerText = "🔒 Importuj dane (ZABLOKOWANE)";
    importBtn.onclick = null;
    
    alert("⏰ Import został automatycznie zablokowany.\n\nDla bezpieczeństwa systemu.");
  }, 60000);
}

function importData(input) {
  const file = input.files[0];
  if (!file) return;
  
  const reader = new FileReader();
  
  reader.onload = function(e) {
    try {
      const data = JSON.parse(e.target.result);
      
      if (!data.days || !data.weeks) {
        alert("❌ Nieprawidłowy format pliku!");
        return;
      }
      
      const confirmed = confirm(`Importować dane?\n\nDni: ${data.days.length}\nTygodni: ${data.weeks.length}\n\n⚠️ Istniejące dane zostaną NADPISANE!`);
      
      if (!confirmed) return;
      
      saveDays(data.days);
      saveWeeks(data.weeks);
      
      // LOG
      addLog("IMPORT_DATA", {
        daysCount: data.days.length,
        weeksCount: data.weeks.length,
        fileName: file.name
      });
      
      alert("✅ Dane zostały zaimportowane!\n\nStrona zostanie odświeżona.");
      location.reload();
      
    } catch (err) {
      alert(`❌ Błąd podczas importu: ${err.message}`);
    }
  };
  
  reader.readAsText(file);
  
  // Reset input
  input.value = '';
}

// ================= TYGODNIE BIEŻĄCEGO MIESIĄCA =================

function updateCurrentMonthWeeks(monthKey) {
  const container = document.getElementById("currentMonthWeeks");
  
  // SPECJALNA LOGIKA DLA STYCZNIA 2026
  // Ukryj kafelki dopóki nie pojawią się pierwsze dane
  if (monthKey === "2026-01") {
    const allDays = loadDays();
    if (allDays.length === 0) {
      container.innerHTML = `
        <div class="stats-info">
          <strong>📅 Początek działania systemu</strong><br>
          Kafelki tygodni pojawią się po wprowadzeniu pierwszych danych.
        </div>
      `;
      return;
    }
  }
  
  // Pobierz WSZYSTKIE tygodnie z bieżącego miesiąca (nie tylko zamknięte)
  const allWeeks = getWeeksInMonth(monthKey, false); // false = wszystkie, nie tylko zamknięte
  
  // Identyfikuj pierwsze 4 tygodnie miesiąca
  // Generujemy klucze tygodni dla pierwszych 4 tygodni
  const firstDayOfMonth = makeDate(monthKey + "-01");
  const potentialWeeks = [];
  
  for (let i = 0; i < 4; i++) {
    const weekDate = new Date(firstDayOfMonth);
    weekDate.setDate(firstDayOfMonth.getDate() + (i * 7));
    const weekKey = getWeekKey(formatDate(weekDate));
    potentialWeeks.push(weekKey);
  }
  
  // Pobierz unikalne klucze tygodni
  const uniqueWeeks = [...new Set(potentialWeeks)].slice(0, 4);
  
  // Nazwy miesięcy
  const monthNames = [
    "styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec",
    "lipiec", "sierpień", "wrzesień", "październik", "listopad", "grudzień"
  ];
  const [year, month] = monthKey.split("-");
  const monthName = monthNames[parseInt(month) - 1];
  
  let html = `<h4 style="margin: 20px 0 10px 0; color: #111827;">📅 Aktualny miesiąc: ${monthName} ${year}</h4>`;
  html += '<div class="month-weeks-grid">';
  
  uniqueWeeks.forEach((weekKey, index) => {
    const weekData = allWeeks.find(w => w.weekKey === weekKey);
    
    if (weekData && weekData.status === "CLOSED") {
      // Tydzień zamknięty - pokaż pełne dane
      html += `
        <div class="week-tile">
          <div class="week-tile-header">Tydzień ${index + 1}</div>
          <div class="week-tile-key">${weekData.weekKey}</div>
          <div class="week-tile-stats">
            <div class="week-tile-row">
              <span>Sklep:</span>
              <strong>${weekData.shop} zł</strong>
            </div>
            <div class="week-tile-row">
              <span>Paczki:</span>
              <strong>${weekData.shippingSum} zł</strong>
            </div>
            <div class="week-tile-row">
              <span>Ilość:</span>
              <strong>${weekData.shippingCount} szt.</strong>
            </div>
            <div class="week-tile-divider"></div>
            <div class="week-tile-row week-tile-total">
              <span>Łączny:</span>
              <strong>${weekData.total} zł</strong>
            </div>
            <div class="week-tile-row">
              <span>Zwroty:</span>
              <strong>${weekData.returns} zł</strong>
            </div>
            <div class="week-tile-row week-tile-final">
              <span>FINAL:</span>
              <strong>${weekData.final} zł</strong>
            </div>
          </div>
        </div>
      `;
    } else {
      // Tydzień otwarty lub nie istnieje - pusty kafelek
      html += `
        <div class="week-tile week-tile-empty">
          <div class="week-tile-header">Tydzień ${index + 1}</div>
          <div class="week-tile-key">${weekKey}</div>
          <div class="week-tile-empty-text">⚠️ Nie zamknięty</div>
        </div>
      `;
    }
  });
  
  html += '</div>';
  
  container.innerHTML = html;
}
// ================= LOGI - ZARZĄDZANIE =================

function refreshLogs() {
  const logs = getRecentLogs(50);
  const container = document.getElementById("logsContainer");
  const countEl = document.getElementById("logsCount");
  
  if (!container) return;
  
  const totalLogs = loadLogs().length;
  if (countEl) {
    countEl.innerText = `Łącznie: ${totalLogs} logów`;
  }
  
  if (logs.length === 0) {
    container.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 20px;">Brak logów</p>';
    return;
  }
  
  let html = '<table style="width: 100%; font-size: 12px;">';
  html += '<thead><tr style="background: #fff;"><th style="padding: 8px; text-align: left;">Data</th><th>Użytkownik</th><th>Akcja</th><th>Szczegóły</th></tr></thead>';
  html += '<tbody>';
  
  logs.forEach(log => {
    const date = new Date(log.timestamp);
    const dateStr = date.toLocaleString('pl-PL');
    const actionText = getActionText(log.action);
    const details = getActionDetails(log);
    
    html += `
      <tr style="border-bottom: 1px solid #e5e7eb;">
        <td style="padding: 8px;">${dateStr}</td>
        <td style="padding: 8px;"><strong>${log.user}</strong></td>
        <td style="padding: 8px;">${actionText}</td>
        <td style="padding: 8px; color: #6b7280;">${details}</td>
      </tr>
    `;
  });
  
  html += '</tbody></table>';
  container.innerHTML = html;
}

function getActionText(action) {
  const actions = {
    'CLOSE_STATION_1': '🔒 Zamknięto stanowisko 1',
    'CLOSE_STATION_2': '🔒 Zamknięto stanowisko 2',
    'CLOSE_SHIPPING': '📦 Zamknięto wysyłki',
    'CLOSE_ALL_STATIONS': '✅ Zamknięto wszystkie',
    'CLOSE_DAY_OFF': '🏖️ Dzień wolny',
    'EDIT_DAY': '✏️ Edycja dnia',
    'CLOSE_WEEK': '🏁 Zamknięto tydzień',
    'EDIT_WEEK': '✏️ Edycja tygodnia',
    'GENERATE_DATA': '🔧 Generowano dane',
    'RESET_DATA': '🗑️ Reset danych',
    'IMPORT_DATA': '📤 Import danych',
    'EXPORT_DATA': '📥 Export danych',
    'AUTO_BACKUP': '💾 Auto-backup',
    'RESTORE_BACKUP': '🔄 Przywrócono backup'
  };
  
  return actions[action] || action;
}

function getActionDetails(log) {
  const d = log.data;
  
  switch (log.action) {
    case 'CLOSE_STATION_1':
    case 'CLOSE_STATION_2':
      return `${d.date} | ${d.total} zł`;
    case 'CLOSE_SHIPPING':
      return `${d.date} | ${d.sum} zł (${d.count} szt.)`;
    case 'CLOSE_ALL_STATIONS':
      return `${d.date} | Łącznie: ${d.total} zł`;
    case 'CLOSE_DAY_OFF':
      return `${d.date} | ${d.weekKey}`;
    case 'EDIT_DAY':
      return `${d.date} | ${d.weekKey}`;
    case 'CLOSE_WEEK':
      return `${d.weekKey} | Final: ${d.final} zł`;
    case 'GENERATE_DATA':
      return `${d.weeks} tygodni od ${d.startDate}`;
    case 'AUTO_BACKUP':
      return `${d.date} | ${d.daysCount} dni, ${d.weeksCount} tygodni`;
    case 'RESTORE_BACKUP':
      return `${d.backupDate} | Przywrócono ${d.daysCount} dni`;
    default:
      return JSON.stringify(d).substring(0, 50);
  }
}

function exportLogsToFile() {
  const logs = loadLogs();
  const json = JSON.stringify(logs, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `obrot-logs-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

function cleanLogsPrompt() {
  // SUPER-ADMIN - hasło
  // Sprawdź uprawnienia admin
  if (!requireAdminAccess("Czyszczenie starych logów")) {
    return;
  }
  
  const days = prompt("Usuń logi starsze niż ile dni?\n\n(Domyślnie: 90 dni)", "90");
  if (!days) return;
  
  const deleted = cleanOldLogs(parseInt(days));
  alert(`✅ Usunięto ${deleted} starych logów`);
  refreshLogs();
}

// ================= LOGI - TYDZIEŃ =================

function renderWeekLogs() {
  const container = document.getElementById("weekLogsContainer");
  if (!container) return;
  
  const logs = getWeekLogs(currentWeek);
  
  if (logs.length === 0) {
    container.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 10px;">Brak aktywności</p>';
    return;
  }
  
  let html = '<div style="display: flex; flex-direction: column; gap: 8px;">';
  
  logs.forEach(log => {
    const date = new Date(log.timestamp);
    const time = date.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
    const dateStr = date.toLocaleDateString('pl-PL', { day: '2-digit', month: '2-digit' });
    const actionText = getActionText(log.action);
    
    html += `
      <div style="padding: 8px; background: #fff; border-left: 3px solid #3b82f6; border-radius: 4px;">
        <div style="font-weight: 600; font-size: 11px;">${actionText}</div>
        <div style="color: #6b7280; font-size: 10px; margin-top: 2px;">
          ${dateStr} ${time} | ${log.user}
        </div>
      </div>
    `;
  });
  
  html += '</div>';
  container.innerHTML = html;
}

// ================= AUTO-BACKUP =================

const BACKUP_PREFIX = "oplex:obrot:backup:";
const MAX_BACKUPS = 7; // Ostatnie 7 dni

/**
 * Sprawdź czy wszystkie stanowiska zamknięte i zrób auto-backup
 */
function checkAndAutoBackup() {
  // Odśwież dane dnia
  const day = loadDay(currentDate);
  
  if (!day) return;
  
  // Sprawdź czy wszystkie 3 stanowiska zamknięte
  if (day.s1Closed && day.s2Closed && day.shippingClosed) {
    createAutoBackup(currentDate);
    
    // Wyświetl subtelne powiadomienie
    showBackupNotification();
  }
}

/**
 * Tworzy automatyczny backup
 */
function createAutoBackup(date) {
  const backupKey = BACKUP_PREFIX + date;
  
  // Sprawdź czy backup już istnieje
  if (localStorage.getItem(backupKey)) {
    return; // Już jest backup dla tego dnia
  }
  
  const backup = {
    date: date,
    timestamp: new Date().toISOString(),
    user: getUser(),
    data: {
      days: loadDays(),
      weeks: loadWeeks()
    }
  };
  
  localStorage.setItem(backupKey, JSON.stringify(backup));
  
  // LOG
  addLog("AUTO_BACKUP", {
    date: date,
    daysCount: backup.data.days.length,
    weeksCount: backup.data.weeks.length
  });
  
  // Wyczyść stare backupy
  cleanOldBackups();
}

/**
 * Pobiera listę wszystkich auto-backupów
 */
function getAutoBackups() {
  const backups = [];
  
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key.startsWith(BACKUP_PREFIX)) {
      try {
        const backup = JSON.parse(localStorage.getItem(key));
        backups.push({
          key: key,
          date: backup.date,
          timestamp: backup.timestamp,
          user: backup.user,
          daysCount: backup.data.days.length,
          weeksCount: backup.data.weeks.length
        });
      } catch (e) {
        console.error("Błąd odczytu backupu:", e);
      }
    }
  }
  
  // Sortuj od najnowszych
  return backups.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
}

/**
 * Czyści stare backupy (zachowuje ostatnie MAX_BACKUPS)
 */
function cleanOldBackups() {
  const backups = getAutoBackups();
  
  if (backups.length <= MAX_BACKUPS) return;
  
  // Usuń najstarsze
  backups.slice(MAX_BACKUPS).forEach(backup => {
    localStorage.removeItem(backup.key);
  });
}

/**
 * Przywraca backup
 */
function restoreBackup(backupKey) {
  const confirmed = confirm(
    "⚠️ UWAGA!\n\n" +
    "Przywrócić dane z backupu?\n\n" +
    "Aktualne dane zostaną NADPISANE!\n\n" +
    "Czy kontynuować?"
  );
  
  if (!confirmed) return;
  
  try {
    const backup = JSON.parse(localStorage.getItem(backupKey));
    
    if (!backup || !backup.data) {
      alert("❌ Błąd: Nieprawidłowy backup!");
      return;
    }
    
    // Przywróć dane
    saveDays(backup.data.days);
    saveWeeks(backup.data.weeks);
    
    // LOG
    addLog("RESTORE_BACKUP", {
      backupDate: backup.date,
      daysCount: backup.data.days.length,
      weeksCount: backup.data.weeks.length
    });
    
    alert("✅ Dane przywrócone z backupu!\n\nStrona zostanie odświeżona.");
    location.reload();
    
  } catch (e) {
    alert("❌ Błąd podczas przywracania: " + e.message);
  }
}

/**
 * Pobiera backup jako plik
 */
function downloadBackup(backupKey) {
  try {
    const backup = JSON.parse(localStorage.getItem(backupKey));
    
    const json = JSON.stringify(backup, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `obrot-autobackup-${backup.date}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
  } catch (e) {
    alert("❌ Błąd podczas pobierania: " + e.message);
  }
}

/**
 * Usuwa backup
 */
function deleteBackup(backupKey) {
  // Sprawdź uprawnienia admin
  if (!requireAdminAccess("Usuwanie backupu")) {
    return;
  }
  
  const confirmed = confirm("Usunąć ten backup?\n\n⚠️ Operacja nieodwracalna!");
  
  if (!confirmed) return;
  
  localStorage.removeItem(backupKey);
  renderBackupsList();
  
  alert("✅ Backup usunięty!");
}

/**
 * Wyświetla listę backupów
 */
function renderBackupsList() {
  const container = document.getElementById("backupsContainer");
  if (!container) return;
  
  const backups = getAutoBackups();
  
  if (backups.length === 0) {
    container.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 20px;">Brak automatycznych backupów</p>';
    return;
  }
  
  let html = '<table style="width: 100%; font-size: 13px;">';
  html += '<thead><tr style="background: #f9fafb;"><th style="padding: 8px; text-align: left;">Data</th><th>Utworzono</th><th>Użytkownik</th><th>Dni</th><th>Tygodnie</th><th>Akcje</th></tr></thead>';
  html += '<tbody>';
  
  backups.forEach(backup => {
    const date = new Date(backup.timestamp);
    const dateStr = date.toLocaleString('pl-PL');
    
    html += `
      <tr style="border-bottom: 1px solid #e5e7eb;">
        <td style="padding: 8px;"><strong>${backup.date}</strong></td>
        <td style="padding: 8px;">${dateStr}</td>
        <td style="padding: 8px;">${backup.user}</td>
        <td style="padding: 8px;">${backup.daysCount}</td>
        <td style="padding: 8px;">${backup.weeksCount}</td>
        <td style="padding: 8px;">
          <button onclick="restoreBackup('${backup.key}')" style="padding: 4px 8px; font-size: 11px; margin-right: 4px;">🔄 Przywróć</button>
          <button onclick="downloadBackup('${backup.key}')" style="padding: 4px 8px; font-size: 11px; margin-right: 4px;">📥 Pobierz</button>
          <button onclick="deleteBackup('${backup.key}')" style="padding: 4px 8px; font-size: 11px; background: #ef4444; color: #fff;">🗑️</button>
        </td>
      </tr>
    `;
  });
  
  html += '</tbody></table>';
  container.innerHTML = html;
}

/**
 * Pokazuje subtelne powiadomienie o backupie
 */
function showBackupNotification() {
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #16a34a;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    font-size: 14px;
    font-weight: 600;
    z-index: 9999;
    animation: slideIn 0.3s ease-out;
  `;
  notification.innerHTML = '✅ Auto-backup utworzony';
  
  document.body.appendChild(notification);
  
  // Usuń po 3 sekundach
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease-out';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// Dodaj style animacji
const style = document.createElement('style');
style.innerHTML = `
  @keyframes slideIn {
    from { transform: translateX(400px); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  @keyframes slideOut {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(400px); opacity: 0; }
  }
`;
document.head.appendChild(style);

// ================= INICJALIZACJA =================
try {
  initWeekTracking();
  showView("day");
} catch (error) {
  console.error("Błąd inicjalizacji:", error);
  alert("Błąd uruchamiania systemu. Sprawdź konsolę (F12).");
}

// ================= DATA STARTOWA SYSTEMU =================
/**
 * Ustawia datę startową systemu
 */
function setSystemStartDate() {
  const dateInput = document.getElementById('systemStartDate');
  const warning = document.getElementById('startDateWarning');
  const status = document.getElementById('startDateStatus');
  const currentDateSpan = document.getElementById('currentStartDate');
  
  if (!dateInput || !dateInput.value) {
    alert('⚠️ Wybierz datę!');
    return;
  }
  
  const selectedDate = dateInput.value;
  
  // Sprawdź czy to poniedziałek
  const dateObj = new Date(selectedDate + 'T00:00:00');
  const dayOfWeek = dateObj.getDay();
  
  if (dayOfWeek !== 1) {
    if (warning) {
      warning.style.display = 'block';
    }
    alert('⚠️ Wybrana data nie jest poniedziałkiem!\n\nWybierz poniedziałek aby system działał poprawnie.');
    return;
  }
  
  // Ukryj warning
  if (warning) {
    warning.style.display = 'none';
  }
  
  // Zapisz datę
  localStorage.setItem('oplex:system:startDate', selectedDate);
  
  // Pokaż status
  if (status && currentDateSpan) {
    currentDateSpan.textContent = selectedDate + ' (poniedziałek)';
    status.style.display = 'block';
  }
  
  alert(`✅ Data startowa ustawiona!\n\n${selectedDate}\n\nSystem będzie działał od tego dnia.\nMożesz teraz cofać się strzałkami do tej daty.`);
  
  // Odśwież stronę aby zastosować nową datę
  const reload = confirm('Odświeżyć stronę aby zastosować zmiany?');
  if (reload) {
    location.reload();
  }
}

/**
 * Pokazuje aktualną datę startową przy ładowaniu strony
 */
function showStartDateStatus() {
  const savedStartDate = localStorage.getItem('oplex:system:startDate');
  const status = document.getElementById('startDateStatus');
  const currentDateSpan = document.getElementById('currentStartDate');
  const dateInput = document.getElementById('systemStartDate');
  
  if (savedStartDate && status && currentDateSpan) {
    currentDateSpan.textContent = savedStartDate + ' (poniedziałek)';
    status.style.display = 'block';
  }
  
  // Ustaw wartość w input
  if (dateInput) {
    if (savedStartDate) {
      dateInput.value = savedStartDate;
    } else {
      // Ustaw dzisiejszą datę jako domyślną
      const today = new Date();
      dateInput.value = formatDate(today);
    }
  }
}

// Pokaż status przy ładowaniu zakładki Zarządzaj
document.addEventListener('DOMContentLoaded', function() {
  const manageTab = document.querySelector('[onclick*="showView"]');
  if (manageTab) {
    manageTab.addEventListener('click', function() {
      setTimeout(showStartDateStatus, 100);
    });
  }
  
  // Pokaż też przy pierwszym ładowaniu jeśli jesteśmy na zarządzaj
  setTimeout(showStartDateStatus, 500);
});

// ================= ZEGAR CYFROWY =================
/**
 * Aktualizuje zegar cyfrowy co sekundę
 */
function updateDigitalClock() {
  const clockTime = document.getElementById('clockTime');
  const clockDate = document.getElementById('clockDate');
  
  if (!clockTime) return;
  
  const now = new Date();
  
  // Czas: HH:MM:SS
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  clockTime.textContent = `${hours}:${minutes}:${seconds}`;
  
  // Data: DD.MM.YYYY
  if (clockDate) {
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const weekdays = ['Niedziela', 'Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota'];
    const weekday = weekdays[now.getDay()];
    clockDate.textContent = `${weekday}, ${day}.${month}.${year}`;
  }
}

// Uruchom zegar przy ładowaniu strony
document.addEventListener('DOMContentLoaded', function() {
  updateDigitalClock();
  setInterval(updateDigitalClock, 1000); // Aktualizuj co sekundę
});

// Uruchom też od razu (na wypadek gdyby DOMContentLoaded już przeszedł)
if (document.readyState === 'complete' || document.readyState === 'interactive') {
  updateDigitalClock();
  setInterval(updateDigitalClock, 1000);
}
